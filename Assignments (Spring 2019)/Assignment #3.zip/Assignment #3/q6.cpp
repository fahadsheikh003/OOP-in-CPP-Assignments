#include<iostream>
using namespace std;
struct Address
{
	private:
		int HouseNumber;
		int street;
		int ApartmentNumber;
		char* city;
		char* state;
		int PostalCode;
	public:
		Address(int,int,char*,char*,int);
		Address(int,int,int,char*,char*,int);
		void print();
		bool compareTO(Address);
		int getPostal()
		{
			return PostalCode;
		}
		void setPostalCode(int P)
		{
			PostalCode=P;
		}
};
Address::Address(int HN,int Str,char* C,char* S,int PC)
{
	HouseNumber=HN;
	street=Str;
	ApartmentNumber=0;
	city=C;
	state=S;
	PostalCode=PC;
}
Address::Address(int HN,int Str,int AN,char* C,char* S,int PC)
{
	HouseNumber=HN;
	street=Str;
	ApartmentNumber=AN;
	city=C;
	state=S;
	PostalCode=PC;
}
void Address::print()
{
	cout<<"Address: \nHouse #"<<HouseNumber<<", Street #"<<street<<", ";
	if (ApartmentNumber!=0)
	{
		cout<<"Apartment #"<<ApartmentNumber;
	}
	cout<<endl<<city<<", "<<state<<", "<<PostalCode<<endl;
}
bool Address::compareTO(Address X)
{
	if (PostalCode>X.getPostal())
	{
		return false;
	}
	else
	{
		return true;
	}
}
