#include<iostream>
using namespace std;
class Array
{
	private:
		int *ptrtoArray;
		int s;
		int currentpos;
	public:
		Array()
		{
			ptrtoArray=new int;
			s=1;
			currentpos=0;
		}
		Array(int size)
		{
			ptrtoArray=new int [size];
			s=size;
			currentpos=0;
		}
		Array(int *arr,int size)
		{
			ptrtoArray=new int [size];
			s=size;
			for (int a=0;a<size;a++)
			{
				ptrtoArray[a]=arr[a];
			}
			currentpos=s;
		}
		Array(const Array &X)
		{
			s=X.length();
			ptrtoArray=new int [s];
			for (int a=0;a<s;a++)
			{
				ptrtoArray[a]=X.getAt(a);
			}
			currentpos=s-1;
		}
		int getAt(int b) const
		{
			return ptrtoArray[b];
		}
		void setAt(int i,int val)
		{
			if (i>=length())
			{
				return;
			}
			else
			{
				if (i>=currentpos)
				{
					currentpos=i;
				}
				ptrtoArray[i]=val;
			}
		}
		Array subArr(int pos,int size)
		{
			Array X(size-pos);
			for (int a=pos,b=0;a<size;a++,b++)
			{
				X.setAt(b,ptrtoArray[a]);
			}
			return X;
		}
		Array subArr(int pos)
		{
			Array X(s-pos);
			for (int a=pos,b=0;a<s;a++,b++)
			{
				X.setAt(b,ptrtoArray[a]);
			}
			return X;
		}
		int * subArrPointer(int pos,int size)
		{
			int *Arr=new int [size-pos];
			for (int a=pos,b=0;a<size;a++,b++)
			{
				Arr[b]=ptrtoArray[a];
			}
			return Arr;
		}
		int *subArrPointer(int pos)
		{
			int *Arr=new int [s-pos];
			for (int a=pos,b=0;a<s;a++,b++)
			{
				Arr[b]=ptrtoArray[a];
			}
			return Arr;
		}
		void push_back(int a)
		{
			if (a<s)
			{
				ptrtoArray[++currentpos]=a;
			}
		}
		int pop_back()
		{
			currentpos--;
			return ptrtoArray[currentpos+1];
		}
		int insert(int idx,int val)
		{
			if (idx<s)
			{
				int Temp;
				do
				{
					Temp=ptrtoArray[idx];
					ptrtoArray[idx]=val;
					val=Temp;
					idx++;
				}
				while (idx<=currentpos);
				currentpos=idx;
				return 1;
			}
			else
			{
				return -1;
			}
		}
		int erase(int idx)
		{
			if (idx<s)
			{
				while(idx<currentpos)
				{
					ptrtoArray[idx]=ptrtoArray[idx+1];
					idx++;
				}
				currentpos=idx-1;
			}
			else
			{
				return -1;
			}
		}
		int length() const
		{
			return s;
		}
		void clear()
		{
			currentpos=0;
		}
		int value(int idx) const
		{
			return ptrtoArray[idx];
		}
		void assign(int idx,int val)
		{
			if (idx<s)
			{
				ptrtoArray[idx]=val;
			}
			else
			{
				return;
			}
		}
		void copy(const Array &Arr)
		{
			int X=Arr.length();
			int Y=length();
			for (int a=0;a<X && a<Y;a++)
			{
				ptrtoArray[a]=Arr.value(a);
			}
			if (X<Y)
				currentpos=X;
			else
				currentpos=Y;
		}
		void copy(const int *arr,int size)
		{
			int Y=length();
			for (int a=0;a<size && a<Y;a++)
			{
				ptrtoArray[a]=arr[a];
			}
			if (size<Y)
				currentpos=size;
			else
				currentpos=Y;
		}
		void display()
		{
			cout<<"Data in the Array: "<<endl;
			for (int a=0;a<=currentpos;a++)
			{
				cout<<"["<<a<<"]:\t"<<ptrtoArray[a]<<endl;
			}
		}
		bool isEmpty()
		{
			if (currentpos==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		Array find(int X)
		{
			Array Y(20);
			for (int a=0;a<currentpos;a++)
			{
				if (ptrtoArray[a]==X)
				{
					Y.push_back(ptrtoArray[a]);
				}
			}
			return Y;
		}
		bool equal(const Array &Arr)
		{
			if (Arr.length()!=length())
			{
				return false;
			}
			else
			{
				for (int a=0;a<length();a++)
				{
					if (ptrtoArray[a]!=Arr.getAt(a))
					{
						return false;
					}
				}
			}
			return true;
		}
		int sort()
		{
			for (int a=0;a<currentpos;a++)
			{
				for (int b=0;b<currentpos-a-1;b++)
				{
					if (ptrtoArray[b]>ptrtoArray[b+1])
					{
						int Temp=ptrtoArray[b];
						ptrtoArray[b+1]=ptrtoArray[b];
						ptrtoArray[b+1]=Temp;
					}
				}
			}
		}
		void reverse()
		{
			for (int a=0,b=currentpos;a<currentpos/2;a++,b--)
			{
				int Temp=ptrtoArray[a];
				ptrtoArray[a]=ptrtoArray[b];
				ptrtoArray[b]=Temp;
			}
		}
		~Array()
		{
			delete [] ptrtoArray;
		}
};
