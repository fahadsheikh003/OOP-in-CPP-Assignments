#include<iostream>
using namespace std;
struct Car
{
	private:
		float FuelEff;
		float Fuel;
	public:
		Car(float,float);
		float getFuelLevel()
		{
			return Fuel;
		}
		void tank(float);
		void drive(float);
};
Car::Car(float F=10,float Fu=0)
{
	FuelEff=F;
	Fuel=Fu;
}
void Car::tank(float Fu)
{
	Fuel+=Fu;
}
void Car::drive(float Distance)
{
	Fuel-=Distance/FuelEff;
}
