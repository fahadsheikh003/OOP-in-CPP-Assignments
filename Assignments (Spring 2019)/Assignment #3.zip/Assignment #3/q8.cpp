#include<iostream>
using namespace std;
class Student
{
	private:
		char* RollNumber;
		char* Name;
		int Batch;
		int Courses_Code[5];
		char* Courses_Name[5];
		char Courses_Grades[5];
		float CGPA;
		char* Degree;
		char* DOB;
	public:
		Student();
		Student(char*,char*,int,int [],char* [],char [],float,char*,char*);
		void setValues(char*,char*,int,int [],char* [],char [],float,char*,char*);
		void setRoll(char* R)
		{
			RollNumber=R;
		}
		void setName(char* N)
		{
			Name=N;
		}
		void setBatch(int B)
		{
			Batch=B;
		}
		void setCC(int []);
		void setCN(char* []);
		void setCG(char []);
		void setCGPA(float G)
		{
			CGPA=G;
		}
		void setDeg(char *D)
		{
			Degree=D;
		}
		void setDOB(char* D)
		{
			DOB=D;
		}
		void Display();
};
Student::Student()
{
	RollNumber="";
	Name="";
	Batch=0;
	for (int a=0;a<5;a++)
	{
		Courses_Code[a]=0;
		Courses_Name[a]="";
		Courses_Grades[a]='I';
	}
	CGPA=0.0;
	Degree="";
	DOB="1-1-2000";
}
Student::Student(char* RN,char *N,int B,int CC[],char* CN[],char CG[],float G,char* Deg,char*D)
{
	RollNumber=RN;
	Name=N;
	Batch=B;
	for (int a=0;a<5;a++)
	{
		Courses_Code[a]=CC[a];
		Courses_Name[a]=CN[a];
		Courses_Grades[a]=CG[a];
	}
	CGPA=G;
	Degree=Deg;
	DOB=D;
}
void Student::setValues(char* RN,char *N,int B,int CC[],char* CN[],char CG[],float G,char* Deg,char*D)
{
	RollNumber=RN;
	Name=N;
	Batch=B;
	for (int a=0;a<5;a++)
	{
		Courses_Code[a]=CC[a];
		Courses_Name[a]=CN[a];
		Courses_Grades[a]=CG[a];
	}
	CGPA=G;
	Degree=Deg;
	DOB=D;
}
void Student::setCC(int CC[])
{
	for (int a=0;a<5;a++)
	{
		Courses_Code[a]=CC[a];
	}
}
void Student::setCN(char* CN[])
{
	for (int a=0;a<5;a++)
	{
		Courses_Name[a]=CN[a];
	}
}
void Student::setCG(char CG[])
{
	for (int a=0;a<5;a++)
	{
		Courses_Grades[a]=CG[a];
	}
}
void Student::Display()
{
	cout<<"Student Name: "<<Name<<"\t\t\t\t\t\t\t\tRoll No. "<<RollNumber<<endl;
	cout<<"Date of Birth: "<<DOB<<"\t\t\t\t\t\t\t\tDegree: "<<Degree<<endl<<endl;
	cout<<"\t\t\t\t\t\tBatch: "<<Batch<<endl;
	cout<<"\t\t_______________________________________________________________________________"<<endl;
	cout<<"\t\t| Code\t\t\t\tCourseTitle\t\t\t\tGrade |"<<endl;
	for (int a=0;a<5;a++)
	{
		cout<<"\t\t| "<<Courses_Code[a]<<"\t\t\t\t"<<Courses_Name[a]<<"\t\t\t\t\t    "<<Courses_Grades[a]<<" |"<<endl;
	}
	cout<<"\t\t|_____________________________________________________________________________|"<<endl;
	cout<<"\t\t\t\t\t\tCGPA: "<<CGPA<<endl;
}
/*
int main()
{
	char *CN[5]={"PF","AP","OOP","Cal","Isl"};
	char CG[5]={'A','A','A','B','B'};
	int CC[5]={202,203,204,205,206};
	Student X;
	X.setValues("18I-0462","Tayyab Ejaz",2018,CC,CN,CG,3.3,"BS-CS","20-10-2000");
	X.Display();
}
*/
