#include<iostream>
using namespace std;
struct Account
{
	private:
		float balance;
	public:
		Account();
		Account(float);
		void deposit(float);
		bool withdraw(float);
		float inquire()
		{
			return balance;
		}
};
Account::Account()
{
	balance=0;
}
Account::Account(float B)
{
	balance=B;
}
void Account::deposit(float D)
{
	if (D<0)
	{
		return;
	}
	else
	{
		balance+=D;
	}
}
bool Account::withdraw(float W)
{
	if (W>balance)
	{
		balance-=5;
		return false;
	}
	else
	{	
		balance-=W;
		return true;
	}
}
