#include<iostream>
using namespace std;
struct Circle
{
	private:
		float Radius;
	public:
		Circle(float);
		float getArea();
		float getCircumference();
		~Circle();
};
Circle::Circle(float R=0)
{
	Radius=R;
}
float Circle::getArea()
{
	return 3.14*(Radius)*(Radius);
}
float Circle::getCircumference()
{
	return 2*3.14*Radius;
}
Circle::~Circle()
{
	cout<<"Good-bye!"<<endl;
}
