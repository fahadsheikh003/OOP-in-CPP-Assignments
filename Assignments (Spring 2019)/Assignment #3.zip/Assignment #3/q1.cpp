#include<iostream>
using namespace std;
struct Employee
{
	private:
		char* name;
		double salary;
	public:
		Employee();
		Employee(char *,double);
		char *getName();
		double getSalary();
		~Employee();
};
Employee::Employee()
{
	name="";
	salary=0;
}
Employee::Employee(char *N,double S)
{
	name=N;
	salary=S;
}
char* Employee::getName()
{
	return name;
}
double Employee::getSalary()
{
	return salary;
}
Employee::~Employee()
{
	cout<<"Thanks for testing out Employee Structure!!!"<<endl;
}
void TestEmployee()
{
	char *Name=new char [30];
	cout<<"Enter the name of the employee: ";
	cin.getline(Name,30);
	double salary;
	cout<<"Enter Salary: ";
	cin>>salary;
	Employee X(Name,salary);
	cout<<"Name of the Employee: "<<X.getName()<<endl;
	cout<<"Salary: "<<X.getSalary()<<endl;
	delete [] Name;
}
