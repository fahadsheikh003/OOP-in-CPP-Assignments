#include<iostream>
using namespace std;
struct Employee2
{
	private:
		char* Name;
		float HourlyWage;
		float WorkedHours;
		float ExtraHours;
	public:
		Employee2();
		Employee2(char*,float,float,float);
		void setData(char*,float,float);
		float wageCalculator();
		void PayCheck();
		void setName(char *N)
		{
			Name=N;
		}
		void hourlyWage(float HW)
		{
			HourlyWage=HW;
		}
		void setWorkedHours(float WH)
		{
			WorkedHours=WH;
		}
		void setExtraHours(float EH)
		{
			ExtraHours=EH;
		}
};
Employee2::Employee2()
{
	Name="";
	HourlyWage=0;
	WorkedHours=0;
	ExtraHours=0;
}
Employee2::Employee2(char *N,float HW,float WH,float EH)
{
	Name=N;
	HourlyWage=HW;
	WorkedHours=WH;
	ExtraHours=EH;
}
void Employee2::setData(char* N,float HW,float WH)
{
	Name=N;
	HourlyWage=HW;
	if (WH>40)
	{
		WorkedHours=WH;
		ExtraHours=WH-40;
	}
	else
	{
		WorkedHours=WH;
	}
}
float Employee2::wageCalculator()
{
	if (ExtraHours!=0)
	{
		return ((WorkedHours-ExtraHours)+ExtraHours*1.50)*HourlyWage;
	}
	else
	{
		return WorkedHours*HourlyWage;
	}
}
void Employee2::PayCheck()
{
	cout<<"Paycheck for employee "<<Name<<endl<<endl;
	cout<<"\tHours Worked: "<<WorkedHours<<endl;
	cout<<"\tHourly Wage: "<<HourlyWage<<endl<<endl;
	if (ExtraHours!=0)
	{
		cout<<"\tOvertime Hours: "<<ExtraHours<<endl;
		cout<<"\tOvertime Hourly Wage: "<<HourlyWage*1.5<<endl<<endl;
	}
	cout<<"Total Payment: "<<wageCalculator()<<endl;
}
