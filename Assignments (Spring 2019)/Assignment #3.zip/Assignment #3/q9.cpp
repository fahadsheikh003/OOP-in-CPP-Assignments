#include<iostream>
using namespace std;
class Rectangle
{
	private:
		float length;
		float width;
	public:
		Rectangle()
		{
			length=0;
			width=0;
		}
		Rectangle(float L,float W)
		{
			length=L;
			width=W;
		}
		void setLength(float L)
		{
			if (L>=0)
				length=L;
		}
		void setWidth(float W)
		{
			if (W>=0)
				width=W;
		}
		float perimeter()
		{
			return 2*(length+width);
		}
		float area()
		{
			return length*width;
		}
		void show();
		int sameArea(Rectangle);
};
void Rectangle::show()
{
	cout<<"Length: "<<length<<endl;
	cout<<"Width: "<<width<<endl;
}
int Rectangle::sameArea(Rectangle X)
{
	if (area()==X.area())
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
