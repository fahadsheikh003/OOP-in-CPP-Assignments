#include<iostream>
using namespace std;
struct FlightInfo
{
	private:
		int FlightNumber;
		char* Destination;
		float Distance;
		float Fuel;
		void calFuel();
	public:
		FlightInfo(int Num,char * Dest,float Dist)
		{
			FlightNumber=Num;
			Destination=Dest;
			Distance=Dist;
			calFuel();
		}
		void feedInfo(int,char *,float);
		void showInfo();
		float getFuel()
		{
			return Fuel;
		}

};
void FlightInfo::calFuel()
{
	if (Distance<=1000)
	{
		Fuel=500;
	}
	else if (Distance<=2000)
	{
		Fuel=1100;
	}
	else
	{
		Fuel=2200;
	}
}
void FlightInfo::feedInfo(int Num,char* Dest,float Dist)
{
	FlightNumber=Num;
	Destination=Dest;
	Distance=Dist;
	calFuel();
}
void FlightInfo::showInfo()
{
	cout<<"Flight number: "<<FlightNumber<<endl;
	cout<<"Destination: "<<Destination<<endl;
	cout<<"Distance: "<<Distance<<endl;
}
