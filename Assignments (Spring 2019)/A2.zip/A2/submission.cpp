#include<iostream>
#include<fstream>
#include<cmath>
#include<string.h>
using namespace std;


/*
int find(int array[], int length, int target)
{
//write your code here for question 1

	if(length>0)
	{
		if(array[length-1]==target)
		{
			return length-1;
		}
		else
			find(array,length-1,target);
	}
	else
		return -1;
}

bool isPrime(int n, int i = 2)
{
//write your code here for question 2
if(n<2)
return false;

if(i<=n)
	{

		if(i==n)
		{
		return true;
		}
		if(n%i == 0 && i!=n)
		{
			return false;
		}
		else
			isPrime(n,i+1);
	}



}

char findUpperCase(char * str, int index)
{
//write your code here for question 3

	if(str[index]!='\0')
	{
		if(str[index]<91 && str[index]>64)
		{
			return str[index];
		}
		else
			findUpperCase(str,index+1);
	}

}

float calculatePi(int n)
{
//write your code here for question 4

if(n>0)
	{
		if(n==1)
		{
			return 4.0f;
		}
		else
		{

			float x =(4.0f*((1.0f/((2.0f*n)-1.0f))*pow(-1,n+1)))+calculatePi(n-1);

			return x;
		}
	}

}


int checkEachRow(int ** matrix1, int **matrix2, int row, int column)
{
	if(column>=0)
	{
		if(matrix1[row][column]!= matrix2[row][column])
			{return 0;}
		checkEachRow(matrix1,matrix2,row,column-1);
	}
	else
	return 1;
}
int checkEqual(int ** matrix1, int **matrix2, int row, int column)
{
 if(row>=0)
 {
	 int x = checkEachRow( matrix1,matrix2, row,  column);
	if( x == 0)
	{
		return 0;
	}
	checkEqual( matrix1,matrix2, row-1, column);
 }
 else
 return 1;
}

void calculateSumForEachRow(int **matrix1, int row, int column, int &evenSum, int &oddSum)
{
	if(column>=0)
		{
			if(matrix1[row][column]%2 !=0)
			{
				oddSum+=matrix1[row][column];
				calculateSumForEachRow(matrix1,row,column-1, evenSum,oddSum);
			}
			else
			{
				evenSum+=matrix1[row][column];
				calculateSumForEachRow(matrix1,row,column-1,evenSum,oddSum);
			}

		}


}


void calculateSum(int **matrix1, int row, int column, int &evenSum, int &oddSum)
{

	if(row>=0)
	 {
		calculateSumForEachRow(matrix1,row,column,evenSum,oddSum);
		calculateSum(matrix1,row-1,column,evenSum,oddSum);
	 }
}

//............................................................................................................................................................//

void printChar(char c,int n, fstream &output)
{
	if (n <= 0)
		return;
	else
	{
		output << c;
		printChar(c,n - 1, output);

	}
}

void printPattern1(int start, int end, fstream &output)
{
//write your code here for question 7
	if(start<end/2)
	{
		printChar(' ',start,output);
		printChar('*',1,output);
		output<<endl;
		printPattern1(start+1,end, output);
		printChar(' ',start,output);
		printChar('*',1,output);
		output<<endl;
		

	}

	else{
		printChar(' ',start,output);
		printChar('*',1,output);
		output<<endl;
		}
}


//............................................................................................................................................................//



void printPattern2(int mline, int startLine, int space, fstream &output)
{
//write your code here for question 8
	if(startLine<mline)
	{
			printChar(' ',(startLine),output);
			printChar('*',1,output);
			printChar(' ',(2*space)-3,output);
			printChar('*',1,output);
			output<<endl;
			printPattern2( mline, startLine+1,space-1, output);
						printChar(' ',(startLine),output);
						printChar('*',1,output);
						printChar(' ',(2*space)-3,output);
						printChar('*',1,output);
						output<<endl;

	}
	else
	{
				printChar(' ',startLine,output);
				printChar('*',1,output);
				output<<endl;
	}
}




//............................................................................................................................................................//



void printPattern3(int sp, int mLine, fstream &output)
{
//write your code here for question 9

	if(mLine>1)
			{

				printChar(' ',mLine,output);
				printChar('*',2*sp-1,output);
				output<<endl;
				printPattern3(sp+1,mLine-1,output);
				printChar(' ',mLine,output);
				printChar('*',2*sp-1,output);
				output<<endl;
			}
	else
	{
						printChar(' ',mLine,output);
						printChar('*',2*sp-1,output);
						output<<endl;
	}
}



//............................................................................................................................................................//


long factorial(int n)
{
	if(n==0)
		return 1;
	else
		return n*factorial(n-1);
}

long permutate(int n, int r)
{
//write your code here for question 10
	return factorial(n)/factorial(n-r);

}

//.....................................................................................................................................................................//

*/

void istore(int arr[], int **sumTriangle, int row, int column)
{
	if(column>0)
	{
		sumTriangle[row-1][column-1] = arr[column-1];
		istore(arr,sumTriangle, row,column-1);
	}
}

void fstore( int size, int **sumTriangle, int row, int column)
{
	if(size>0)
	{
		sumTriangle[row-1][column-1] = sumTriangle[row][column-1]+sumTriangle[row][column-2];
		fstore( size -1, sumTriangle,  row,  column-1);
	}

}

//...................................................................................//
void printSumTriangle(int arr[], int size, int **sumTriangle, int row, int column)
{
	if(row>0)
	{
		if(row==column)
		{
			istore(arr, sumTriangle, row,column);
			printSumTriangle(arr, size-1, sumTriangle, row-1,column);
		}
		else
		{
			fstore( size, sumTriangle, row, column);
			printSumTriangle(arr, size-1, sumTriangle, row-1,column);
		}
	}

}


//zero onward callin
// call from main  // 	printAll( res,0, 5, 5);

/*
void printRow( int **sumTriangle, int iy, int ix, int column)
{
	if(iy<column)
	{
		cout<<sumTriangle[ix][iy]<<" ";
		printRow(sumTriangle,iy+1, ix, column);
	}

}


void printAll( int **sumTriangle,int ix, int row, int column)
{
	if(ix<row)
	{
		printRow( sumTriangle,0, ix, column);
		cout<<endl;
		printAll(sumTriangle,ix+1,row, column);
	}

}
*/




//.....................................................................................................................................................................//

/*
int func(int res, int wrap) 
{ 
    
    if (res < wrap) 
        return 0; 
     
    int newRes = res/wrap; 
    return newRes + func(newRes+ res%wrap, wrap); 
} 


int countMaxChoco(int money, int price, int wrap)
{


int res = money/price; 
    
    return res + func(res, wrap); 
}















//.....................................................................................................................................................................//
bool solveNQUtil(int **board, int N, int col)
{
//write your code here for question 13
}*/
