#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;


struct Point{
	float x;
	float y;
};

struct Circle{
	Point p;
	float radius;
	
	Circle();
	Circle(float r);
	float getArea();
	float getCircumference();
};

//.............................................................................//

Circle::Circle()
{
radius = 0.0;
}
Circle::Circle(float r)
{
	if(r>0.0)
	{
		radius = r;
	}
	else
	{
		radius = 0.0;
	}
	p.x = 0.0;
	p.y = 0.0;
}
float Circle::getArea()
{
	return (3.14 *(radius*radius));
}
float Circle::getCircumference()
{
	return (2*3.14*radius);
}




