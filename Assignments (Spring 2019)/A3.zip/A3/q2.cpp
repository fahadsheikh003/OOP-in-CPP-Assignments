#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;




struct Car{
	float fuelEfficiency;
	float fuelLevel;

	Car();
	Car(float eff, float lvl);
	void drive(float distanceKm);
	float getFuelLevel();
	void tank(float fuel);

};

//..................................................................................................................................//



Car::Car()
{
fuelLevel = 0.0;
fuelEfficiency = 10.0;

}
Car::Car(float eff, float lvl)
{
	if(eff>=10.0)
	{
		fuelEfficiency = eff;
	}
	else
	{
		fuelEfficiency = 10.0;
	}

	if(lvl>=0.0)
		{
			fuelLevel = lvl;
		}
		else
		{
			fuelLevel = 0.0;
		}


}
void Car::drive(float distanceKm)
{
fuelLevel-= distanceKm/fuelEfficiency;
}
float Car::getFuelLevel()
{
return fuelLevel;
}
void Car::tank(float fuel)
{
fuelLevel+=fuel;
}









