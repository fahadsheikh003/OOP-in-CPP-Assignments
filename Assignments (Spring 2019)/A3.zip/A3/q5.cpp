#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;

struct Employee2
{
	char* name;
	float HourlyWage;
	float WorkedHours;
	float ExtraHours;

	Employee2();
	Employee2(char*n,float hourlyWage, float workedHours , float extraHours);
	bool setName(char*n);
	bool hourlyWage(float hourlyWage);
	bool setWorkedHours(float workedHours);
	bool setExtraHours(float extraHours);
	float wageCalculator();

};

//..............................................................................................................//


Employee2::Employee2()
{
	name = NULL;
	HourlyWage = 0.0;
	WorkedHours = 0.0;
	ExtraHours = 0.0;

}
Employee2::Employee2(char*n,float hourlyWage, float workedHours , float extraHours)
{
	if(hourlyWage>0.0)
	{
		HourlyWage = hourlyWage;
	}
	else
	{
		HourlyWage = 0.0;
	}

	if(workedHours>=0.0)
	{
		WorkedHours = workedHours;
	}
	else
	{
		WorkedHours = 0.0;
	}

	if(extraHours>=0.0)
	{
		ExtraHours = extraHours;
	}
	else
	{
		ExtraHours = 0.0;
	}


		if(n!=NULL || n!="\0" || n!="")
		{
			name = n;
		}
		else
		{
			name = NULL;
		}

}
bool Employee2::setName(char*n)
{
	if(n!=NULL || n!="\0" || n!="")
	{
		name = n;
		return true;
	}
	else
	{
		name = NULL;
		return false;
	}


}
bool Employee2::hourlyWage(float hourlyWage)
{
	if(hourlyWage>0.0)
	{
		HourlyWage = hourlyWage;
		return true;
	}
	else
	{
		HourlyWage = 0.0;
		return false;
	}
}
bool Employee2::setWorkedHours(float workedHours)
{
	if(workedHours>=0.0)
	{
		WorkedHours = workedHours;
		return true;
	}
	else
	{
		WorkedHours = 0.0;
		return false;
	}

}
bool Employee2::setExtraHours(float extraHours)
{
	if(extraHours>=0.0)
	{
		ExtraHours = extraHours;
		return true;
	}
	else
	{
		ExtraHours = 0.0;
		return false;
	}

}
float Employee2::wageCalculator()
{
	float FirstPayment;
	float OvertimePayment;
	float TotalPayment;

	if(WorkedHours>40.0)
	{
		float temp = WorkedHours;
		WorkedHours = 40.0;
		ExtraHours = temp - 40.0;

	}

	FirstPayment = WorkedHours*HourlyWage;

	OvertimePayment = (ExtraHours*15.0);

	TotalPayment = FirstPayment + OvertimePayment;

	return TotalPayment;
}



