#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;


struct FlightInfo{
private:
	int FlightNumber;
	char* Destination;
	float Distance;
	float Fuel;
	void calFuel();

public:
	FlightInfo();
	FlightInfo(int flightNo, char*des, float distanc);
	bool setFlightNumber(int flightNo);
	bool setDestination(char*des);
	bool setDistance(float distanc);
	char * getDestination();
	int getFlightNumber();
	float getDistance();
	void feedInfo();
	void showInfo();
	float getFuel();
};


//...................................................................................................//


FlightInfo::FlightInfo()
{
FlightNumber = 0;
Distance = 0.0;
Destination= NULL;


}
void FlightInfo::calFuel()
{

	if(Distance>2000.0)
	{
		Fuel = 2200.0;
	}
	else if(Distance>1000.0 && Distance <= 2000.0)
	{
		Fuel = 1100.0;
	}
	else
	{
		Fuel = 500.0;
	}
}

FlightInfo::FlightInfo(int flightNo, char*des, float distanc)
{
	if(flightNo>=0)
	{
		FlightNumber = flightNo;
	}
	else
	{
		FlightNumber = 0;
	}

	if(distanc>=0.0)
		{
			Distance = distanc;
		}
		else
		{
			Distance = 0.0;
		}

	if(des!=NULL || des!="\0" || des!="")
		{
			Destination = des;
		}
		else
		{
			Destination = NULL;
		}

	calFuel();

}




bool FlightInfo::setFlightNumber(int flightNo)
{
	if(flightNo>=0)
	{
		FlightNumber = flightNo;
		return true;
	}
	else
	{
		FlightNumber = 0;
		return false;
	}

}
bool FlightInfo::setDestination(char*des)
{
	if(des!=NULL || des!="\0" || des!="")
	{
		Destination = des;
		return true;
	}
	else
	{
		Destination = NULL;
		return false;
	}


}
bool FlightInfo::setDistance(float distanc)
{
	if(distanc>=0.0)
	{
		Distance = distanc;
		return true;
	}
	else
	{
		Distance = 0.0;
		return false;
	}
}
char * FlightInfo::getDestination()
{
	return Destination;
}
int FlightInfo::getFlightNumber()
{
	return FlightNumber;
}
float FlightInfo::getDistance()
{
	return Distance;
}


void FlightInfo::feedInfo()
{
		int flightNo;
		char *ptr = new char[100];
		float dis;

		cout<<"Enter Destination.  "<<endl;
		cin.getline(ptr,100);
		cout<<"Enter Flight NUmber. "<<endl;
		cin>>flightNo;
		cout<<"Enter Distance.  "<<endl;
		cin>>dis;



		FlightNumber = flightNo;
		Destination = ptr;
		Distance = dis;

		calFuel();
}

void FlightInfo::showInfo()
{
	cout<<"Destination: ";

	for(int i =0;Destination[i]!='\0';i++)
	{
		cout<<Destination[i];
	}
	cout<<endl;
	cout<<"Flight NUmber: "<< FlightNumber<<endl;
	cout<<"Distance: "<<Distance<<endl;
	cout<<"Fuel: "<<Fuel<<endl;
}
float FlightInfo::getFuel()
{
return Fuel;
}



