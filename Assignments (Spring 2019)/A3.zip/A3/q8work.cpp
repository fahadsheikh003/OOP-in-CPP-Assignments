

class Student{
	char *RollNumber;
	char *Name;
	int Batch;
	int Courses_Code[5];
	char *Courses_Name [5];
	char Courses_Grade[5];
	float CGPA;
	char *Degree;
	char *DateOfBirth;

public:
	Student();
	Student(char *rn,char *n,int b, int cc[],char * z[], char x[],float cgpa, char * degre, char* dob);
	bool setRollNumber(char* rn);
	char* getRollNumber() ;
	bool setName(char* n);
	char* getName() ;
	bool setBatch(int b);
	int getBatch();
	bool setCgpa(float cgpa);
	float getCgpa() ;
	bool setDegree(char* degre);
	char* getDegree() ;
	bool setDateOfBirth(char* dob);
	char* getDateOfBirth() ;
	bool setCoursesCode(int cc[]);
	bool setCoursesGrade(char x[]);
	bool setCoursesName(char*z[]);
	int* getCoursesCode() ;
	char* getCoursesGrade() ;
	char** getCoursesName() ;
	void SetValues();
	void Display();

};






//main

/*

	char*z[5];

		for(int i =0;i<5;i++)
		{
			z[i] = new char[100];

		}

		for(int i =0;i<5;i++)
			{

				cout<<"enter subject"<<i+1<<endl;
				cin.getline(z[i],100);

			}


		char*rn = "i181573";
		char*n = "fatima";
		int b = 2018;
		int cc[5]={11,22,33,44,55};
		char x[5]={'A','B','C','D','B'};
		int cgpa = 2.8;
		char* degre = "BS-CS";
		char* dob = "Jan 29, 2010";



	Student s(rn,n,b, cc,z,x,cgpa, degre, dob);

	s.Display();




*/


//.....................................//




Student::Student()
{
		RollNumber = NULL;
		Name = NULL;
		Batch = 0;
		for(int i =0;i<5;i++)
		{
			Courses_Code[i] = 0;
		}

		for(int i =0;i<5;i++)
		{
			Courses_Name[i] = new char[200];
		}
		for(int i =0;i<5;i++)
		{

			Courses_Name[i][0] = '\0';
		}


		for(int i =0;i<5;i++)
		{
			Courses_Grade[i] = '\0';
		}

		CGPA = 0.0;
		Degree = NULL;
		DateOfBirth = NULL;


}
Student::Student(char *rn,char *n,int b, int cc[],char * z[], char x[],float cgpa, char * degre, char* dob)
{

	if(rn!=NULL || rn!="\0" || rn!="")
	{
		RollNumber = rn;

	}
	else
	{
		RollNumber = NULL;

	}


	if(n!=NULL || n!="\0" || n!="")
	{
		Name = n;

	}
	else
	{
		Name = NULL;

	}


	if(b>2005)
	{
		Batch = b;

	}
	else
	{
		Batch = 2005;

	}

	if(cgpa>=0.0)
	{
		CGPA = cgpa;

	}
	else
	{
		CGPA = 0.0;

	}

	if(degre!=NULL || degre!="\0" || degre!="")
	{
		Degree = degre;
	}
	else
	{
		Degree = NULL;
	}

	if(dob!=NULL || dob!="\0" || dob!="")
	{
		DateOfBirth = dob;

	}
	else
	{
		DateOfBirth = NULL;

	}


	for(int i =0;i<5;i++)
	{
		Courses_Code[i] = cc[i];
	}


	for(int i =0;i<5;i++)
	{
		Courses_Grade[i] = x[i];
	}


	for(int i =0;i<5;i++)
	{
		Courses_Name[i] = new char[200];
	}
	for(int i =0;i<5;i++)
	{

		Courses_Name[i] = z[i];
	}


	cout<<"bla"<<endl;

}
bool Student::setRollNumber(char* rn)
{
	if(rn!=NULL || rn!="\0" || rn!="")
	{
		RollNumber = rn;
		return true;
	}
	else
	{
		RollNumber = NULL;
		return false;
	}
}
char* Student::getRollNumber()
{
return RollNumber;
}
bool Student::setName(char* n)
{
	if(n!=NULL || n!="\0" || n!="")
		{
			Name = n;
			return true;
		}
		else
		{
			Name = NULL;
			return false;
		}
}
char* Student::getName()
{
return Name;
}
bool Student::setBatch(int b)
{
	if(b>2005)
	{
		Batch = b;
		return true;
	}
	else
	{
		Batch = 2005;
		return false;
	}

}
int Student::getBatch()
{
return Batch;
}
bool Student::setCgpa(float cgpa)
{
	if(cgpa>=0.0)
	{
		CGPA = cgpa;
		return true;
	}
	else
	{
		CGPA = 0.0;
		return false;
	}
}
float Student::getCgpa()
{
return CGPA;
}
bool Student::setDegree(char* degre)
{
	if(degre!=NULL || degre!="\0" || degre!="")
			{
				Degree = degre;
				return true;
			}
			else
			{
				Degree = NULL;
				return false;
			}
}
char* Student::getDegree()
{
return Degree;
}
bool Student::setDateOfBirth(char* dob)
{
	if(dob!=NULL || dob!="\0" || dob!="")
			{
				DateOfBirth = dob;
				return true;
			}
			else
			{
				DateOfBirth = NULL;
				return false;
			}
}
char* Student::getDateOfBirth()
{
return DateOfBirth;
}
bool Student::setCoursesCode(int cc[])
{


	for(int i =0;i<5;i++)
	{
		Courses_Code[i] = cc[i];
	}
	return true;
}
bool Student::setCoursesGrade(char x[])
{


	for(int i =0;i<5;i++)
	{
		Courses_Grade[i] = x[i];
	}

	return true;
}
bool Student::setCoursesName(char*z[])
{
	for(int i =0;i<5;i++)
	{
		Courses_Name[i] = new char[200];
	}
	for(int i =0;i<5;i++)
	{

		Courses_Name[i] = z[i];
	}
return true;
}
int* Student::getCoursesCode()
{
	int * ptr = Courses_Code;
return ptr;
}
char* Student::getCoursesGrade()
{
	char *ptr = Courses_Grade;
return ptr;
}
char** Student::getCoursesName()
{
char** ptr = Courses_Name;
return ptr;
}
void Student::SetValues()
{
	char *rn = new char [10];
	char *n = new char [50];
	int b;
	int cc[5];
	char * z[5];
	char x[5];
	float cgpa;
	char * degre = new char [10];
	char* dob = new char [100];

	for(int i =0;i<5;i++)
	{
		z[i] = new char[200];
	}
	cout<<"Enter your roll number"<<endl;
	cin.get(rn,10);
	cout<<"Enter your name"<<endl;
	cin.get(n,50);
	cout<<"Enter your batch"<<endl;
	cin>>b;
	cout<<"Enter your cgpa"<<endl;
	cin>>cgpa;
	cout<<"Enter your degree"<<endl;
	cin.get(degre,10);
	cout<<"Enter your date of birth"<<endl;
	cin.get(dob,100);

	for(int i =0;i<5;i++)
	{
		cout<<"enter the course code for your course "<<i+1<<endl;
		cin>>cc[i];
		cout<<"enter the course grade for your course "<<i+1<<endl;
		cin>>x[i];
		cout<<"enter the course name for your course "<<i+1<<endl;
		cin.getline(z[i],100);

	}

	RollNumber = rn;
	Name = n;
	Batch = b;

	CGPA = cgpa;
	Degree = degre;
	DateOfBirth = dob;


	for(int i =0;i<5;i++)
	{
		Courses_Code[i] = cc[i];
		Courses_Grade[i] = x[i];
		Courses_Name [i] = z[i];

	}


}
void Student::Display()
{
cout<<"Student Name :"<<Name<<setw(100);
cout<<"Roll Number :"<<RollNumber<<endl;


cout<<"Date of Birth :"<<DateOfBirth<<setw(100);
cout<<"Degree :"<<Degree<<endl;
cout<<setw(50)<<"Univ.Reg.No :"<<RollNumber<<endl;
cout<<setw(50)<<"Batch :"<<Batch<<endl;

for(int i = 0;i<5;i++)
{

	cout<<setw(25)<<Courses_Code[i]<<setw(5)<<Courses_Name[i]<<setw(5)<<Courses_Grade[i]<<endl;

}


}
