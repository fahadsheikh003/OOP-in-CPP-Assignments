#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;




class Rectangle{
	float length;
	float width;
public:
	Rectangle();
	Rectangle(float l, float w);
	void setLength(float l);
	void setWidth(float w);
	float getLength();
	float getWidth();
	float perimeter();
	float area();
	void show();
	int sameArea( Rectangle r);
};

//..............................................................................................................//


Rectangle::Rectangle()
{
	length = 0.0;
	width = 0.0;
}
Rectangle::Rectangle(float l, float w)
{
	if(l>=0.0)
	{
		length = l;
	}
	else
	{
		length = 0.0;
	}

	if(w>=0.0)
	{
		width = w;
	}
	else
	{
		width = 0.0;
	}

}
void Rectangle::setLength(float l)
{
	if(l>=0.0)
	{
		length = l;
	}
	else
	{
		length = 0.0;
	}
}
void Rectangle::setWidth(float w)
{
	if(w>=0.0)
	{
		width = w;
	}
	else
	{
		width = 0.0;
	}
}


float Rectangle::getLength()
{
	return length;
}
float Rectangle::getWidth()
{
	return width;
}



float Rectangle::perimeter()
{
	return(2*length)+(2*width);
}
float Rectangle::area()
{
	return length*width;
}
void Rectangle::show()
{
	cout<<"Length is: "<<length<<endl;
	cout<<"Width is: "<<width<<endl;
}
int Rectangle::sameArea( Rectangle r)
{
 if(this->area() == r.area())
 {
	 return 1;
 }
 else
 {
	 return 0;
 }

}





