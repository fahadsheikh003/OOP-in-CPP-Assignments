#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;




class Array{
	int* ptr;
	int tsize;
	int csize;

public:
	Array();
	Array(int size);
	Array(int *arr, int size);
	Array(const Array &copy);
	int getAt( int i);
	void setAt(int i, int val);
	Array subArr(int pos, int siz);
	Array subArr(int pos);
	int * subArrPointer(int pos, int siz);
	int * subArrPointer(int pos);
	void push_back(int a);
	int pop_back();
	int insert(int idx, int val);
	int erase(int idx,int val);
	void size();
	int length();
	void clear();
	int value(int idx);
	void assign(int idx, int val);
	void copy(const Array &Arr);
	void copy(const int *arr, int siz);
	void display();
	bool isEmpty();
	Array find(int x);
	bool equal(const Array &check);
	int sort();
	void reverse();
	~Array();

};




//..............................................................................................................................//





Array::Array()
{
	tsize = 3;
	ptr = new int [tsize];
	csize = -1;

}
Array::Array(int size)
{
	if(size>0)
	{
		tsize = size;
	}
	else
	{
		tsize = 3;
	}
	ptr = new int [tsize];
	csize = -1;

}
Array::Array(int *arr, int size)
{
	if(size>0)
	{
		tsize = size;
		ptr = new int [tsize];
		for(int i = 0; i<tsize;i++)
		{
			ptr[i]= arr[i];
			csize = i;
		}
	}
	else
	{
		tsize = 3;
		ptr = new int [tsize];
		for(int i = 0; i<tsize;i++)
		{
			ptr[i]= 0;
			csize = i;
		}
	}

}
Array::Array(const Array &copy)
{
	tsize = copy.tsize;
	csize = copy.csize;
	ptr = new int [tsize];

	for(int i =0; i<=csize;i++)
	{
		ptr[i] = copy.ptr[i];
	}

}
int Array::getAt( int i)
{
	if(i>=0 && i<=csize)
	return ptr[i];
	else
		return -1;
}
void Array::setAt(int i, int val)
{
	if(i>=0 && i<csize+1)
	{
		ptr[i]= val;

	}

	if(i == csize+1)
	{
		csize++;
		ptr[i]= val;
		//cout<<" at index " <<i <<" element is "<<val;

	}


}

Array Array::subArr(int pos, int siz)
{
	Array res(siz);
	int i = pos;
	for(int j = 0; j<siz ; j++)
	{
		res.ptr[j]= ptr[i];
		res.csize++;
		i++;
	}

	return res;
}
Array Array::subArr(int pos)
{
	int tempsiz = (csize-pos)+1;
	Array res(tempsiz);
	int i = pos;
		for(int j = 0; j<tempsiz ; j++)
		{
			res.ptr[j]= ptr[i];
			res.csize++;
			i++;
		}

		return res;
}
int * Array::subArrPointer(int pos, int siz)
{
	int*res = new int[siz];
	int i = pos;
		for(int j = 0; j<siz ; j++)
		{
			res[j]= ptr[i];
			i++;
		}

		return res;
}
int * Array::subArrPointer(int pos)
{
	int tempsiz = (csize-pos)+1;
	int*res = new int[tempsiz];
		int i = pos;
			for(int j = 0; j<tempsiz ; j++)
			{
				res[j]= ptr[i];
				i++;
			}

			return res;
}
void Array::push_back(int a)
{
	if(csize == tsize-1)
	{
		csize++;
		ptr[csize]=a;
		tsize++;
	}
	else if(csize<tsize)
	{

		csize++;
		ptr[csize]=a;
	}
}
int Array::pop_back()
{
	int temp = ptr[csize];
	ptr[csize]=0;
	csize--;

	return temp;
}
int Array::insert(int idx, int val)
{

	if(idx>=0 && idx<tsize && idx<csize+1)
	{


		for(int i = csize;i>=idx;i--)
		{
			ptr[i+1] = ptr[i];
		}

		ptr[idx]= val;

		return 1;
	}

		if(idx == csize+1)
		{
			ptr[idx]=val;
			return 1;
		}


		return -1;
}
int Array::erase(int idx,int val)
{
	if(idx>=0 && idx<=csize)
	{
		for(int i=idx;i<csize;i++)
		{
			ptr[i]=ptr[i+1];
		}

		csize--;
		return 1;
	}

	return -1;
}


void Array::size()
{
cout<<"total size is :"<<tsize<<endl;
}
int Array::length()
{
	return tsize;
}
void Array::clear()
{
	for(int i =0;i<=csize;i++)
	{
		ptr[i]=0;
	}

		csize = -1;
}




int Array::value(int idx)
{
	if(idx>=0 && idx<=csize)
		return ptr[idx];
	else
		return -1;
}
void Array::assign(int idx, int val)
{
	if(idx>=0 && idx<csize+1)
	{
		ptr[idx]= val;

	}

	if(idx == csize+1)
	{
		ptr[idx]= val;
		csize++;
	}
}
void Array::copy(const Array &Arr)
{

	tsize = Arr.tsize;
	csize = Arr.csize;
	ptr = new int [tsize];

	for(int i =0; i<=csize;i++)
	{
		ptr[i] = Arr.ptr[i];
	}

}
void Array::copy(const int *arr, int siz)
{
	for(int i =0;i<siz;i++)
	{
		ptr[i]= arr[i];
	}
}
void Array::display()
{
	for(int i =0;i<=csize;i++)
	{
		cout<<ptr[i]<<" ";
	}
}
bool Array::isEmpty()
{
	if(csize==-1)
		return true;
	else
		return false;

}
Array Array::find(int x)
{

int countf = 0;
for(int i=0;i<=csize;i++ )
{
	if(ptr[i]==x)
		countf++;
}

Array res(countf);

int j =0;

for(int i=0;i<=csize;i++ )
{
	if(ptr[i]==x)
	{
		res.ptr[j] = i;
		res.csize++;
		j++;
	}
}

return res;
}
bool Array::equal(const Array &check)
{
	int countf = 0;
	if(tsize == check.tsize)
	{
		if(csize == check.csize)
		{
			for(int i =0;i<=csize;i++)
			{
				 if(ptr[i]== check.ptr[i])
				 {
					 countf++;
				 }
			}

			if(countf == csize)
				return true;
			else
				return false;

		}
	}
}
int Array::sort()
{
int maxElement;
int index;

for(maxElement = csize ; maxElement>0 ; maxElement--)
{
	for(index = 0; index<maxElement; index++)
	{
		if(ptr[index]>ptr[index+1])
		{
			int temp = ptr[index];
			ptr[index] = ptr[index+1];
			ptr[index+1] = temp;
		}

	}
}
}
void Array::reverse()
{
	int x = csize+1;
	for(int i=0;i<x/2;i++)
	 {
		int temp;
	    temp = ptr[i];
	    ptr[i]=ptr[x-i-1];
	    ptr[x-i-1]=temp;
	 }
}
Array::~Array()
{
	delete []ptr;
}








