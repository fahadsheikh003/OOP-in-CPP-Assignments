#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;

struct Address{
	int HouseNumber;
	int street;
	int ApartmentNumber;
	char* city;
	char* state;
	int PostalCode;

	Address();
	Address(int houseNo,int st,char*c,char*s,int postal);
	Address(int houseNo,int st,int apartmentNo,char*c,char*s,int postal);
	bool setHouseNumber(int houseNo);
	bool setStreet(int st);
	bool setApartmentNumber(int apartmentNo);
	bool setPostalCode(int postal);
	bool setCity(char*c);
	bool setState(char*s);
	int getHouseNumber();
	int getStreet();
	int getApartmentNumber();
	int getPostalCode();
	char* getCity();
	char* getState();
	void print();
	bool compareTO(Address a);


};



//..............................................................................................................//



Address::Address()
{
	HouseNumber = 0;
	street = 0;
	ApartmentNumber = 0;
	city = NULL;
	state = NULL;
	PostalCode = 0;

}
Address::Address(int houseNo,int st,char*c,char*s,int postal)
{

	if(houseNo>=0)
	{
		HouseNumber = houseNo;
	}
	else
	{
		HouseNumber = 0;
	}

	if(st>=0)
	{
		street = st;
	}
	else
	{
		street = 0;
	}


	if(postal>=0)
	{
		PostalCode = postal;
	}
	else
	{
		PostalCode = 0;
	}


	if(c!=NULL || c!="\0" || c!="")
	{
		city = c;
	}
	else
	{
		city = NULL;
	}

	if(s!=NULL || s!="\0" || s!="")
	{
		state = s;
	}
	else
	{
		state = NULL;
	}

}
Address::Address(int houseNo,int st,int apartmentNo,char*c,char*s,int postal)
{

	if(houseNo>=0)
	{
		HouseNumber = houseNo;
	}
	else
	{
		HouseNumber = 0;
	}

	if(st>=0)
	{
		street = st;
	}
	else
	{
		street = 0;
	}

	if(apartmentNo>=0)
	{
		ApartmentNumber = apartmentNo;
	}
	else
	{
		ApartmentNumber = 0;
	}

	if(postal>=0)
	{
		PostalCode = postal;
	}
	else
	{
		PostalCode = 0;
	}


	if(c!=NULL || c!="\0" || c!="")
	{
		city = c;
	}
	else
	{
		city = NULL;
	}

	if(s!=NULL || s!="\0" || s!="")
	{
		state = s;
	}
	else
	{
		state = NULL;
	}

}
bool Address::setHouseNumber(int houseNo)
{
	if(houseNo>=0)
	{
		HouseNumber = houseNo;
		return true;
	}
	else
	{
		HouseNumber = 0;
		return false;
	}
}
bool Address::setStreet(int st)
{
	if(st>=0)
	{
		street = st;
		return true;
	}
	else
	{
		street = 0;
		return false;
	}
}
bool Address::setApartmentNumber(int apartmentNo)
{
	if(apartmentNo>=0)
	{
		ApartmentNumber = apartmentNo;
		return true;
	}
	else
	{
		ApartmentNumber = 0;
		return false;
	}
}
bool Address::setPostalCode(int postal)
{
	if(postal>=0)
	{
		PostalCode = postal;
		return true;
	}
	else
	{
		PostalCode = 0;
		return false;
	}


}
bool Address::setCity(char*c)
{

	if(c!=NULL || c!="\0" || c!="")
	{
		city = c;
		return true;
	}
	else
	{
		city = NULL;
		return false;
	}


}
bool Address::setState(char*s)
{

	if(s!=NULL || s!="\0" || s!="")
	{
		state = s;
		return true;
	}
	else
	{
		state = NULL;
		return false;
	}
}
int Address::getHouseNumber()
{
	return HouseNumber;
}
int Address::getStreet()
{
	return street;
}
int Address::getApartmentNumber()
{
	return ApartmentNumber;
}
int Address::getPostalCode()
{
	return PostalCode;
}
char* Address::getCity()
{
	return city;
}
char* Address::getState()
{
	return state;
}
void Address::print()
{
	cout<<HouseNumber<<" "<<street<<" "<<ApartmentNumber<<endl;
	cout<<city<<" "<<state<<" "<<PostalCode<<endl;
}
bool Address::compareTO(Address a)
{
	if(this->PostalCode > a.PostalCode)
	{
		return false;
	}
	else
	{
		return true;
	}
}





