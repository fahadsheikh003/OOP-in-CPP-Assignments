#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;


struct Account
{
	float balance;

	Account();
	Account(float b);
	void deposit(float m);
	bool withdraw(float w);
	float inquire();
};



//..............................................................................................................//


Account::Account()
{
	balance = 0.0;
}
Account::Account(float b)
{
	if(b>=0.0)
	{
		balance = b;
	}
	else
	{
		balance = 0.0;
	}
}
void Account::deposit(float m)
{
	if(m>=0.0)
	{
		balance+=m;
	}
}
bool Account::withdraw(float w)
{
	if(w>balance)
	{
		balance-=5.0;
		return false;
	}
	else
	{
		balance-=w;
		return true;
	}
}
float Account::inquire()
{
	return balance;
}
















