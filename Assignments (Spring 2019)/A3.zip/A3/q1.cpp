#include <iostream>
#include <iomanip>
#include <cstring>
#include <cmath>
#include <cstdlib>
using namespace std;


struct Employee
{
	char* name;
	double salary;

	Employee();
	Employee(char* n,double s);
	char* getName();
	double getSalary();
};

void TestEmployee();

//............................................................................//
Employee::Employee()
{
name = NULL;
salary = 0.0;
}

Employee::Employee(char* n,double s)
{
	if(s>0.0)
	{
		salary = s;
	}
	else
	{
		salary = 0.0;
	}

	if(n!=NULL || n!="\0" || n!="")
	{
		name = n;
	}
	else
	{
		name = NULL;
	}

}
char* Employee::getName()
{
return name;
}
double Employee::getSalary()
{
return salary;
}


void TestEmployee()
{
	char *n = new char[100];
	double s;

	cout<<"Creating a new employee. "<<endl;
	Employee e;
	cout<<"Please type the name: "<<endl;
	cin.getline(n,100);
	cout<<"Please specify the salary: "<<endl;
	cin>>s;
	e.name = n;
	e.salary = s;
	cout<<"New employee has been created. "<<endl;
	cout<<"Name of employee: ";
	for(int i =0;e.name[i]!='\0';i++)
	{
		cout<<e.name[i];
	}
	cout<<endl;
	cout<<"Salary: "<<e.salary<<endl;
	cout<<"Thank you for testing structure Employee. "<<endl;

}



