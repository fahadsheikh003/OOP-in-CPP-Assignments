#include<iostream>
#include<fstream>
#include<cmath>
#include<string.h>
using namespace std;
int find(int array[], int length, int target)
{
	if (length<0)
	{
		return -1;
	}
	else if (array[length]==target)
	{
		return length;
	}
	else
	{
		return find(array,length-1,target);
	}
}
bool isPrime(int n, int i = 2)
{
	if (n==i)
	{
		return true;
	}
	if (n%i==0)
	{
		return false;
	}
	return isPrime(n,i+1);
}
char findUpperCase(char * str, int index)
{
	if (*(str+index)==0 || *(str+index)>=65 && *(str+index)<=90)
	{
		return *(str+index);
	}
	return findUpperCase(str,index+1);
}
float calculatePi(int n)
{
	if (n==1)
	{	
		return 4;
	}
	else
	{
		return calculatePi(n-1)+4*(pow(-1,n+1)*(1/(2.0*n-1)));
	}
}
bool ColCheck(int **mat1,int **mat2,int row,int col)
{
	if (col==0)
	{
		return true;
	}
	if (mat1[row][col]!=mat2[row][col])
	{
		return false;
	}
	else
	{
		return ColCheck(mat1,mat2,row,col-1);
	}
} 
bool checkEqual(int ** matrix1, int** matrix2, int row, int column)
{
	if (row==0)
	{
		return true;
	}
	if (!ColCheck(matrix1,matrix2,row,column))
	{
		return false;
	}
	else
	{
		return checkEqual(matrix1,matrix2,row-1,column);
	}
}
void col(int **array, int row, int column, int &evenSum, int &oddSum)
{
	if (column!=-1)
	{
		if (array[row][column]%2==0)
		{
			evenSum+=array[row][column];
		}
		else
		{
			oddSum+=array[row][column];
		}
		col(array,row,column-1,evenSum,oddSum);
	}
}
int calculateSum(int **array, int row, int column, int &evenSum, int &oddSum)
{
	if (row!=-1)
	{
		col(array,row,column,evenSum,oddSum);
		calculateSum(array,row-1,column,evenSum,oddSum);
	}
}
void PrintChar(char s,int l, fstream &output)
{
	if (l<=0)
	{
		return;
	}
	else
	{
		output<<s;
		PrintChar(s,l-1,output);
	}
}
void printPattern1(int start, int end, fstream &output)
{
	if (start>=end)
	{
		return;
	}
	else
	{
		PrintChar(' ',start,output);
		output<<"*"<<endl;
		printPattern1(start+1,end-1,output);
		if (start!=end-1)
		{
			PrintChar(' ',start,output);
			output<<"*"<<endl;
		}
	}
}

void printPattern2(int mline, int startLine, int space, fstream &output)
{
	if (mline<2)
	{
		return;
	}
	else
	{
		PrintChar(' ',startLine,output);
		output<<"*";
		PrintChar(' ',space+1,output);
		if (mline!=2)
		{
			output<<"*";
		}
		output<<endl;
		printPattern2(mline-1,startLine+1,space-2,output);
		if (mline!=2)
		{
			PrintChar(' ',startLine,output);
			output<<"*";
			PrintChar(' ',space+1,output);
			output<<"*";
			output<<endl;
		}
	}
}

void printPattern3(int sp, int mLine, fstream &output)
{
	if (mLine<0)
	{
		return;
	}
	else
	{
		PrintChar(' ',mLine+1,output);
		PrintChar('*',sp,output);
		output<<endl;
		printPattern3(sp+2,mLine-1,output);
		if (mLine!=0)
		{
			PrintChar(' ',mLine+1,output);
			PrintChar('*',sp,output);
			output<<endl;
		}
	}
}
long permutate(int n, int r)
{
	if (r<1)
	{
		return 1;
	}
	else
	{
		return n*permutate(n-1,r-1);
	}
}
void Col(int Row,int column,int size,int arr[],int **sumTriangle,bool check=true)
{
	if (column<size)
	{
		return;
	}
	else
	{
		if (check)
		{
			sumTriangle[Row][column]=arr[column]+arr[column-1];
		}
		else
		{
			sumTriangle[Row][column]=arr[column];
		}
		Col(Row,column-1,size,arr,sumTriangle,check);
		arr[column]=sumTriangle[Row][column];
		
	}
}
void printSumTriangle(int arr[], int size, int **sumTriangle, int row, int column)
{
	if (row<=0)
	{
		return;
	}
	else
	{
		if (row==column)
		{
			Col(row-1,column-1,column-size,arr,sumTriangle,false);
		}
		else
		{
			Col(row-1,column-1,column-size,arr,sumTriangle,true);
		}
		printSumTriangle(arr,size-1,sumTriangle,row-1,column);
	}
}
int wrappers(int Choco,int wrap)
{
	if (Choco<wrap)
	{
		return 0;
	}
	else
	{
		return (Choco/wrap)+wrappers((Choco/wrap)+(Choco%wrap),wrap);
	}
}
int countMaxChoco(int money, int price, int wrap)
{
	int Choco=0;
	Choco=money/price;
	Choco+=wrappers(Choco,wrap);
	return Choco;
}
void Row(int **board,int &N,int count)
{
	if (count>=2)
	{
		return;
	}
	else
	{
		Row(board,++N,count+1);
	}
}
bool solveNQUtil(int **board, int N, int col)
{
	if (col>=5)
	{
		return true;
	}
	else
	{
		if (col!=0)
		{
			Row(board,N,0);
		}
		if (N>=5)
		{
			N-=5;
		}
		board[N][col]=1;
		solveNQUtil(board,N,col+1);
	}
}
