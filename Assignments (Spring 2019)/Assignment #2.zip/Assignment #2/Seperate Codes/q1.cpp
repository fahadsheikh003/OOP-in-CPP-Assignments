#include<iostream>
using namespace std;
int find(int array[],int length,int target)
{
	if (length<0)
	{
		return -1;
	}
	else if (array[length]==target)
	{
		return length;
	}
	else
	{
		return find(array,length-1,target);
	}
}
