#include<iostream>
using namespace std;
void col(int **array, int row, int column, int &evenSum, int &oddSum)
{
	if (column!=-1)
	{
		if (array[row][column]%2==0)
		{
			evenSum+=array[row][column];
		}
		else
		{
			oddSum+=array[row][column];
		}
		col(array,row,column-1,evenSum,oddSum);
	}
}
int sum(int **array, int row, int column, int &evenSum, int &oddSum)
{
	if (row!=-1)
	{
		col(array,row,column,evenSum,oddSum);
		sum(array,row-1,column,evenSum,oddSum);
	}
}
/*
int main()
{
	int **arr=new int *[3];
	for (int a=0;a<3;a++)
	{
		arr[a]=new int [3];
		for (int b=0;b<3;b++)
		{
			arr[a][b]=2;
		}
	}
	int evenSum=0,oddSum=0;
	sum(arr,2,2,evenSum,oddSum);
	cout<<evenSum<<" "<<oddSum<<endl;
	for (int a=0;a<3;a++)
	{
		delete [] arr[a];
	}
	delete [] arr;
}
*/
