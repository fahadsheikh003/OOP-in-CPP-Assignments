#include<iostream>
using namespace std;
bool ColCheck(int **mat1,int **mat2,int row,int col)
{
	if (col==0)
	{
		return true;
	}
	if (mat1[row][col]!=mat2[row][col])
	{
		return false;
	}
	else
	{
		return ColCheck(mat1,mat2,row,col-1);
	}
} 
bool Mequal(int ** matrix1, int** matrix2, int row, int column)
{
	if (row==0)
	{
		return true;
	}
	if (!ColCheck(matrix1,matrix2,row,column))
	{
		return false;
	}
	else
	{
		return Mequal(matrix1,matrix2,row-1,column);
	}
}
/*int main()
{
	int x=1,y=2;
	int **mat1=new int *[2];
	int **mat2=new int *[2];
	for (int a=0;a<2;a++)
	{
		mat1[a]=new int [2];
		mat2[a]=new int [2];
		for (int b=0;b<2;b++)
		{
			mat1[a][b]=x;
			mat2[a][b]=y;
		}
	}
	cout<<Mequal(mat1,mat2,1,1)<<endl;
	for (int a=0;a<2;a++)
	{
		delete [] mat1[a];
		delete [] mat2[a];
	}
	delete [] mat1;
	delete [] mat2;
}*/
