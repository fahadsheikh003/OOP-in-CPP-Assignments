#include<iostream>
using namespace std;
bool Col(char **b,int r,int c,int x)
{
	if (x!=c)
	{
		if (x<0)
		{
			return true;
		}
		else if (b[r][x]!=32)
		{
			return false;
		}
	}
	return Col(b,r,c,x-1);
}
bool Row(char **b,int r,int c,int x)
{
	if (x!=r)
	{
		if (x<0)
		{
			return true;
		}
		else if (b[x][c]!=32)
		{
			return false;
		}
	}
	return Row(b,r,c,x-1);
}
bool Diag1(char **b,int r,int c)
{
	if (r<0 || c<0)
	{
		return true;
	}
	else if (b[r][c]!=32)
	{
		return false;
	}
	else
	{
		
		return Diag1(b,r-1,c-1);
	}
}
bool Diag2(char **b,int r,int c)
{
	if (r>=5 || c>=5)
	{
		return true;
	}
	else if (b[r][c]!=32)
	{
		return false;
	}
	else
	{
		return Diag1(b,r+1,c+1);
	}
}
bool Diag3(char **b,int r,int c)
{
	if (r>=5 || c<0)
	{
		return true;
	}
	else if (b[r][c]!=32)
	{
		return false;
	}
	else
	{
		return Diag1(b,r+1,c-1);
	}
}
bool Diag4(char **b,int r,int c)
{
	if (r<0 || c>=5)
	{
		return true;
	}
	else if (b[r][c]!=32)
	{
		return false;
	}
	else
	{
		return Diag1(b,r-1,c+1);
	}
}
bool solveNQUtil(char **b,int n=4,int col=0)
{
	if (col==5)
	{
		col=0;
		n--;
	}
	if (n<0)
	{
		return true;
	}
	else
	{
		if (Col(b,n,col,4) && Row(b,n,col,4) && Diag1(b,n-1,col-1) && Diag3(b,n+1,col-1))
		{
			b[n][col]='*';
		}
		return solveNQUtil(b,n,col+1);
	}
}
int main()
{
	char **board=new char *[5];
	for (int a=0;a<5;a++)
	{
		board[a]=new char [5];
		for (int b=0;b<5;b++)
		{
			board[a][b]=32;
		}
	}
	if(solveNQUtil(board,4,0))
	{
		for (int a=0;a<5;a++)
		{
			for (int b=0;b<5;b++)
			{
				cout<<board[a][b]<<" ";
			}
			cout<<endl;
		}
	}
}
