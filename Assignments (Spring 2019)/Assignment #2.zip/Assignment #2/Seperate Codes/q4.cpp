#include<iostream>
#include<cmath>
#include<iomanip>
using namespace std;
float PiValue(int n)
{
	if (n%2==0)
	{
		PiValue(n-1);
	}
	else
	{
		float S=0;
		if (n<=1)
		{
			return 4;
		}
		S+=PiValue(n-4);
		S-=4*(1/(float)(n-2));
		S+=4*(1/(float)(n));
		return S;
	}
}
int main()
{
	cout<<setprecision(20)<<PiValue(5)<<endl;
}
