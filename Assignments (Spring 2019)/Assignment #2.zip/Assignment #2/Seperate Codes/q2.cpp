#include<iostream>
using namespace std;
bool checkPrime(int n,int x)
{
	if (n==x)
	{
		return true;
	}
	if (x!=0 && x!=1)
	{
		if (n%x==0)
			return false;
	}
	return checkPrime(n,x+1);
}
