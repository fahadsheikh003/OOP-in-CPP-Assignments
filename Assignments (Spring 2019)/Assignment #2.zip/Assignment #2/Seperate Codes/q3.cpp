#include<iostream>
using namespace std;
char UpperCasefind(char * X)
{
	if (*X==0 || (*X>=65 && *X<=90))
	{
		return *X;
	}
	UpperCasefind(X+1);
}
