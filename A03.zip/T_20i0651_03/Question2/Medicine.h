//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>

using namespace std;

class Medicine
{
	int ID;
	string name;

public:
	Medicine();
	void setData(int, string);
	void setID(int);
	int getID();
	void setname(string);
	string getname();
};