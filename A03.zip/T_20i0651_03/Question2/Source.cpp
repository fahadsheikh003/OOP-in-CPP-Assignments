//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Source Program)

#include<iostream>
#include<iomanip>
#include<ctime>
#include"Medical_Institute.h"
#include"Patient.h"
#include"Medical_Visit.h"
#include"Medicine.h"
#include"Doctor.h"
#include"PHR.h"
#include"System.h"

#pragma warning(disable:4996)

using namespace std;

//Medical Institutes
Medical_Institute::Medical_Institute() : ID(0), name("NULL") {};

void Medical_Institute::setData(int ID, string name)
{
	this->ID = ID;
	this->name = name;
}

int Medical_Institute::getID() 
{ 
	return ID; 
}

string Medical_Institute::getname() 
{ 
	return name; 
}

//Patient
Patient::Patient() : ID(0), name("NULL"), myPHR{} {};

void Patient::setData(int id, string name)
{
	ID = id;
	this->name = name;
}

int Patient::getID()
{
	return ID;
}

string Patient::getname()
{
	return name;
}

void Patient::setPHR(PHR &P)
{
	myPHR = &P;
}

PHR* Patient::getPHR()
{
	return myPHR;
}

PHR* Patient::PHRAccessRequest(int id)
{
	int size = myPHR->getdocsize();
	Doctor* doctors = myPHR->getdoctors();
	for (int i = 0; i < size; i++)
	{
		if (doctors[i].getID() == id)
		{
			cout << "Access Granted!\n";
			return myPHR;
		}
	}

	Patient* X=new Patient;
	X->setData(-1, "NULL");
	PHR* x=new PHR;
	x->setData(-1, *X);
	X->setPHR(*x);

	cout << "Access Denied!\n";
	return x;
}

//Medical Visit
int Medical_Visit::mvbase = 0;

Medical_Visit::Medical_Visit() : ID(0), Time("NULL"), doc{}, med{} {};

void Medical_Visit::setData(Doctor doc, Medicine med)
{
	this->ID = mvbase++;
	this->doc = doc;
	this->med = med;
}

void Medical_Visit::setID() 
{ 
	this->ID = mvbase++; 
}

int Medical_Visit::getID() 
{ 
	return ID; 
}

Doctor Medical_Visit::getDoctor() 
{ 
	return this->doc; 
}

Medicine Medical_Visit::getMedicine() 
{ 
	return this->med; 
}

void Medical_Visit::setTime()
{
	time_t dt = time(nullptr);

	Time = ctime(&dt);
}

string Medical_Visit::getTime()
{
	return Time;
}

//Medicine
Medicine::Medicine() : ID(0), name("NULL") {};

void Medicine::setData(int ID, string name)
{
	this->ID = ID;
	this->name = name;
}

void Medicine::setID(int id) 
{ 
	this->ID = id;
}

int Medicine::getID()
{ 
	return ID; 
}

void Medicine::setname(string name) 
{ 
	this->name = name; 
}

string Medicine::getname() 
{ 
	return name; 
}

//Doctor
Doctor::Doctor() : ID(0), name("NULL"), Employer{} {};

void Doctor::setData(int ID, string name, Medical_Institute mi)
{
	this->ID = ID;
	this->name = name;
	Employer = mi;
}

int Doctor::getID()
{
	return ID;
}

string Doctor::getname()
{
	return name;
}

PHR* Doctor::getPHRAccess(Patient P)
{
	PHR* phr=P.PHRAccessRequest(this->ID);

	return phr;
}

//PHR
PHR::PHR() :ID(0), patient{}, med_visits{}, doctors{}, medicines{}, mvindex(0), docindex(0), medindex(0) {};

void PHR::setData(int id, Patient& P)
{
	ID = id;
	patient = &P;
}

void PHR::setID(int id)
{
	ID = id;
}

int PHR::findDocindex(int id)
{
	for (int i = 0; i < docindex; i++)
	{
		if (doctors[i].getID() == id)
		{
			return i;
		}
	}
	return -1;
}

void PHR::addDoc(Doctor D)
{
	bool check = false;
	for (int i = 0; i < docindex; i++)
	{
		if (doctors[i].getID() == D.getID())
			check = true;
	}
	if (check)
	{
		cout << D.getname() << " is already in " << patient->getname() << "'s Doctor list.\n";
		return;
	}
	
	Doctor* temp = new Doctor[docindex + 1];
	for (int i = 0; i < docindex; i++)
	{
		temp[i] = doctors[i];
	}
	temp[docindex] = D;

	cout << "\n" << D.getname() << " added successfully to " << patient->getname() << "'s Doctor list.\n";

	if (docindex != 0)
		delete[] doctors;
	doctors = temp;
	temp = nullptr;

	docindex++;
}

void PHR::addVisit(Medical_Visit mi)
{
	Medicine* T = new Medicine[medindex + 1];
	for (int i = 0; i < medindex; i++)
	{
		T[i] = medicines[i];
	}
	T[medindex].setData(mi.getMedicine().getID(), mi.getMedicine().getname());

	if (medindex != 0)
		delete[] medicines;
	medicines = T;
	T = nullptr;

	medindex++;

	Medical_Visit * temp = new Medical_Visit[mvindex + 1];
	for (int i = 0; i < mvindex; i++)
	{
		temp[i] = med_visits[i];
	}
	temp[mvindex] = mi;

	if (mvindex != 0)
		delete[] med_visits;
	med_visits = temp;
	temp = nullptr;

	mvindex++;
}

void PHR::removeDoctor(Doctor D)
{
	int index = findDocindex(D.getID());

	if (index == -1)
	{
		cout << "\nSorry! " << D.getname() << " is not in " << patient->getname() << "'s doctor list.\n";
		return;
	}
	else
	{
		for (int i = index; i < docindex - 1; i++)
		{
			doctors[i] = doctors[i + 1];
		}
		docindex--;
	}
	cout << endl << D.getname() << " removed successfully from " << patient->getname() << "'s Doctor list.\n";

}

void PHR::displayPHR()
{
	cout << "Patient Name: " << patient->getname() << "\t\tPatient ID: " << patient->getID() << endl;

	cout << endl << "Doctors List: " << endl;
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < docindex; i++)
	{
		cout << setw(10) << doctors[i].getID() << setw(30) << doctors[i].getname() << endl;
	}

	cout << endl;

	cout << endl << "Medicines List: " << endl;
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < medindex; i++)
	{
		cout << setw(10) << medicines[i].getID() << setw(30) << medicines[i].getname() << endl;
	}

	cout << endl;

	cout << endl << "List of Medical Visits: " << endl;
	cout << left << setw(10) << "ID" << setw(30) << "Doctor" << setw(20) << "Medicine"
		<< setw(25) << "Time" << endl;
	for (int i = 0; i < mvindex; i++)
	{
		cout << setw(10) << med_visits[i].getID() << setw(30) << med_visits[i].getDoctor().getname()
			<< setw(20) << med_visits[i].getMedicine().getname() 
			<< setw(25) << med_visits[i].getTime() << endl;
	}
}

int PHR::getdocsize()
{
	return docindex;
}

Doctor* PHR::getdoctors()
{
	return doctors;
}

int PHR::getID()
{
	return ID;
}

Patient* PHR::getpatient()
{
	return patient;
}

int PHR::getmvindex()
{
	return mvindex;
}

int PHR::getmedindex()
{
	return medindex;
}

Medicine* PHR::getmedicines()
{
	return medicines;
}

Medical_Visit* PHR::getmed_visits()
{
	return med_visits;
}

//System
void System::generateData()
{
	patindex = 10;
	docindex = 10;
	medindex = 3;//for medical institutes
	mindex = 10;//for medicines
	Patients = new Patient[patindex];
	phr = new PHR[patindex];
	Doctors = new Doctor[docindex];
	MedInstitutes = new Medical_Institute[medindex];
	Medicines = new Medicine[mindex];

	for (int i = 0; i < patindex; i++)
	{
		Patients[i].setData((i + 1) * 100, "Patient " + to_string(i + 1));
		phr[i].setData(Patients[i].getID(), Patients[i]);
		Patients[i].setPHR(phr[i]);
	}

	for (int i = 0; i < medindex; i++)
	{
		MedInstitutes[i].setData((i + 1) * 1111, "Hospital " + to_string(i + 1));
	}

	for (int i = 0; i < docindex; i++)
	{
		Doctors[i].setData(i + 1, "Doctor " + to_string(i + 1), MedInstitutes[rand() % medindex]);
	}

	for (int i = 0; i < mindex; i++)
	{
		Medicines[i].setData((i + 1) * 5, "Medicine " + to_string(i + 1));
	}
}

void System::displayGeneratedData()
{
	cout << "Generated Patients: \n";
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < patindex; i++)
	{
		cout << setw(10) << Patients[i].getID() << setw(30) << Patients[i].getname() << endl;
	}

	cout << endl << endl;

	cout << "Generated Medical Institutes: \n";
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < medindex; i++)
	{
		cout << setw(10) << MedInstitutes[i].getID() << setw(30) << MedInstitutes[i].getname() << endl;
	}

	cout << endl << endl;

	cout << "Generated Doctors: \n";
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < docindex; i++)
	{
		cout << setw(10) << Doctors[i].getID() << setw(30) << Doctors[i].getname() << endl;
	}

	cout << "Generated Medicines: \n";
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < mindex; i++)
	{
		cout << setw(10) << Medicines[i].getID() << setw(30) << Medicines[i].getname() << endl;
	}
}

void System::displaydoctors()
{
	cout << "List of all Doctors: \n";
	cout << left << setw(10) << "ID" << setw(30) << "Name" << endl;
	for (int i = 0; i < docindex; i++)
	{
		cout << setw(10) << Doctors[i].getID() << setw(30) << Doctors[i].getname() << endl;
	}
}

int System::findpatindex(int id)
{
	for (int i = 0; i < patindex; i++)
	{
		if (Patients[i].getID() == id)
		{
			return i;
		}
	}
	return -1;
}

int System::finddocindex(int id)
{
	for (int i = 0; i < docindex; i++)
	{
		if (Doctors[i].getID() == id)
		{
			return i;
		}
	}
	return -1;
}

int System::findmedindex(int id)
{
	for (int i = 0; i < mindex; i++)
	{
		if (Medicines[i].getID() == id)
		{
			return i;
		}
	}
	return -1;
}

void System::PatientLogin()
{
	int id;
againpatient:
	cout << "Enter ID of the patient to Login: ";
	cin >> id;

	int index = findpatindex(id);

	if (index == -1)
	{
		cout << "\nSorry! Patient not found.\n";
		goto againpatient;
	}

	int choice;
menu:
	do
	{
		cout << "Menu:\n"
			<< "Enter 1 to display PHR.\n"
			<< "Enter 2 to add a Doctor.\n"
			<< "Enter 3 to delete a doctor.\n"
			<< "Enter 4 to log out.\n"
			<< "Enter your choice: ";
		cin >> choice;
	} while (!(choice > 0 && choice < 5));

	switch (choice)
	{
	case 1:
	{
		Patients[index].getPHR()->displayPHR();
		goto menu;
	}
	case 2:
	{
		displaydoctors();
		int idx;
	againdoctor:
		cout << "Enter ID of doctor you want to add: ";
		cin >> idx;

		int dindex = finddocindex(idx);
		if (dindex == -1)
		{
			cout << "\nSorry! wrong ID. Please enter a valid ID.\n";
			goto againdoctor;
		}

		Patients[index].getPHR()->addDoc(Doctors[dindex]);

		goto menu;
	}
	case 3:
	{
		displaydoctors();
		int idx;
	againdoctor1:
		cout << "Enter ID of doctor you want to remove: ";
		cin >> idx;

		int dindex = finddocindex(idx);
		if (dindex == -1)
		{
			cout << "\nSorry! wrong ID. Please enter a valid ID.\n";
			goto againdoctor1;
		}

		Patients[index].getPHR()->removeDoctor(Doctors[dindex]);

		goto menu;
	}
	case 4:
	{
		return;
	}
	}
}

int System::DocAdvice()
{
	int id;
medagain:
	cout << "Enter ID of the Medicine: ";
	cin >> id;

	int index = findmedindex(id);
	if (index == -1)
	{
		cout << "\nMedicine not found.\n";
		goto medagain;
	}

	return index;
}

void System::DoctorLogin()
{
	int id;
docagain:
	cout << "Enter id of the Doctor to login: ";
	cin >> id;

	int index = finddocindex(id);
	if (index == -1)
	{
		cout << "\nSorry! Doctor not Found.\n";
		goto docagain;
	}

	int choice;
menu1:
	do
	{
		cout << "Menu:\n"
			<< "Enter 1 to treat a patient.\n"
			<< "Enter 2 to logout.\n"
			<< "Enter your choice: ";
		cin >> choice;
	} while (!(choice == 1 || choice == 2));

	switch (choice)
	{
	case 1:
	{
		int idx;
	patagain:
		cout << "Enter ID of the Patient you want to treat: ";
		cin >> idx;

		int pindex = findpatindex(idx);

		if (pindex == -1)
		{
			cout << "\nSorry! Patient not found.\n";
			goto patagain;
		}

		PHR* phr = Doctors[index].getPHRAccess(Patients[pindex]);

		if (phr->getpatient()->getID() == -1)
		{
			goto menu1;
		}

		phr->displayPHR();
		int mindex = DocAdvice();

		Medical_Visit mi;
		mi.setData(Doctors[index], Medicines[mindex]);
		mi.setTime();

		phr->addVisit(mi);

		goto menu1;
	}
	case 2:
	{
		return;
	}
	}

	
}

void System::Menu()
{
	generateData();
	displayGeneratedData();
	
	int choice;
menu2:
	do
	{
		cout << "Menu:\n"
			<< "Enter 1 to Login as a Patient.\n"
			<< "Enter 2 to Login as a Doctor.\n"
			<< "Enter 3 to exit.\n"
			<< "Enter your choice: ";
		cin >> choice;
	} while (!(choice > 0 && choice < 4));

	switch (choice)
	{
	case 1:
	{
		PatientLogin();
		goto menu2;
	}
	case 2:
	{
		DoctorLogin();
		goto menu2;
	}
	case 3:
		exit(0);
	}
}

void System::Main()
{
	generateData();
	displayGeneratedData();

	srand(time(nullptr));

	int currentPatient = rand() % patindex;
	int addedDoctor = rand() % docindex;
	int addedMedicine = rand() % mindex;
	Medical_Visit mi;
	mi.setData(Doctors[addedDoctor], Medicines[addedMedicine]);
	mi.setTime();

	Patients[currentPatient].getPHR()->addDoc(Doctors[addedDoctor]);

	Patients[currentPatient].getPHR()->displayPHR();

	Patients[currentPatient].getPHR()->addVisit(mi);

	cout << "Another medical visit took place; added to PHR. Displaying updated PHR:\n";

	Patients[currentPatient].getPHR()->displayPHR();

	cout << "Doctor visited (ID " << Doctors[addedDoctor].getID() << ") requested access to PHR of patient ID " << Patients[currentPatient].getID() << ".\n";
	
	PHR* acc = Doctors[addedDoctor].getPHRAccess(Patients[currentPatient]);

	if (acc->getID() == -1)
		cout << "Access Denied\n";
	else
		cout << "Access Granted\n";

	int unknownPatient;

	do
	{
		unknownPatient = rand() % patindex;
	} while (unknownPatient == currentPatient);

	cout << "Doctor (ID " << Doctors[addedDoctor].getID() << ") requested access to PHR of patient that does not have this doctor on their PHR, Patient ID: " << Patients[unknownPatient].getID() << ".\n";

	acc = Doctors[addedDoctor].getPHRAccess(Patients[unknownPatient]);

	if (acc->getID() == -1)
		cout << "Access Denied\n";
	else
		cout << "Access Granted\n";

	Patients[currentPatient].getPHR()->removeDoctor(Doctors[addedDoctor]);

	cout << "Doctor visited (ID " << Doctors[addedDoctor].getID() << ") requested access to PHR of patient ID " << Patients[currentPatient].getID() << ".\n";

	acc = Doctors[addedDoctor].getPHRAccess(Patients[currentPatient]);

	if (acc->getID() == -1)
		cout << "Access Denied\n";
	else
		cout << "Access Granted\n";
}

System::~System()
{
	int x;
	for (int i = 0; i < patindex; i++)
	{
		delete[] phr[i].getdoctors(), phr[i].getmed_visits(),
			phr[i].getmedicines();
	}

	delete[] Medicines, MedInstitutes, Doctors, Patients, phr;
}

int main()
{
	System S1;
	
	//call S1.Menu() if you to simulate by yourself
	//call S1.Main() if you to check random simulation (as prescribed in phr.txt) 

	//S1.Menu();

	S1.Main();
}