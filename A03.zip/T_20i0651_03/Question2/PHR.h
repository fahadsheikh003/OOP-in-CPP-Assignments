//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>
#include"Medical_Institute.h"
#include"Patient.h"
#include"Medical_Visit.h"
#include"Medicine.h"
#include"Doctor.h"
#include"PHR.h"

using namespace std;

class Patient;

class PHR
{
	int ID;
	Patient* patient;
	Medical_Visit* med_visits;//array of medical visit objects
	Doctor* doctors; //list of doctors who this patient sees. Not necessary that all past visited doctors are in this list; patient can add and remove, so this is not redundant
	Medicine* medicines; //list of current medications.
	int mvindex, docindex, medindex;

public:
	PHR();

	void setData(int, Patient&);

	void setID(int);

	int findDocindex(int);

	void addDoc(Doctor);

	void addVisit(Medical_Visit);

	void removeDoctor(Doctor);

	void displayPHR();

	int getdocsize();

	Doctor* getdoctors();

	int getID();

	Patient* getpatient();

	int getmvindex();

	int getmedindex();

	Medicine* getmedicines();

	Medical_Visit* getmed_visits();
};
