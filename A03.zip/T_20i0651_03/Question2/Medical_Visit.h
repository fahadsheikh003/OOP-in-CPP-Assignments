//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>
#include"Doctor.h"
#include"Medicine.h"

using namespace std;

class Medical_Visit
{
	int ID;
	static int mvbase;
	string Time;//(either create Time class or use any representation of your choice to represent both date and time)
	Doctor doc;
	Medicine med; //assume only a single medicine prescribed in each visit

public:
	Medical_Visit();
	void setData(Doctor, Medicine);
	void setID();
	void setTime();
	int getID();
	Doctor getDoctor();
	Medicine getMedicine();
	string getTime();

	
};