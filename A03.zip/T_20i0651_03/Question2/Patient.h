//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>
#include"PHR.h"

using namespace std;

class Patient
{
	int ID;
	string name;
	PHR* myPHR;
public:
	Patient();

	void setData(int, string);

	int getID();

	string getname();

	void setPHR(PHR&);

	PHR* getPHR();

	//void addDocToPHR(Doctor);
	PHR* PHRAccessRequest(int);
};