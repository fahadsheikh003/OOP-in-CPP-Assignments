//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>

using namespace std;

class Medical_Institute
{
	int ID;
	string name;

public:
	Medical_Institute();

	void setData(int, string);

	int getID();

	string getname();
};