//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>
#include"Medical_Institute.h"
#include"Patient.h"
#include"Medical_Visit.h"
#include"Medicine.h"
#include"Doctor.h"
#include"PHR.h"

using namespace std;

class System
{
	Patient* Patients;
	PHR* phr;
	Doctor* Doctors;
	Medical_Institute* MedInstitutes;
	Medicine* Medicines;
	int patindex, docindex, medindex, mindex;

public:
	void generateData();

	void displayGeneratedData();

	void displaydoctors();

	int DocAdvice();

	int findpatindex(int);

	int finddocindex(int);

	int findmedindex(int);

	void PatientLogin();

	void DoctorLogin();

	void Menu();

	void Main();

	~System();
};