//Fahad Waheed	20I-0651
//Problem 2 of Assignment 3 (Header File)

#pragma once
#include<string>
#include"Medical_Institute.h"
#include"PHR.h"

using namespace std;

class PHR;
class Patient;

class Doctor
{
	int ID;
	string name;
	Medical_Institute Employer;// (i.e. medical institute).

public:
	Doctor();
	
	void setData(int, string, Medical_Institute);

	int getID();

	string getname();

	PHR* getPHRAccess(Patient);
};