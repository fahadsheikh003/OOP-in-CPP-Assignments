//Fahad Waheed	20I-0651
//Problem 5 of Assignment 3 (Source Program)

#include<iostream>
#include<iomanip>
#include<string>
#include"Matrix.h"

using namespace std;

Matrix::Matrix() : row(0), col(0), array{} {};

Matrix::Matrix(int r, int c) : row(r), col(c)
{
	array = new int* [r];
	for (int i = 0; i < r; i++)
		array[i] = new int[c];
}

Matrix::Matrix(const Matrix& M)
{
	this->row = M.row;
	this->col = M.col;

	array = new int* [row];
	for (int i = 0; i < row; i++)
	{
		array[i] = new int[col];
	}

	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
		{
			array[i][j] = M.array[i][j];
		}
	}
}

void Matrix::createMatrix(int r, int c)
{
	row = r;
	col = c;
	array = new int* [r];
	for (int i = 0; i < r; i++)
		array[i] = new int[c];
}

void Matrix::display()
{
	for (int i = 0; i < row; i++)
	{
		for (int j = 0; j < col; j++)
			cout << left << setw(5) << array[i][j] << "     ";
		cout << endl << endl;
	}
}

void Matrix::setdatastring(string str)
{
	int s = str.length();

	int r = 0;
	int j = 0, k = 0;
	for (int i = 0; i < s + 1; i++)
	{
		if (str[i] == ',' || str[i] == '\0')
		{
			this->array[j][k] = r;
			r = 0;
			k++;

			if ((k == this->col) && (j == this->row))
			{
				break;
			}

			if (k == this->col)
			{
				k = 0;
				j++;
			}

			continue;
		}
		else//Converting ASCII into digits and then digits into number 
		{
			r = r * 10 + (int(str[i]) - 48);
		}
	}
}

void Matrix::setdata()
{
	for (int i = 0; i < this->row; i++)
	{
		for (int j = 0; j < this->col; j++)
		{
			cout << "Enter number at row " << i + 1 << " & column " << j + 1 << " : ";
			cin >> this->array[i][j];
		}
	}
}

Matrix Matrix::operator+(const Matrix& T)
{
	Matrix R;
	if (this->row == T.row && this->col == T.col)
	{
		R.row = this->row;
		R.col = this->col;
		R.array = new int* [R.row];
		for (int i = 0; i < R.row; i++)
			R.array[i] = new int[R.col];

		for (int i = 0; i < R.row; i++)
		{
			for (int j = 0; j < R.col; j++)
			{
				R.array[i][j] = this->array[i][j] + T.array[i][j];
			}
		}
	}
	else
		cout << "\nInvalid Operation!\n";

	return R;
}

Matrix Matrix::operator-(const Matrix& T)
{
	Matrix R;
	if (this->row == T.row && this->col == T.col)
	{
		R.row = this->row;
		R.col = this->col;
		R.array = new int* [R.row];
		for (int i = 0; i < R.row; i++)
			R.array[i] = new int[R.col];

		for (int i = 0; i < R.row; i++)
		{
			for (int j = 0; j < R.col; j++)
			{
				R.array[i][j] = this->array[i][j] - T.array[i][j];
			}
		}
	}
	else
		cout << "\nInvalid Operation!\n";

	return R;
}

Matrix Matrix::operator*(int x)
{
	Matrix R;

	R.row = this->row;
	R.col = this->col;
	R.array = new int* [R.row];
	for (int i = 0; i < R.row; i++)
		R.array[i] = new int[R.col];

	for (int i = 0; i < R.row; i++)
	{
		for (int j = 0; j < R.col; j++)
		{
			R.array[i][j] = this->array[i][j] * x;
		}
	}

	return R;
}

Matrix Matrix::operator*(const Matrix& T)
{
	Matrix R;
	if (this->col == T.row)
	{
		R.row = this->row;
		R.col = T.col;

		R.array = new int* [R.row];
		for (int i = 0; i < R.row; i++)
			R.array[i] = new int[R.col];

		for (int i = 0; i < R.row; i++)
		{
			for (int j = 0; j < R.col; j++)
			{
				R.array[i][j] = 0;
				for (int k = 0; k < this->col; k++)
				{
					R.array[i][j] += this->array[i][k] * T.array[k][j];
				}
			}
		}
	}
	else
		cout << "\nInvalid Operation!\n";

	return R;
}

bool Matrix::operator==(const Matrix& T)
{
	if (this->row != T.row && this->col != T.col)
		return false;

	for (int i = 0; i < this->row; i++)
		for (int j = 0; j < this->col; j++)
			if (this->array[i][j] != T.array[i][j])
				return false;

	return true;

}

void Matrix::operator++()
{
	for (int i = 0; i < this->row; i++)
		for (int j = 0; j < this->col; j++)
			++this->array[i][j];
}

void Matrix::operator++(int)
{
	for (int i = 0; i < this->row; i++)
		for (int j = 0; j < this->col; j++)
			this->array[i][j]++;
}

Matrix Matrix::operator=(Matrix& T)
{
	this->row = T.row;
	this->col = T.col;

	int** newdata = new int* [this->row];
	for (int i = 0; i < this->row; i++)
		newdata[i] = new int[this->col];

	for (int i = 0; i < this->row; i++)
		for (int j = 0; j < this->col; j++)
			newdata[i][j] = T.array[i][j];

	delete[] array;
	array = newdata;
	newdata = nullptr;

	return *this;
}

int Matrix::getrow()
{
	return row;
}

int Matrix::getcol()
{
	return col;
}

Matrix::~Matrix()
{
	for (int i = 0; i < this->row; i++)
		delete[] array[i];
	delete[] array;
}

int main()
{
	Matrix M1, M2;
	int r, c;

	cout << "Enter number of rows of Matrix 1: ";
	cin >> r;

	cout << "Enter number of columns of Matrix 1: ";
	cin >> c;

	M1.createMatrix(r, c);

	cout << "Enter number of rows of Matrix 1: ";
	cin >> r;

	cout << "Enter number of columns of Matrix 1: ";
	cin >> c;

	M2.createMatrix(r, c);

	int choice;
	do
	{
		cout << "Enter 1 if you to enter data in form of string (comma seperated).\n"
			<< "Enter 2 if you enter data element by element.\n"
			<< "Enter your choice: ";
		cin >> choice;
	} while (!(choice == 1 || choice == 2));

	switch (choice)
	{
	case 1:
	{
		cin.ignore();
		string str;
		cout << "Please enter the values of matrix 1 (comma separated: e.g; 4,5,6,7,8,9): ";
		getline(cin, str);
		cout << endl;
		M1.setdatastring(str);
		M1.display();

		cout << endl;

		cout << "Please enter the values of matrix 2 (comma separated: e.g; 4,5,6,7,8,9): ";
		getline(cin, str);
		cout << endl;
		M2.setdatastring(str);
		M2.display();

		break;
	}
	case 2:
	{
		cout << "Please enter the values of matrix 1 (element by element): ";
		M1.setdata();
		M1.display();

		cout << "Please enter the values of matrix 2 (element by element): ";
		M2.setdata();
		M2.display();
	}
	}


	Matrix M3 = M1 + M2;
	cout << "Sum of Matrix M1 & M2: \n";
	M3.display();
	cout << endl << endl;

	Matrix M4 = M1 - M2;
	cout << "Difference of Matrix M1 & M2: \n";
	M4.display();
	cout << endl << endl;

	cout << "M1: \n";
	M1.display();
	Matrix M5 = M1 * 4;
	cout << "Multiplication of Matrix M1 with 4: \n";
	M5.display();
	cout << endl << endl;

	cout << "M1: \n";
	M1.display();
	cout << "M2: \n";
	M2.display();
	Matrix M6 = M1 * M2;
	cout << "Multiplication of Matrix M1 & M2: \n";
	M6.display();
	cout << endl << endl;

	Matrix M7 = M1;

	cout << "M1: \n";
	M1.display();
	cout << "M7: \n";
	M7.display();
	if (M1 == M7)
		cout << "\nMatrix M1 & M7 are equal.\n";
	else
		cout << "\nMatrix M1 & M7 aren't equal.\n";
	cout << endl << endl;


	cout << "Before Pre-Increment of M2: \n";
	M2.display();
	++M2;
	cout << "After Pre-Increment of M2: \n";
	M2.display();
	cout << endl << endl;

	cout << "Before Post-Increment of M1: \n";
	M1.display();
	M1++;
	cout << "After Post-Increment of M1: \n";
	M1.display();
	cout << endl << endl;
}