//Fahad Waheed	20I-0651
//Problem 5 of Assignment 3 (Header File)

#pragma once
#include<string>

using namespace std;

class Matrix
{
	int row, col;
	int** array;

public:
	Matrix();
	Matrix(int, int);
	Matrix(const Matrix&);
	void createMatrix(int, int);
	void display();
	void setdatastring(string);
	void setdata();
	Matrix operator+(const Matrix&);
	Matrix operator-(const Matrix&);
	Matrix operator*(int);
	Matrix operator*(const Matrix&);
	bool operator==(const Matrix&);
	void operator++();
	void operator++(int);
	Matrix operator=(Matrix&);
	int getrow();
	int getcol();
	~Matrix();

};