#pragma once

using namespace std;

class ArrayInt
{
	int size;
	int* array;

public:
	ArrayInt();
	ArrayInt(int);
	ArrayInt(const ArrayInt&);
	ArrayInt operator=(const ArrayInt&);
	void Copy(int*);
	void makeNull();
	void initialise(int);
	int getIndex(int);
	int sum();
	double average();
	bool contains(int);
	int getIndexOf(int);
	int getElement(int);
	int* getSubArray(int a, int b);
	void sort();
	void reverse();
	ArrayInt operator+(const ArrayInt& T);
	ArrayInt operator*(const ArrayInt& T);
	bool operator==(ArrayInt& T);
	bool operator>(ArrayInt& T);
	void display();
	int getsize();
	int* getarray();
	~ArrayInt();
};