//Fahad Waheed	20I-0651
//Problem 4 of Assignment 3 (Source Program)

#include<iostream>
#include"ArrayInt.h"

using namespace std;

ArrayInt::ArrayInt() :size(0), array{} {};

ArrayInt::ArrayInt(int i)
{
	size = i;
	array = new int[size];
}

ArrayInt::ArrayInt(const ArrayInt& T)
{
	this->size = T.size;
	this->array = new int[this->size];

	for (int i = 0; i < this->size; i++)
	{
		this->array[i] = T.array[i];
	}
}

ArrayInt ArrayInt::operator=(const ArrayInt& T)
{
	int* newdata = new int[T.size];
	//copy(T.array, T.array + T.size, newdata);
	for (int i = 0; i < T.size; i++)
	{
		newdata[i] = T.array[i];
	}
	delete[] array;
	array = newdata;
	newdata = nullptr;
	size = T.size;
	return *this;
}

void ArrayInt::Copy(int* arr)
{
	for (int i = 0; i < size; i++)
	{
		array[i] = arr[i];
	}
}

void ArrayInt::makeNull()
{
	if (size > 0)
		delete[] array;
	array = nullptr;
	size = 0;
}

void ArrayInt::initialise(int x)
{
	for (int i = 0; i < size; i++)
	{
		array[i] = x;
	}
}

int ArrayInt::getIndex(int x)
{
	if (x < size && x >= 0)
	{
		return array[x];
	}
	else
	{
		cout << "\nInvalid index!\n";
		return -1;
	}
}

int ArrayInt::sum()
{
	int s = 0;
	for (int i = 0; i < size; i++)
	{
		s += array[i];
	}
	return s;
}

double ArrayInt::average()
{
	return double(sum()) / size;
}

bool ArrayInt::contains(int x)
{
	for (int i = 0; i < size; i++)
	{
		if (array[i] == x)
			return true;
	}
	return false;
}

int ArrayInt::getIndexOf(int x)
{
	for (int i = 0; i < size; i++)
	{
		if (array[i] == x)
			return i;
	}
	return -1;
}

int ArrayInt::getElement(int x)
{
	if (x < size && x >= 0)
	{
		return array[x];
	}
	else
	{
		cout << "\nInvalid index!\n";
		return -1;
	}
}

int* ArrayInt::getSubArray(int a, int b)
{
	if (a < size && b < size && a >= 0 && b >= a)
	{
		int* arr = new int[b - a + 1];

		for (int i = a, k = 0; i <= b; i++, k++)
		{
			arr[k] = array[i];
		}
		return arr;
	}
	else
	{
		cout << "\nInvalid operation!\n";
	}

	return nullptr;
}

void ArrayInt::sort()
{
	int temp;
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = 0; j < size - i - 1; j++)
		{
			if (array[j] > array[j + 1])
			{
				temp = array[j];
				array[j] = array[j + 1];
				array[j + 1] = temp;
			}
		}
	}
}

void ArrayInt::reverse()
{
	int* rev = new int[size];

	for (int i = 0, j = size - 1; i < size; i++, j--)
	{
		rev[j] = array[i];
	}

	delete[] array;
	array = rev;
	rev = nullptr;
}

ArrayInt ArrayInt::operator+(const ArrayInt& T)
{
	int s = this->size + T.size;
	ArrayInt R(s);

	for (int i = 0; i < this->size; i++)
	{
		R.array[i] = this->array[i];
	}

	for (int i = 0, j = this->size; i < T.size; i++, j++)
	{
		R.array[j] = T.array[i];
	}

	return R;
}

ArrayInt ArrayInt::operator*(const ArrayInt& T)
{
	if (this->size == T.size)
	{
		ArrayInt R(this->size);

		for (int i = 0; i < this->size; i++)
		{
			R.array[i] = this->array[i] * T.array[i];
		}

		return R;
	}

	else if (this->size < T.size)
	{
		ArrayInt R(T.size);

		for (int i = 0; i < this->size; i++)
		{
			R.array[i] = this->array[i] * T.array[i];
		}

		for (int i = this->size; i < T.size; i++)
		{
			R.array[i] = T.array[i];
		}

		return R;
	}

	else if (this->size > T.size)
	{
		ArrayInt R(this->size);

		for (int i = 0; i < T.size; i++)
		{
			R.array[i] = this->array[i] * T.array[i];
		}

		for (int i = T.size; i < this->size; i++)
		{
			R.array[i] = this->array[i];
		}

		return R;
	}
	else
	{
		ArrayInt R(0);
		return R;
	}
}

bool ArrayInt::operator==(ArrayInt& T)
{
	if (this->size != T.size)
		return false;

	for (int i = 0; i < this->size; i++)
		if (this->array[i] != T.array[i])
			return false;

	return true;
}

bool ArrayInt::operator>(ArrayInt & T)
{
	int sum1 = 0, sum2 = 0;

	for (int i = 0; i < this->size; i++)
	{
		sum1 += this->array[i];
	}

	for (int i = 0; i < T.size; i++)
	{
		sum2 += T.array[i];
	}

	if (sum1 > sum2)
		return true;
	else
		return false;
}

void ArrayInt::display()
{
	for (int i = 0; i < size; i++)
	{
		if (i == size - 1)
			cout << array[i];
		else
			cout << array[i] << ", ";
	}
}

int ArrayInt::getsize()
{
	return size;
}

int* ArrayInt::getarray()
{
	return array;
}

ArrayInt::~ArrayInt()
{
	delete[] array;
	array = nullptr;
}

int main()
{
	ArrayInt obj1(5), obj2(5), obj3(10), obj4(10);

	int arr1[] = { 5,3,0,5,4 }, arr2[] = { 9,5,1,5,8,7,0,1,9,3 };

	obj1.Copy(arr1);
	obj2.Copy(arr1);
	obj3.Copy(arr2);
	obj4.Copy(arr2);

	cout << "Array 1: ";
	obj1.display();
	cout << "\nArray 2: ";
	obj2.display();
	cout << "\nArray 3: ";
	obj3.display();
	cout << "\nArray 4: ";
	obj4.display();
	cout << endl;

	cout << endl << endl;

	if (obj1 == obj2)
	{
		obj1.display();
		cout << " & ";
		obj2.display();
		cout << " are equal.";
	}
	else
	{
		obj1.display();
		cout << " & ";
		obj2.display();
		cout << " aren't equal.";
	}

	cout << endl << endl;

	if (obj3 > obj1)
	{
		obj3.display();
		cout << " is greater than ";
		obj1.display();
	}
	else
	{
		obj3.display();
		cout << " is less than ";
		obj1.display();
	}

	cout << endl << endl;

	obj1.initialise(2);

	cout << endl << "Array 1 after initiallizing all elements with 2: ";
	obj1.display();

	cout << endl << "Element in Array 2 at index 2: " << obj2.getElement(2) << endl;

	cout << endl << "Sum of Array 1: " << obj1.sum() << endl;

	cout << endl << "Average of Array 1: " << obj1.average() << endl;

	cout << endl << "Array 2: ";
	obj2.display();
	cout << "\nChecking for availability of \"1\" in Array 2: ";
	if (obj2.contains(1))
	{
		cout << "found..";
	}
	else
	{
		cout << "not found..";
	}

	cout << endl << endl;

	cout << "\nArray 4: ";
	obj4.display();
	cout << endl;
	int* subarr = obj4.getSubArray(4, 8);
	int s = 8 - 4 + 1;
	cout << "Sub-array of Array 4 from index 4 to 8 is ";
	for (int i = 0; i < s; i++)
	{
		if (i == s - 1)
			cout << subarr[i];
		else
			cout << subarr[i] << ", ";
	}

	cout << endl << endl;

	cout << endl << "Array 2: ";
	obj2.display();
	cout << "\nIndex of 4 in Array 2: " << obj2.getIndexOf(4) << endl;

	cout << endl << endl;

	cout << endl << "Before sorting of Array 2: ";
	obj2.display();
	obj2.sort();
	cout << endl << "After sorting of Array 2: ";
	obj2.display();

	cout << endl << endl;

	cout << endl << "Initially Array 3: ";
	obj3.display();
	obj3.reverse();
	cout << endl << "After Reversing: ";
	obj3.display();

	ArrayInt obj5 = obj3 + obj4;

	cout << endl << endl;

	cout << "\nArray 3: ";
	obj3.display();
	cout << "\nArray 4: ";
	obj4.display();
	cout << endl;

	cout << "\n\nConcatenation of Array 3 & 4: ";
	obj5.display();

	ArrayInt obj6 = obj3 * obj4;

	cout << endl << endl;

	cout << "\nArray 3: ";
	obj3.display();
	cout << "\nArray 4: ";
	obj4.display();
	cout << endl;

	cout << "\n\nMultiplication of Array 3 & 4: ";
	obj6.display();

	cout << endl << endl << endl;
}