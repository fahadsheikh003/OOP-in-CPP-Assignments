//Fahad Waheed	20I-0651
//Problem 1 of Assignment 3 (Header File)

#pragma once
#include<string>

using namespace std;

class Item
{
	int ID, category;
	string name;

public:
	Item();
	Item(int, int, string);
	void setID(int);
	void setname(string);
	void setcategory(int);
	int getID();
	int getcategory();
	string getname();
};