//Fahad Waheed	20I-0651
//Problem 1 of Assignment 3 (Header File)

#pragma once
#include<string>
#include"Item.h"

using namespace std;

class Customer
{
	string name;
	static int base;
	int ID;
	Item* items;
	int itemsize;

public:
	Customer();
	Customer(string);
	void setname(string);
	void setID();
	void setitem(Item&);
	void purchaseitem(Item*, int);
	void addcustomer();
	Item* getitems();
	int getitemsize();
	int getID();
	string getname();
	int getbase();
	void setbase(int);
};