//Fahad Waheed	20I-0651
//Problem 1 of Assignment 3 (Source Program)

#include<iostream>
#include<ctime>
#include<cstdlib>
#include<iomanip>
#include"Customer.h"
#include"Item.h"

//member functions of Item class
Item::Item() : ID(0), category(0), name("NULL") {};

Item::Item(int i, int c, string s) : ID(i), category(c), name(s) {};

void Item::setID(int i)
{
	ID = i;
}

void Item::setname(string n)
{
	name = n;
}

void Item::setcategory(int c)
{
	category = c;
}

int Item::getID()
{
	return ID;
}

int Item::getcategory()
{
	return category;
}

string Item::getname()
{
	return name;
}

//member functions of Customer class
int Customer::base = 0;

Customer::Customer() : name("NULL"), ID(base++), itemsize(0)
{
	items = nullptr;
}

Customer::Customer(string n) : name(n), ID(base++), itemsize(0)
{
	items = nullptr;
}

void Customer::setname(string n)
{
	name = n;
}

void Customer::setID()
{
	ID = base++;
}

void Customer::setbase(int i)
{
	base = i;
}

void Customer::setitem(Item& item)
{
	Item* temparray = new Item[itemsize + 1];
	for (int i = 0; i < itemsize; i++)
	{
		temparray[i] = items[i];
	}
	
	temparray[itemsize].setcategory(item.getcategory());
	temparray[itemsize].setID(item.getID());
	temparray[itemsize].setname(item.getname());

	itemsize++;

	Item t;
	for (int i = 0; i < itemsize - 1; i++)
	{
		for (int j = 0; j < itemsize - i - 1; j++)
		{
			if (temparray[j].getcategory() > temparray[j + 1].getcategory())
			{
				t = temparray[j];
				temparray[j] = temparray[j + 1];
				temparray[j + 1] = t;
			}
		}
	}

	if (itemsize != 0)
		delete[] items;
	items = temparray;
	temparray = nullptr;
}

void Customer::purchaseitem(Item* allitems, int size)
{
	int temp;
againinputitem:
	cout << "Enter ID of Product you want to purchase: ";
	cin >> temp;

	int check = -1;
	for (int i = 0; i < size; i++)
	{
		if (temp == allitems[i].getID())
		{
			check = i;
			break;
		}
	}

	if (check == -1)
	{
		int a;
		cout << "\nSorry, " << temp << " not found!\n";
		
		goto againinputitem;
		cout << "Enter 1 if you want to purchase another product: ";
		cin >> a;

		if (a == 1)
		{
			goto againinputitem;
		}
		else
		{
			return;
		}
	}
	
	Item* temparray = new Item[itemsize + 1];
	for (int i = 0; i < itemsize; i++)
	{
		temparray[i] = items[i];
	}

	temparray[itemsize].setcategory(allitems[check].getcategory());
	temparray[itemsize].setID(allitems[check].getcategory());
	temparray[itemsize].setname(allitems[check].getname());

	itemsize++;

	Item t;
	for (int i = 0; i < itemsize - 1; i++)
	{
		for (int j = 0; j < itemsize - i - 1; j++)
		{
			if (temparray[j].getcategory() > temparray[j + 1].getcategory())
			{
				t = temparray[j];
				temparray[j] = temparray[j + 1];
				temparray[j + 1] = t;
			}
		}
	}

	if (itemsize != 0)
		delete[] items;
	items = temparray;
	temparray = nullptr;
}

void Customer::addcustomer()
{
	cout << "Enter name of customer: ";
	getline(cin, name);

	ID = base++;
	cout << "\nID assigned to Customer is " << ID << endl << endl;
}

Item* Customer::getitems()
{
	return items;
}

int Customer::getitemsize()
{
	return itemsize;
}

int Customer::getID()
{
	return ID;
}

int Customer::getbase()
{
	return base;
}

string Customer::getname()
{
	return name;
}

//Initial Data
Item* allitems()
{
	Item* array = new Item[30];

	int k = 0;
	for (int i = 0; i < 10; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			array[k].setcategory(i + 1);
			array[k].setID((k + 1) * 100);
			array[k].setname("Item " + to_string(k + 1));

			k++;
		}
	}

	return array;
}

Customer* allcustomers(Item * allitemsp, int n)
{
	Customer* array = new Customer[25];

	srand(time(nullptr));

	for (int i = 0; i < 25; i++)
	{
		array[i].setname("Customer " + to_string(i + 1));

		int k = -1;
		for (int j = 0; j < 2; j++)
		{
			k = rand() % n;
			array[i].setitem(allitemsp[k]);
		}
	}

	return array;
}

//Display Functions
void printallitems(Item * allitemsp, int n)
{
	cout << "List of all available products: \n";
	cout << left << setw(25) << "Name" << setw(8) << "ID" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << left << setw(25) << allitemsp[i].getname() << setw(8) << allitemsp[i].getID() << endl;	
	}
}

void printpreviousitems(Item * allitemsp, int n)
{
	cout << "List of all previously puchased products: \n";
	cout << left << setw(25) << "Name" << setw(8) << "ID" << endl;
	for (int i = 0; i < n; i++)
	{
		cout << left << setw(25) << allitemsp[i].getname() << setw(8) << allitemsp[i].getID() << endl;
	}
}

void printrecommendeditems(Customer C, Item * allitemsp, int sizep)
{
	Item* itemsp = C.getitems();
	int size = C.getitemsize();

	cout << "List of all recommended products: \n";
	cout << left << setw(25) << "Name" << setw(8) << "ID" << endl;
	bool check;
	for (int i = 0; i < size; i++)
	{
		check = false;
		for (int k = i + 1; k < size; k++)
		{
			if (itemsp[i].getID() == itemsp[k].getID())
			{
				check = true;
				break;
			}
			else if ((itemsp[i].getcategory() == itemsp[k].getcategory()) && (itemsp[i].getID() != itemsp[k].getID()))
			{
				check = true;
				break;
			}
		}

		if (check)
		{
			continue;
		}

		for (int j = 0; j < sizep; j++)
		{
			if ((itemsp[i].getcategory() == allitemsp[j].getcategory()) && (itemsp[i].getID() != allitemsp[j].getID()))
			{
				check = false;
				for (int k = 0; k < size; k++)
				{
					if (i == k)
						continue;

					else if (allitemsp[j].getID() == itemsp[k].getID())
					{
						check = true;
						break;
					}
				}

				if (check == false)
				{
					cout << left << setw(25) << allitemsp[j].getname() << setw(8) << allitemsp[j].getID() << endl;
				}
			}
		}
	}
}

//Logic Functions
int finditemindex(Item * allitemsp, int n, int id)
{
	for (int i = 0; i < n; i++)
	{
		if (allitemsp[i].getID() == id)
		{
			return i;
		}
	}
	return -1;
}

int findcustindex(Customer* allcustomersp, int n, int id)
{
	for (int i = 0; i < n; i++)
	{
		if (allcustomersp[i].getID() == id)
		{
			return i;
		}
	}
	return -1;
}

//Additional Function
void purchase(Customer * allcustomersp, int index, Item * allitemsp, int n)
{
	int id;
againx:
	cout << "Enter id of item you want to purchase: ";
	cin >> id;

	int x = finditemindex(allitemsp, n, id);

	if (x == -1)
		goto againx;

	allcustomersp[index].setitem(allitemsp[x]);
	cin.ignore();
	cout << "Item added successfully..\n";
	cout << "Press enter to continue..\n";
	cin.get();
}

int main()
{
	int numberofitems = 30;
	Item* allitemsp = allitems();
	int numberofcustomers = 25;
	Customer* allcustomersp = allcustomers(allitemsp, numberofitems);

	int id;
againid:
	cout << "Enter ID of customer to continue: ";
	cin >> id;
	int index = findcustindex(allcustomersp, numberofcustomers, id);
	if (index == -1)
	{
		cout << "\nWrong ID!\n";
		goto againid;
	}

	int choice;
menu:
	cout << "Customer name: " << allcustomersp[index].getname() << endl;
	cout << "Enter 1 to view all available items\n"
		<< "Enter 2 to view purchase history\n"
		<< "Enter 3 to view recommended items\n"
		<< "Enter 4 to login again(i.e.log out and log in as a different customer)\n"
		<< "Enter 5 to signup (i.e. add a new customer)\n"
		<< "Enter 6 to purchase an item\n"
		<< "Enter 7 to Exit\n"
		<< "Enter your choice: ";
	cin >> choice;
	while (!(choice > 0 && choice <= 7))
	{
		cout << "Please enter a valid input!\n";
		cout << "Enter 1 to view all available items\n"
			<< "Enter 2 to view purchase history\n"
			<< "Enter 3 to view recommended items\n"
			<< "Enter 4 to login again(i.e.log out and log in as a different customer)\n"
			<< "Enter 5 to signup (i.e. add a new customer)\n"
			<< "Enter 6 to purchase an item\n"
			<< "Enter 7 to Exit\n"
			<< "Enter your choice: ";
		cin >> choice;
	}

	switch (choice)
	{
	case 1:
	{
		printallitems(allitemsp, numberofitems);
		goto menu;
	}
	case 2:
	{
		printpreviousitems(allcustomersp[index].getitems(), allcustomersp[index].getitemsize());
		goto menu;
	}
	case 3:
	{
		printrecommendeditems(allcustomersp[index], allitemsp, numberofitems);
		goto menu;
	}
	case 4:
	{
		goto againid;
	}
	case 5:
	{
		int x = allcustomersp[0].getbase();
		Customer* tempC = new Customer[numberofcustomers + 1];
		for (int i = 0; i < numberofcustomers; i++)
		{
			tempC[i] = allcustomersp[i];
		}
		tempC[numberofcustomers].setbase(--x);
		tempC[numberofcustomers].setID();
		cin.ignore();
		
		tempC[numberofcustomers].addcustomer();

		srand(time(nullptr));
		int k = -1;
		for (int j = 0; j < 2; j++)
		{
			k = rand() % numberofitems;
			tempC[numberofcustomers].setitem(allitemsp[k]);
		}

		index = numberofcustomers;

		numberofcustomers++;
		delete[] allcustomersp;
		allcustomersp = tempC;
		tempC = nullptr;

		goto menu;
	}
	case 6:
	{
		purchase(allcustomersp, index, allitemsp, numberofitems);

		goto menu;
	}
	case 7:
	{
		exit(0);
	}
	}
}