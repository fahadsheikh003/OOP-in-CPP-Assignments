//Fahad Waheed	20I-0651
//Problem 3 of Assignment 3 (Header File)

#pragma once
#include<cstdlib>

using namespace std;

class Date
{
	int day, month, year;

public:
	Date();
	Date(int, int, int);
	void setday(int);
	void setmonth(int);
	void setyear(int);
	int getday();
	int getmonth();
	int getyear();
	int getdayNumber(int, int, int);
	int getnumberOfMDays(int, int);
	Date& operator-(Date&);
	void printdiff();
	void futuredate();
	void pastdate();
};