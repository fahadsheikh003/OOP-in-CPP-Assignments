//Fahad Waheed	20I-0651
//Problem 3 of Assignment 3 (Header File)

#pragma once
#include"Note.h"
#include"Date.h"

using namespace std;

class Calender
{
	int firstday, month, year, mdays;
	Note* notes;
	int nsize;

public:
	Calender();
	Calender(int, int);
	void dayNumber(int);
	string monthName();
	void numberOfMDays();
	void printCalendar();
	void addnote();
	void displaynotes();
	void deletenote();
	void editnote();
	void Menu();
};