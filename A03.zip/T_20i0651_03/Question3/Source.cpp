//Fahad Waheed	20I-0651
//Problem 3 of Assignment 3 (Source Program)

#include<iostream>
#include<iomanip>
#include<string>
#include<cstdlib>
#include<time.h>
#include"Calender.h"

#pragma warning(disable:4996)

using namespace std;

//member functions of Note class
Note::Note() : day(0), month(0), year(0), note("NULL") {};

void Note::setday(int d)
{
	day = d;
}

void Note::setmonth(int m)
{
	month = m;
}

void Note::setyear(int y)
{
	year = y;
}

void Note::setnote(string n)
{
	note = n;
}

int Note::getday()
{
	return day;
}

int Note::getmonth()
{
	return month;
}

int Note::getyear()
{
	return year;
}

string Note::getnote()
{
	return note;
}

//member functions of Date class
Date::Date() : day(0), month(0), year(0) {};

Date::Date(int d, int m, int y) : day(d), month(m), year(y) {};

void Date::setday(int d)
{
	day = d;
}

void Date::setmonth(int m)
{
	month = m;
}

void Date::setyear(int y)
{
	year = y;
}

int Date::getday()
{
	return day;
}

int Date::getmonth()
{
	return month;
}

int Date::getyear()
{
	return year;
}

int Date::getdayNumber(int k, int a, int b)//Zeller�s Rule
{
	/*
		According to Zeller�s rule, the year starts from March and ends with February.
		k is  the day of the month.
		m is the month number.
		D is the last two digits of the year.
		C is the first two digits of the year.
	*/

	int m = a, y = b;

	int D = y % 100;
	int C = y / 100;

	if (m == 1 || m == 2)
		m += 10;
	else
		m -= 2;

	int F = k + ((13 * m - 1) / 5) + D + (D / 4) + (C / 4) - (2 * C);

	if (F >= 0)
	{
		return (F % 7);
	}
	else if (F < 0)
	{
		int count = 0;
		for (int i = abs(F); ; i++)
		{
			if (i % 7 == 0)
			{
				return count;
			}
			else
				count++;
		}
	}

	return NULL;
}

int Date::getnumberOfMDays(int m, int y)
{
	switch (m - 1)
	{
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11:
	{
		return 31;
	}
	case 1:
	{
		if (y % 400 == 0 || (y % 4 == 0 && y % 100 != 0))
		{
			return 29;
		}
		else
		{
			return 28;
		}
	}
	case 3:
	case 5:
	case 8:
	case 10:
	{
		return 30;
	}
	}
}

Date& Date::operator-(Date& T)
{
	Date R;
	bool daycheck = false;
	R.day = this->day - T.day;
	if (R.day < 0)
	{
		daycheck = true;
	}

	bool monthcheck = false;
	R.month = this->month - T.month;
	if (R.month < 0)
	{
		monthcheck = true;
	}

	R.year = this->year - T.year;
	R.year = abs(R.year);

	if (monthcheck)
	{
		R.month += 12;
		R.year -= 1;
	}

	if (daycheck)
	{
		R.day += 30;
		R.month -= 1;
	}

	if (R.month == 0)
	{
		R.month = 12;
		R.year -= 1;
	}

	return R;
}

void Date::printdiff()
{
	int months = this->month + this->year * 12;

	cout << endl << months << " months & " << this->day << " days.\n";

	int days = this->day + months * 30;

	int weeks = days / 7;
	int weekdays = days % 7;

	cout << endl << weeks << " weeks & " << weekdays << " days.\n";
}

void Date::futuredate()
{
	int choice;
	cout << "Enter 1 if you want to enter number of weeks.\n"
		<< "Enter 2 if you want to enter number of months.\n"
		<< "Enter 3 if you want to enter number of days.\n"
		<< "Enter your choice: ";
	cin >> choice;
	while (!(choice > 0 && choice < 4))
	{
		cout << "Please enter valid input!\n";
		cout << "Enter 1 if you want to enter number of weeks.\n"
			<< "Enter 2 if you want to enter number of months.\n"
			<< "Enter 3 if you want to enter number of days.\n"
			<< "Enter your choice: ";
		cin >> choice;
	}

	int FD, ED;

	switch (choice)
	{
	case 1:
	{
		int x;
		cout << "Enter number of weeks: ";
		cin >> x;
		ED = x;
		FD = x * 7;

		break;
	}
	case 2:
	{
		int x;
		cout << "Enter number of months: ";
		cin >> x;

		ED = FD = x;

		break;
	}
	case 3:
	{
		int x;
		cout << "Enter number of days: ";
		cin >> x;

		ED = FD = x;

		break;
	}
	}


	switch (choice)
	{
	case 2:
	{
		int m = 0;
		m = FD + month;

		int n = 0;
		if (m >= 12)
		{
			n = m / 12;
			m = m % 12;
		}

		int y = year + n;

		int d = getnumberOfMDays(m, y);

		if (day < d)
			d = day;

		int c = getdayNumber(d, m, y);

		string days[] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

		cout << "Future date from ";
		cout << ED << " months from the start date " << day << " " << months[month - 1] << " " << year << " is " << days[c] << ", " << d << " " << months[m - 1] << " " << y;

		break;
	}

	case 1:
	case 3:
	{
		int offset1 = day;

		for (int i = month - 1; i > 0; i--)
		{
			offset1 += getnumberOfMDays(i, year);
		}

		int remdays = (year % 400 == 0 || year % 100 != 0 && year % 4 == 0) ? (366 - offset1) : (365 - offset1);

		int y, offset2;
		if (FD <= remdays)
		{
			y = year;
			offset2 = offset1 + FD;
		}

		else
		{
			FD -= remdays;
			y = year + 1;
			int ydays = (y % 400 == 0 || y % 100 != 0 && y % 4 == 0) ? 366 : 365;
			while (FD >= ydays)
			{
				FD -= ydays;
				y++;
				ydays = (y % 400 == 0 || y % 100 != 0 && y % 4 == 0) ? 366 : 365;
			}
			offset2 = FD;
		}

		int m, d;

		int i;
		for (i = 1; i <= 12; i++)
		{
			if (offset2 <= getnumberOfMDays(i, y))
				break;
			offset2 = offset2 - getnumberOfMDays(i, y);
		}

		d = offset2;
		m = i;

		int c = getdayNumber(d, m, y);

		string days[] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

		if (choice == 1)
		{
			cout << "Future date from ";
			cout << ED << " weeks from the start date " << day << " " << months[month - 1] << " " << year << " is " << days[c] << ", " << d << " " << months[m - 1] << " " << y;
		}
		else if (choice == 3)
		{
			cout << "Future date from ";
			cout << ED << " days from the start date " << day << " " << months[month - 1] << " " << year << " is " << days[c] << ", " << d << " " << months[m - 1] << " " << y;
		}
	}
	}
}

void Date::pastdate()
{
	int choice;
	cout << "Enter 1 if you want to enter number of weeks.\n"
		<< "Enter 2 if you want to enter number of months.\n"
		<< "Enter 3 if you want to enter number of days.\n"
		<< "Enter your choice: ";
	cin >> choice;
	while (!(choice > 0 && choice < 4))
	{
		cout << "Please enter valid input!\n";
		cout << "Enter 1 if you want to enter number of weeks.\n"
			<< "Enter 2 if you want to enter number of months.\n"
			<< "Enter 3 if you want to enter number of days.\n"
			<< "Enter your choice: ";
		cin >> choice;
	}

	int FD, ED;

	switch (choice)
	{
	case 1:
	{
		int x;
		cout << "Enter number of weeks: ";
		cin >> x;
		ED = x;
		FD = x * 7;

		break;
	}
	case 2:
	{
		int x;
		cout << "Enter number of months: ";
		cin >> x;

		ED = FD = x;

		break;
	}
	case 3:
	{
		int x;
		cout << "Enter number of days: ";
		cin >> x;

		ED = FD = x;

		break;
	}
	}

	switch (choice)
	{
	case 2:
	{
		int m = 0;
		m = FD + month;

		int n = 0;
		if (m >= 12)
		{
			n = m / 12;
			m = m % 12;
		}

		int y = year - n;

		int d = getnumberOfMDays(m, y);

		if (day < d)
			d = day;

		int c = getdayNumber(d, m, y);

		string days[] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

		cout << "Past date from ";
		cout << ED << " months from the start date " << day << " " << months[month - 1] << " " << year << " is " << days[c] << ", " << d << " " << months[m - 1] << " " << y;

		break;
	}
	case 1:
	case 3:
	{
		int offset1 = day;

		for (int i = month - 1; i > 0; i--)
		{
			offset1 += getnumberOfMDays(i, year);
		}

		int remdays = (year % 400 == 0 || year % 100 != 0 && year % 4 == 0) ? (366 - offset1) : (365 - offset1);

		int y, offset2;
		if (FD <= remdays)
		{
			y = year;
			offset2 = offset1 - FD;
		}

		else
		{
			FD -= remdays;
			y = year - 1;
			int ydays = (y % 400 == 0 || y % 100 != 0 && y % 4 == 0) ? 366 : 365;
			while (FD >= ydays)
			{
				FD -= ydays;
				y--;
				ydays = (y % 400 == 0 || y % 100 != 0 && y % 4 == 0) ? 366 : 365;
			}
			offset2 = FD;
		}

		int m, d;

		int i;
		for (i = 1; i <= 12; i++)
		{
			if (offset2 <= getnumberOfMDays(i, y))
				break;
			offset2 = offset2 - getnumberOfMDays(i, y);
		}

		d = offset2;
		m = i;

		int c = getdayNumber(d, m, y);

		string days[] = { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
		string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };

		if (choice == 1)
		{
			cout << "Past date from ";
			cout << ED << " weeks from the start date " << day << " " << months[month - 1] << " " << year << " is " << days[c] << ", " << d << " " << months[m - 1] << " " << y;
		}
		else if (choice == 3)
		{
			cout << "Past date from ";
			cout << ED << " days from the start date " << day << " " << months[month - 1] << " " << year << " is " << days[c] << ", " << d << " " << months[m - 1] << " " << y;
		}
	}
	}

}

//member functions of Calender Class
Calender::Calender() : month(0), year(0), firstday(-1), mdays(0), notes{}, nsize(0) {};

Calender::Calender(int m, int y) : month(m), year(y), firstday(-1), mdays(0), notes{}, nsize(0) {};

void Calender::dayNumber(int k)//Zeller�s Rule
{
	/*
		According to Zeller�s rule, the year starts from March and ends with February.
		k is  the day of the month.
		m is the month number.
		D is the last two digits of the year.
		C is the first two digits of the year.
	*/

	int m = month, y = year;

	int D = y % 100;
	int C = y / 100;

	if (m == 1 || m == 2)
		m += 10;
	else
		m -= 2;

	int F = k + ((13 * m - 1) / 5) + D + (D / 4) + (C / 4) - (2 * C);

	if (F >= 0)
	{
		firstday = (F % 7);
	}
	else if (F < 0)
	{
		int count = 0;
		for (int i = abs(F); ; i++)
		{
			if (i % 7 == 0)
			{
				firstday = count;
				return;
			}
			else
				count++;
		}
	}
}

string Calender::monthName()
{
	string months[12] = { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" };
	return (months[month - 1]);
}

void Calender::numberOfMDays()
{
	switch (month - 1)
	{
	case 0:
	case 2:
	case 4:
	case 6:
	case 7:
	case 9:
	case 11:
	{
		mdays = 31;
		break;
	}
	case 1:
	{
		if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
		{
			mdays = 29;
		}
		else
		{
			mdays = 28;
		}
		break;
	}
	case 3:
	case 5:
	case 8:
	case 10:
	{
		mdays = 30;
		break;
	}
	}
}

void Calender::printCalendar()
{
	cout << endl << "\t ----X----" << monthName() << "----X---- \t" << endl;
	cout << left << setw(6) << "Sun" << setw(6) << "Mon" << setw(6) << "Tue" << setw(6) << "Wed" << setw(6) << "Thu" << setw(6) << "Fri" << setw(6) << "Sat" << endl;
	int k;
	for (k = 0; k < firstday; k++)
		cout << setw(6) << " ";

	for (int j = 1; j <= mdays; j++)
	{
		cout << setw(6) << j;
		if (++k > 6)
		{
			k = 0;
			cout << endl;
		}
	}
	cout << endl;
}

void Calender::addnote()
{
	Note* temparray = new Note[nsize + 1];

	for (int i = 0; i < nsize; i++)
	{
		temparray[i] = notes[i];
	}

	int n;
	cout << "Enter year against which u want to add note (20XX): ";
	cin >> n;
	while (!(n >= 1000 && n < 10000))
	{
		cout << "Please enter valid year against which u want to add note (20XX): ";
		cin >> n;
	}
	temparray[nsize].setyear(n);

	cout << "Enter month against which u want to add note (1-12): ";
	cin >> n;
	while (n < 1 || n > 12)
	{
		cout << "Please enter valid month against which u want to add note (1-12): ";
		cin >> n;
	}
	temparray[nsize].setmonth(n);

	Calender* temp = new Calender(temparray[nsize].getmonth(), temparray[nsize].getyear());
	temp->numberOfMDays();
	int s = temp->mdays;
	delete temp;
	temp = nullptr;

	cout << "Enter day against which u want to add note (1-" << s << "): ";
	cin >> n;
	while (n < 1 || n > s)
	{
		cout << "Please enter valid day against which u want to add note (1-" << s << "): ";
		cin >> n;
	}
	temparray[nsize].setday(n);

	string ns;
	cin.ignore();
	cout << "Enter the note: ";
	getline(cin, ns);
	temparray[nsize].setnote(ns);

	nsize++;

	if (nsize != 0)
		delete[] notes;
	notes = temparray;
	temparray = nullptr;
}

void Calender::displaynotes()
{
	Note temp;

	for (int i = 0; i < nsize - 1; i++)
	{
		for (int j = 0; j < nsize - i - 1; j++)
		{
			if (notes[j].getyear() > notes[j + 1].getyear())
			{
				temp = notes[j];
				notes[j] = notes[j + 1];
				notes[j + 1] = temp;
			}

			else if ((notes[j].getyear() == notes[j + 1].getyear()) || (notes[j].getmonth() > notes[j + 1].getmonth()))
			{
				temp = notes[j];
				notes[j] = notes[j + 1];
				notes[j + 1] = temp;
			}

			else if ((notes[j].getyear() == notes[j + 1].getyear()) || (notes[j].getmonth() == notes[j + 1].getmonth()) || notes[j].getday() > notes[j + 1].getday())
			{
				temp = notes[j];
				notes[j] = notes[j + 1];
				notes[j + 1] = temp;
			}
		}
	}

	for (int i = 0; i < nsize; i++)
	{
		cout << i + 1 << ". " << notes[i].getnote()
			<< " (" << notes[i].getday() << "/"
			<< notes[i].getmonth() << "/"
			<< notes[i].getyear() << ")" << endl;
	}
}

void Calender::deletenote()
{
	displaynotes();

	int s;
	cout << "Enter # of note you want to delete: ";
	cin >> s;
	s--;
	while (s < 0 || s >= nsize)
	{
		cout << "Please enter valid # of note you want to delete: ";
		cin >> s;
		s--;
	}

	for (int i = s - 1; i < nsize; i++)
	{
		if (i < nsize - 1)
			notes[i] = notes[i + 1];
		else if (i == nsize - 1)
			notes[i].setday(0), notes[i].setmonth(0), notes[i].setyear(0), notes[i].setnote("NULL");

	}

	nsize--;

	displaynotes();
}

void Calender::editnote()
{
	displaynotes();

	int s;
	cout << "Enter # of note you want to edit: ";
	cin >> s;
	s--;
	while (s < 0 || s >= nsize)
	{
		cout << "Please enter valid # of note you want to edit: ";
		cin >> s;
		s--;
	}

	int choice;
	cout << "Enter 1 if you want to change the date. \n"
		<< "Enter 2 if you want to change the description. \n"
		<< "Enter your choice: ";
	cin >> choice;
	while (!(choice == 1 || choice == 2))
	{
		cout << "Please enter valid input.\n"
			<< "Enter 1 if you want to change the date. \n"
			<< "Enter 2 if you want to change the description. \n"
			<< "Enter your choice: ";
		cin >> choice;
	}

	switch (choice)
	{
	case 1:
	{
		int n;
		cout << "Enter year against which u want to add note (20XX): ";
		cin >> n;
		while (!(n >= 1000 && n < 10000))
		{
			cout << "Please enter valid year against which u want to add note (20XX): ";
			cin >> n;
		}
		notes[s].setyear(n);

		cout << "Enter month against which u want to add note (1-12): ";
		cin >> n;
		while (n < 1 || n > 12)
		{
			cout << "Please enter valid month against which u want to add note (1-12): ";
			cin >> n;
		}
		notes[s].setmonth(n);

		Calender* temp = new Calender(notes[s].getmonth(), notes[s].getyear());
		temp->numberOfMDays();
		int s = temp->mdays;
		delete temp;
		temp = nullptr;

		cout << "Enter day against which u want to add note (1-" << s << "): ";
		cin >> n;
		while (n < 1 || n > s)
		{
			cout << "Please enter valid day against which u want to add note (1-" << s << "): ";
			cin >> n;
		}
		notes[s].setday(n);

		break;
	}
	case 2:
	{
		string ns;
		cin.ignore();
		cout << "Enter the note: ";
		getline(cin, ns);
		notes[s].setnote(ns);
	}
	}

	displaynotes();
}

void Calender::Menu()
{
	int choice;
menu:
	cout << endl << endl << endl;
	cout << "Enter 1 to see calender of any month of any year.\n"
		<< "Enter 2 to add a note against any date.\n"
		<< "Enter 3 to view all notes sorted by date.\n"
		<< "Enter 4 to edit existing notes.\n"
		<< "Enter 5 to delete existing notes.\n"
		<< "Enter 6 to calculate the difference in months, weeks or days between any two dates.\n"
		<< "Enter 7 to calculate future date from specific number of weeks, months or days.\n"
		<< "Enter 8 to calculate past date from specific number of weeks, months or days.\n"
		<< "Enter 9 to exit.\n"
		<< "Enter your choice: ";
	cin >> choice;
	while (!(choice > 0 && choice <= 9))
	{
		cout << "Please enter valid input!\n";
		cout << "Enter 1 to see calender of any month of any year.\n"
			<< "Enter 2 to add a note against any date.\n"
			<< "Enter 3 to view all notes sorted by date.\n"
			<< "Enter 4 to edit existing notes.\n"
			<< "Enter 5 to delete existing notes.\n"
			<< "Enter 6 to calculate the difference in months, weeks or days between any two dates.\n"
			<< "Enter 7 to calculate future date from specific number of weeks, months or days.\n"
			<< "Enter 8 to calculate past date from specific number of weeks, months or days.\n"
			<< "Enter 9 to exit.\n"
			<< "Enter your choice: ";
		cin >> choice;
	}

	switch (choice)
	{
	case 1:
	{
		int m, y;

		do
		{
			cout << "Please enter valid month (1-12): ";
			cin >> m;
		} while (!(m > 0 && m <= 12));

		do
		{
			cout << "Please enter valid year (20XX): ";
			cin >> y;
		} while (!(y > 999 && y < 10000));

		month = m;
		year = y;

		dayNumber(1);
		numberOfMDays();
		printCalendar();

		goto menu;

	}
	case 2:
	{
		addnote();

		goto menu;
	}
	case 3:
	{
		displaynotes();

		goto menu;
	}
	case 4:
	{
		editnote();

		goto menu;
	}
	case 5:
	{
		deletenote();

		goto menu;
	}
	case 6:
	{
		Date D1, D2;

		int n;
		cout << "Enter year of date 1 (20XX): ";
		cin >> n;
		while (!(n >= 1000 && n < 10000))
		{
			cout << "Please enter valid year of date 1 (20XX): ";
			cin >> n;
		}
		D1.setyear(n);

		cout << "Enter month of date 1 (1-12): ";
		cin >> n;
		while (n < 1 || n > 12)
		{
			cout << "Please enter valid month of date 1 (1-12): ";
			cin >> n;
		}
		D1.setmonth(n);

		Calender* temp = new Calender(D1.getmonth(), D1.getyear());
		temp->numberOfMDays();
		int s = temp->mdays;
		delete temp;
		temp = nullptr;

		cout << "Enter day of date 1 (1-" << s << "): ";
		cin >> n;
		while (n < 1 || n > s)
		{
			cout << "Please enter valid day of date 1 (1-" << s << "): ";
			cin >> n;
		}
		D1.setday(n);

		cout << "Enter year of date 2 (20XX): ";
		cin >> n;
		while (!(n >= 1000 && n < 10000))
		{
			cout << "Please enter valid year of date 2 (20XX): ";
			cin >> n;
		}
		D2.setyear(n);

		cout << "Enter month of date 2 (1-12): ";
		cin >> n;
		while (n < 1 || n > 12)
		{
			cout << "Please enter valid month of date 2 (1-12): ";
			cin >> n;
		}
		D2.setmonth(n);

		temp = new Calender(D2.getmonth(), D2.getyear());
		temp->numberOfMDays();
		s = temp->mdays;
		delete temp;
		temp = nullptr;

		cout << "Enter day of date 2 (1-" << s << "): ";
		cin >> n;
		while (n < 1 || n > s)
		{
			cout << "Please enter valid day of date 2 (1-" << s << "): ";
			cin >> n;
		}
		D2.setday(n);

		Date D3 = D1 - D2;

		D3.printdiff();

		goto menu;
	}
	case 7:
	{
		Date D1;

		int n;
		cout << "Enter year of date (20XX): ";
		cin >> n;
		while (!(n >= 1000 && n < 10000))
		{
			cout << "Please enter valid year of date (20XX): ";
			cin >> n;
		}
		D1.setyear(n);

		cout << "Enter month of date (1-12): ";
		cin >> n;
		while (n < 1 || n > 12)
		{
			cout << "Please enter valid month of date (1-12): ";
			cin >> n;
		}
		D1.setmonth(n);

		Calender* temp = new Calender(D1.getmonth(), D1.getyear());
		temp->numberOfMDays();
		int s = temp->mdays;
		delete temp;
		temp = nullptr;

		cout << "Enter day of date (1-" << s << "): ";
		cin >> n;
		while (n < 1 || n > s)
		{
			cout << "Please enter valid day of date (1-" << s << "): ";
			cin >> n;
		}
		D1.setday(n);

		D1.futuredate();

		goto menu;
	}
	case 8:
	{
		Date D1;

		int n;
		cout << "Enter year of date (20XX): ";
		cin >> n;
		while (!(n >= 1000 && n < 10000))
		{
			cout << "Please enter valid year of date (20XX): ";
			cin >> n;
		}
		D1.setyear(n);

		cout << "Enter month of date (1-12): ";
		cin >> n;
		while (n < 1 || n > 12)
		{
			cout << "Please enter valid month of date (1-12): ";
			cin >> n;
		}
		D1.setmonth(n);

		Calender* temp = new Calender(D1.getmonth(), D1.getyear());
		temp->numberOfMDays();
		int s = temp->mdays;
		delete temp;
		temp = nullptr;

		cout << "Enter day of date (1-" << s << "): ";
		cin >> n;
		while (n < 1 || n > s)
		{
			cout << "Please enter valid day of date (1-" << s << "): ";
			cin >> n;
		}
		D1.setday(n);

		D1.pastdate();

		goto menu;
	}
	case 9:
		exit(0);
	}

}

int main()
{
	int m, y;

	time_t dt = time(nullptr);
	tm* itm = localtime(&dt);

	m = itm->tm_mon + 1;
	y = itm->tm_year + 1900;

	Calender C1(m, y);

	C1.dayNumber(1);
	C1.numberOfMDays();
	C1.printCalendar();

	C1.Menu();
}