//Fahad Waheed	20I-0651
//Problem 3 of Assignment 3 (Header File)

#pragma once
#include<string>

using namespace std;

class Note
{
	int day, month, year;
	string note;

public:
	Note();
	void setday(int);
	void setmonth(int);
	void setyear(int);
	void setnote(string);
	int getday();
	int getmonth();
	int getyear();
	string getnote();
};