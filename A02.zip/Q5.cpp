//Fahad Waheed	20I-0651

#include<iostream>
#include<string>
#include<ctime>
#include<cstdlib>

using namespace std;

#pragma warning(disable:4996)

struct Index
{
	int index[15];
	int size;
};

class Player {
private:
	char* name;
	string type; //type of the player �attacking� or �defensive�
	double points{}; //randomly assign points between 30 to 40 randomly
	bool status{};
public:
	// constructors
	Player() 
	{
		name = nullptr;
		type = "NULL";
		points = 0.0;
		status = false;
	}

	void setname(char* n)
	{
		name = n;
	}

	void settype(string t)
	{
		type = t;
	}

	void setpoints(double p)
	{
		points = p;
	}

	void setstatus(bool s)
	{
		status = s;
	}

	char* getname()
	{
		return name;
	}

	string gettype()
	{
		return type;
	}

	double getpoints()
	{
		return points;
	}

	bool getstatus()
	{
		return status;
	}
};

class Team {
	char* teamName;
	int teamRank{};
	int Matchwin{};
	Player* teamPlayers{};
	

public:
	Team() 
	{
		teamName = nullptr;
		teamRank = 0;
		Matchwin = 0;
		teamPlayers = new Player[3];
	}
	
	void setteamName(char* tm)
	{
		teamName = tm;
	}

	void setteamRank(int R)
	{
		teamRank = R;
	}

	void setMatchwin(int w)
	{
		Matchwin = w;
	}

	void setteamPlayers(Player te, int i)
	{
		teamPlayers[i] = te;
	}

	char* getteamName()
	{
		return teamName;
	}

	int getteamRank()
	{
		return teamRank;
	}

	int getMatchwin()
	{
		return Matchwin;
	}

	Player* getteamPlayers()
	{
		return teamPlayers;
	}

	Player getteamPlayer(int i)
	{
		return teamPlayers[i];
	}
		
	Index returnPlayers(Player* allPlayers, string temp)
	{
		Index ind;
		ind.size = 0;
		for (int i = 0; i < 15; i++)
		{
			ind.index[i] = -1;
		}

		for (int i = 0; i < 15; i++)
		{
			if (temp == allPlayers[i].gettype())
			{
				ind.index[ind.size] = i;
				ind.size++;
			}
		}
		return ind;
	}

	void displayplayers(Player* allPlayers, Index ind, string ttype)
	{
		cout << "\nPlayers available of type: " << ttype << endl;
		for (int i = 0; i < ind.size; i++)
		{
			if (allPlayers[ind.index[i]].getstatus() == true)
			{
				cout << "Details of Player " << i + 1 << endl;
				cout << "Name of Player: " << allPlayers[ind.index[i]].getname() << endl;
				cout << "Type of " << allPlayers[ind.index[i]].getname() << ": " << allPlayers[ind.index[i]].gettype() << endl;
				cout << "Points of " << allPlayers[ind.index[i]].getname() << ": " << allPlayers[ind.index[i]].getpoints() << endl;
				cout << "Status of " << allPlayers[ind.index[i]].getname() << ": " << allPlayers[ind.index[i]].getstatus() << endl;
				cout << endl;
			}
		}
	}

	int playeravailable(Player* allPlayers, string tname)
	{
		for (int i = 0; i < 15; i++)
		{
			if (tname == allPlayers[i].getname())
			{
				if (allPlayers[i].getstatus() == false)
				{
					cout << "Player already taken!\nNot available for u!";
					return -1;
				}
				
				cout << "Player found!";
				return i;
			}
		}

		cout << "Player not found!";
		return -1;
	}

	bool strategycheck(Player* temp)
	{
		int check1 = 0, check2 = 0;
		for (int i = 0; i < 3; i++)
		{
			if (temp[i].gettype() == "Defensive")
				check1++;
			if (temp[i].gettype() == "Attacking")
				check2++;
		}

		if (check1 == 3)
		{
			cout << "Sorry! for defensive strategy, you must have one attacking player.\n";
			return true;
		}

		else if (check2 == 3)
		{
			cout << "Sorry! for attacking strategy, you must have one defensive player.\n";
			return true;
		}

		else
			return false;
	}

	void playerSelection(Player* allPlayers)
	{
		int index;
		Player temp;
		string temp1;
	wrongstrategy:
		cout << "\nNote: u can select no more than 2 players of same type.\n";
		string ttype;
		cout << "Select Players of " << this->getteamName() << " : \n";
		for (int j = 0; j < 3; j++)
		{
		not_found:
			cout << "\nEnter the type of Player you want to select (Attacking or Defensive): ";
			getline(cin, ttype);
			while (!(ttype == "Attacking" || ttype == "Defensive"))
			{
				cout << "\nSorry! we currently have Players of only two types which are\n"
					<< "1. Attacking\n2. Defensive\nEnter your choice: ";
				getline(cin, ttype);
			}

			Index ind = returnPlayers(allPlayers, ttype);
			displayplayers(allPlayers, ind, ttype);

			cout << "Enter name of Player to select: ";
			getline(cin, temp1);
			index = playeravailable(allPlayers, temp1);

			if (index == -1)
			{
				goto not_found;
			}
			else
			{
				temp.setname(allPlayers[index].getname());
				temp.settype(allPlayers[index].gettype());
				temp.setpoints(allPlayers[index].getpoints());
				temp.setstatus(allPlayers[index].getstatus());
				allPlayers[index].setstatus(false);

				this->setteamPlayers(temp, j);
				cout << "\nPlayer Selected..\n";

				index = -1;
			}

		}
		
		if (strategycheck(teamPlayers))
		{
			Player* temp2 = this->getteamPlayers();
			int i = 0;
			for (int j = 0; j < 3; j++)
			{
				for (int k = 0; k < 15; k++)
				{
					if (temp2[j].getname() == allPlayers[k].getname())
					{
						allPlayers[k].setstatus(true);
					}
				}
			}
			
			cout << "Kindly select all Players again and \n"
				<< "Be careful this time (Remember the Rules).\n";
			goto wrongstrategy;
		}
	}

	void UpdatePlayerPoints(int i)
	{
		for (int j = 0; j < 3; j++)
		{
			if (i == 1)
			{
				teamPlayers[j].setpoints((teamPlayers[j].getpoints())+(rand() % 10) + 10);
			}

			else if (i == 0)
			{
				teamPlayers[j].setpoints((teamPlayers[j].getpoints())+(rand() % 5) + 5);
			}
		}
		Player temp;
		for (int j = 0; j < 3; j++)
		{
			for (int k = 0; k < 3 - j - 1; k++)
			{
				if (teamPlayers[k].getpoints() < teamPlayers[k + 1].getpoints())
				{
					temp = teamPlayers[j];
					teamPlayers[j] = teamPlayers[j + 1];
					teamPlayers[j + 1] = temp;
				}
			}
		}
	}

};

class Match {
	int Match_No{};
	Team* homeTeam{};
	Team* awayTeam{};
	Team* array;
	Player* allPlayers{};

public:
	Match() 
	{
		Match_No = 0;
		homeTeam = nullptr;
		awayTeam = nullptr;
		array = new Team[4];
		allPlayers = new Player[15];
	}

	void setteam(Team te, int i)
	{
		array[i] = te;
	}

	void setteamPlayers(Player* te, int i)
	{
		for (int j = 0; j < 3; j++)
		{
			array[i].setteamPlayers(te[j], j);
		}
	}

	Team& getteam(int i)//returning a specific team by reference
	{
		return array[i];
	}

	void setMatch_No(int i)
	{
		Match_No = i;
	}

	void sethomeTeam(Team* te)
	{
		homeTeam = te;
	}

	void setawayteam(Team* te)
	{
		awayTeam = te;
	}

	void addPlayers()
	{
		string temp;

		temp = "Ali Khan";
		char* te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[0].setname(te);
		allPlayers[0].settype("Attacking");
		allPlayers[0].setpoints(31.5);
		allPlayers[0].setstatus(true);

		temp = "Umer Khan";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[1].setname(te);
		allPlayers[1].settype("Attacking");
		allPlayers[1].setpoints(38);
		allPlayers[1].setstatus(true);

		temp = "Amir Khan";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[2].setname(te);
		allPlayers[2].settype("Defensive");
		allPlayers[2].setpoints(37.5);
		allPlayers[2].setstatus(true);

		temp = "Umer Akmal";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[3].setname(te);
		allPlayers[3].settype("Defensive");
		allPlayers[3].setpoints(38.12);
		allPlayers[3].setstatus(true);

		temp = "Syed Shafaat";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[4].setname(te);
		allPlayers[4].settype("Attacking");
		allPlayers[4].setpoints(38.9);
		allPlayers[4].setstatus(true);

		temp = "Shahid Afridi";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[5].setname(te);
		allPlayers[5].settype("Defensive");
		allPlayers[5].setpoints(33.5);
		allPlayers[5].setstatus(true);

		temp = "Babar Azam";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[6].setname(te);
		allPlayers[6].settype("Attacking");
		allPlayers[6].setpoints(39.9);
		allPlayers[6].setstatus(true);

		temp = "Fakhar Zaman";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[7].setname(te);
		allPlayers[7].settype("Defensive");
		allPlayers[7].setpoints(35.34);
		allPlayers[7].setstatus(true);

		temp = "Shoaib Malik";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[8].setname(te);
		allPlayers[8].settype("Attacking");
		allPlayers[8].setpoints(33.6);
		allPlayers[8].setstatus(true);

		temp = "Hassan Ali";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[9].setname(te);
		allPlayers[9].settype("Defensive");
		allPlayers[9].setpoints(30.99);
		allPlayers[9].setstatus(true);

		temp = "Shaheen Afridi";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[10].setname(te);
		allPlayers[10].settype("Attacking");
		allPlayers[10].setpoints(33.08);
		allPlayers[10].setstatus(true);

		temp = "Sarfaraz Ahmad";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[11].setname(te);
		allPlayers[11].settype("Defensive");
		allPlayers[11].setpoints(33.96);
		allPlayers[11].setstatus(true);

		temp = "Danish Aziz";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[12].setname(te);
		allPlayers[12].settype("Attacking");
		allPlayers[12].setpoints(35.67);
		allPlayers[12].setstatus(true);

		temp = "Shadab Khan";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[13].setname(te);
		allPlayers[13].settype("Defensive");
		allPlayers[13].setpoints(36.83);
		allPlayers[13].setstatus(true);

		temp = "Wahab Riaz";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		allPlayers[14].setname(te);
		allPlayers[14].settype("Attacking");
		allPlayers[14].setpoints(37);
		allPlayers[14].setstatus(true);
	}
	
	Player* getallPlayers()
	{
		return allPlayers;
	}

	void teamnames()
	{
		string temp;
		char* te;

		temp = "Lahore";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		array[0].setteamName(te);

		temp = "Islamabad";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		array[1].setteamName(te);

		temp = "Rawalpindi";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		array[2].setteamName(te);

		temp = "Multan";
		te = new char[temp.length() + 1];
		strcpy(te, temp.c_str());
		array[3].setteamName(te);
	}

	void assignRanks()
	{
		srand(time(0));

		array[0].setteamRank(rand() % 4 + 1);

		do
		{
			array[1].setteamRank(rand() % 4 + 1);
		} while (array[1].getteamRank() == array[0].getteamRank());

		do
		{
			array[2].setteamRank(rand() % 4 + 1);
		} while ((array[2].getteamRank() == array[1].getteamRank()) || (array[2].getteamRank() == array[0].getteamRank()));

		do
		{
			array[3].setteamRank(rand() % 4 + 1);
		} while ((array[3].getteamRank() == array[2].getteamRank()) || (array[3].getteamRank() == array[1].getteamRank()) || (array[3].getteamRank() == array[0].getteamRank()));
	}

	void bestPlayersInMatch()
	{
		Player* TP1 = homeTeam->getteamPlayers(), * TP2=awayTeam->getteamPlayers();
		double i1i = TP1[0].getpoints();
		double i2i = TP2[0].getpoints();
		Player BP1 = TP1[0], BP2 = TP2[0];

		for (int i = 1; i < 3; i++)
		{
			if (TP1[i].getpoints() > i1i)
			{
				BP1 = TP1[i];
				i1i = TP1[i].getpoints();
			}

			if (TP2[i].getpoints() > i2i)
			{
				BP2=TP2[i];
				i2i = TP2[i].getpoints();
			}
		}

		cout << "\nBest Player of " << homeTeam->getteamName() << " is " << BP1.getname()
			<< " having " << BP1.getpoints() << " points.\n";
		cout << "\nBest Player of " << awayTeam->getteamName() << " is " << BP2.getname()
			<< " having " << BP2.getpoints() << " points.\n";
	}

	void PrintTeamRanks()
	{
		Team temp;
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 4 - i - 1; j++)
			{
				if (array[j].getMatchwin() < array[j + 1].getMatchwin())
				{
					temp = array[j];
					array[j] = array[j + 1];
					array[j + 1] = temp;
				}
			}
		}

		array[0].setteamRank(1);
		array[1].setteamRank(2);
		array[2].setteamRank(3);
		array[3].setteamRank(4);

		cout << "\nRank of Teams in Table Tennis Fantasy League: \n";
		for (int i = 0; i < 4; i++)
		{
			cout << "Rank of " << array[i].getteamName() << " is " << array[i].getteamRank() << endl;
		}
	}

	void printLeaderBoard()
	{
		Player* temp;
		Player te;
		for (int i = 0; i < 4; i++)
		{
			temp = array[i].getteamPlayers();
			for (int j = 0; j < 3 - 1; j++)
			{
				for (int k = 0; k < 3 - j - 1; k++)
				{
					if (temp[k].getpoints() < temp[k + 1].getpoints())
					{
						te = temp[k];
						temp[k] = temp[k + 1];
						temp[k + 1] = te;
					}
				}
			}
		}
		
		
		
		for (int i = 0; i < 4; i++)
		{
			cout << "\nPlayers of " << array[i].getteamName() << " are \n";
			for (int j = 0; j < 3; j++)
			{
				cout << j + 1 << ". " << array[i].getteamPlayer(j).getname() << " having "
					<< array[i].getteamPlayer(j).getpoints() << " points.\n";
			}
		}
	}

	void generateMatchStats()
	{
		cout << "\nHome Team: " << homeTeam->getteamName();
		cout << "\nAway Team: " << awayTeam->getteamName();
		
		srand(time(0));

		int win = rand() % 2;

		if (win == 1)
		{
			cout << endl << homeTeam->getteamName() << " wins!\n";
			cout << "Press Enter to continue..\n";
			cin.get();

			homeTeam->UpdatePlayerPoints(1);
			homeTeam->setMatchwin(homeTeam->getMatchwin() + 1);
			cout << endl << awayTeam->getteamName() << " lose!\n";
			cout << "Press Enter to continue..\n";
			cin.get();

			awayTeam->UpdatePlayerPoints(0);
		}

		else if (win == 0)
		{
			cout << endl << awayTeam->getteamName() << " wins!\n";
			cout << "Press Enter to continue..\n";
			cin.get();

			awayTeam->UpdatePlayerPoints(1);
			awayTeam->setMatchwin(awayTeam->getMatchwin() + 1);
			cout << endl << homeTeam->getteamName() << " lose!\n";
			cout << "Press Enter to continue..\n";
			cin.get();

			homeTeam->UpdatePlayerPoints(0);
		}

		bestPlayersInMatch();
		cout << "Press Enter to continue..\n";
		cin.get();
	}

	~Match()
	{
		for (int i = 0; i < 4; i++)
		{
			delete[] array[i].getteamName();
			delete[] array[i].getteamPlayers();
			for (int j = 0; j < 3; j++)
			{
				delete[] array[i].getteamPlayer(j).getname();
			}
		}

		for (int i = 0; i < 15; i++)
		{
			if (allPlayers[i].getstatus() == true)
			{
				delete[] allPlayers[i].getname();
			}
		}
		delete[] allPlayers, array;
	}
};

int main()
{
	Match M;
	M.teamnames();
	M.assignRanks();
	M.addPlayers();

	for (int i = 0; i < 4; i++)
	{		
		M.getteam(i).playerSelection(M.getallPlayers());
	}
	

	Match M1[12];
	int M1count = 0;
	int cont;
	int matchcount = 1;
	Team *team1, *team2;

	for (int i = 0; i < 4; i++)
	{
		for (int j = i + 1; j < 4; j++)
		{
			cout << "Enter 1 to see the stats of Match "<<matchcount<<": ";
			cin >> cont;
			cin.ignore();
			momos:
			if (cont == 1)
			{
				M1[M1count].setMatch_No(matchcount);
				team1 = &M.getteam(i);
				team2 = &M.getteam(j);
				M1[M1count].sethomeTeam(team1);
				M1[M1count].setawayteam(team2);
				M1[M1count].generateMatchStats();
				M.PrintTeamRanks();
				cout << "Press Enter to continue..\n";
				cin.get();
				M.printLeaderBoard();
				cout << "Press Enter to continue..\n";
				cin.get();
				matchcount++;
				M1count++;
			}
			else
			{
				cout << "\nYou didn't Entered 1!\n";
				cout << "Here's another chance if u want too see the stat of match " << matchcount << " Enter 1.\n"
					<< "Otherwise enter any other u want to close.\n "
					<< "Enter ur choice: ";
				cin >> cont;
				if (cont == 1)
					goto momos;
				else
					exit(0);
			}
		}
	}

	for (int i = 3; i >= 0; i--)
	{
		for (int j = i - 1; j >= 0; j--)
		{
			cout << "Enter 1 to see the stats of Match " << matchcount << ": ";
			cin >> cont;
			cin.ignore();
			momo:
			if (cont == 1)
			{
				M1[M1count].setMatch_No(matchcount);
				team1 = &M.getteam(i);
				team2 = &M.getteam(j);
				M1[M1count].sethomeTeam(team1);
				M1[M1count].setawayteam(team2);
				M1[M1count].generateMatchStats();
				M.PrintTeamRanks();
				cout << "Press Enter to continue..\n";
				cin.get();
				M.printLeaderBoard();
				cout << "Press Enter to continue..\n";
				cin.get();
				matchcount++;
				M1count++;
			}
			else
			{
				cout << "\nYou didn't Entered 1!\n";
				cout << "Here's another chance if u want too see the stat of match " << matchcount << " Enter 1.\n"
					<< "Otherwise enter any other u want to close.\n "
					<< "Enter ur choice: ";
				cin >> cont;
				if (cont == 1)
					goto momo;
				else
					exit(0);
			}
		}	
	}
}