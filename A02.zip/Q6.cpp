//Fahad Waheed	20I-0651

#include<iostream>
#include<string>

#ifdef _WIN32
#include <Windows.h>
#else
#include <unistd.h>
#endif

//to change delay Time, please refer to line 292..

using namespace std;

struct Runway {
	int id;
	bool status;
	int dur;
	string type;
	int s_Time; //start time of each task
};

class Flight {
private:
	string flight_No;
	double arrivalTime; //arrival time which is known at the departure.
	double remainingFlyTime; //how long can the fuel last it no runway is available
	double scheduled_landing_Time; 
	Runway rn; 
	bool landed;
public:
	// constructors
	Flight()
	{
		flight_No = "NULL";
		arrivalTime = -1;
		remainingFlyTime = -1;
		scheduled_landing_Time = -1;
		rn.id = 0;
		rn.status = false;
		landed = false;
	}
	
	Runway getrunway()
	{
		return rn;
	}

	string getflight_No()
	{
		return flight_No;
	}

	double getarrivalTime()
	{
		return arrivalTime;
	}

	void setlanded(bool l)
	{
		landed = l;
	}

	bool getlanded()
	{
		return landed;
	}

	double getremainingFlyTime()
	{
		return remainingFlyTime;
	}

	//function to add flight information
	void addFlight()
	{
		cout << "Enter Flight #: ";
		getline(cin, flight_No);

		do
		{
			cout << "Enter Expected Arrival Time (must be with in 10 minutes): ";
			cin >> arrivalTime;
		} while (!(arrivalTime > 0 && arrivalTime <= 10));

		do
		{
			cout << "Enter Remaining Flying Time(Fuel): ";
			cin >> remainingFlyTime;
		} while (!(remainingFlyTime >= arrivalTime));
		
		cin.ignore();
	}

	//This is updated once the flight contacts AirController
	void UpdateRemainingFlyTime(double r) 
	{
		remainingFlyTime = r;
	}

	//get landing time from the AirController depending on the availability of the runway
	void UpdateLandingInfo(double schtime, Runway r) 
	{
		scheduled_landing_Time = schtime;
		rn = r;
	}
};

class AirController {
private:
	Flight* flight{};
	int length; // the # elements
	int nextIndex;
	Runway rn[3];

public:
	// constructors
	AirController() 
	{
		flight = nullptr;
		length = 0;
		nextIndex = -1;

		rn[0].id = 111;
		rn[1].id = 222;
		rn[2].id = 333;

		rn[0].status = false;
		rn[1].status = false;
		rn[2].status = false;
	}

	AirController(int l)
	{
		length = l;
		flight = new Flight[length];
		nextIndex = 0;

		rn[0].id = 111;
		rn[1].id = 222;
		rn[2].id = 333;

		rn[0].status = false;
		rn[1].status = false;
		rn[2].status = false;
	}

	~AirController()
	{
		delete[] flight;
		flight = nullptr;
	}
	
	void RunwayStatus()//prints the status of all the runways
	{
		string temp;
		for (int i = 0; i < 3; i++)
		{
			if (rn[i].status == 0)
				temp = "available";
			else
				temp = "not available";
			cout << "Status of Runway " << rn[i].id << " is " << temp << endl;
		}
	}

	void FlightContact() //prints the data of flights who have contacted the controller
	{
		Runway temp;
		for (int i = 0; i < length; i++)
		{
			temp = flight[i].getrunway();
			if (temp.status == true)
			{
				cout << "Flight No: " << flight[i].getflight_No() << endl;
				cout << "Arrival Time: " << flight[i].getarrivalTime() << endl;
				if (flight[i].getlanded() == true)
				{
					cout << flight[i].getflight_No() << " is landed." << endl;
				}
				else
					cout << flight[i].getflight_No() << " is looking forward for landing." << endl;
			}
		}
	}

	int runwaycheck(int id)
	{
		for (int i = 0; i < 3; i++)
		{
			if (id == rn[i].id)
			{
				if (rn[i].status == true)
				{
					cout << "Sorry! this runway is currently in use ";
					return -1;
				}
				else
					return i;
			}
		}
		cout << "Sorry! there is no runway with the id you entered..";
		return -1;
	}

	void inputflight()
	{
		for (int i = 0; i < length; i++)
		{
			flight[i].addFlight();
		}
	}

	void AssignRunway()//assigns runway to a flight
	{
		Flight temp;
		for (int i = 0; i < length - 1; i++)
		{
			for (int j = 0; j < length - i - 1; j++)
			{
				if (flight[j].getremainingFlyTime() > flight[j + 1].getremainingFlyTime())
				{
					temp = flight[j];
					flight[j] = flight[j + 1];
					flight[j + 1] = temp;
				}
			}
		}

		Runway temp1;
		int i = 0;
		while(nextIndex<length)
		{
			int check;
			if (length > nextIndex)
			{
				RunwayStatus();
				do
				{
					cout << "Assign Runway to " << flight[nextIndex].getflight_No() << "\n";
					cout << "Enter runway ID: ";
					cin >> temp1.id;
					check = runwaycheck(temp1.id);
				} while (check == -1);

				temp1.status = true;
				rn[check] = temp1;
				flight[nextIndex].UpdateLandingInfo(i * 2, rn[check]);
				flight[nextIndex].setlanded(true);
				nextIndex++;
			}

			if (length > nextIndex)
			{
				RunwayStatus();
				do
				{
					cout << "Assign Runway to " << flight[nextIndex].getflight_No() << "\n";
					cout << "Enter runway ID: ";
					cin >> temp1.id;
					check = runwaycheck(temp1.id);
				} while (check == -1);

				temp1.status = true;
				rn[check] = temp1;
				flight[nextIndex].UpdateLandingInfo(i * 2, rn[check]);
				flight[nextIndex].setlanded(true);
				nextIndex++;
			}

			if (length > nextIndex)
			{
				RunwayStatus();
				do
				{
					cout << "Assign Runway to " << flight[nextIndex].getflight_No() << "\n";
					cout << "Enter runway ID: ";
					cin >> temp1.id;
					check = runwaycheck(temp1.id);
				} while (check == -1);

				temp1.status = true;
				rn[check] = temp1;
				flight[nextIndex].UpdateLandingInfo(i * 2, rn[check]);
				flight[nextIndex].setlanded(true);
				nextIndex++;
			}

			cout << "\nNow u have to wait for 2 minutes to get these flights landed..\n";
			
			int sleeptime = 120;//in seconds
			
			//to suspend programs execution			
			#ifdef _WIN32//for windows
				Sleep(sleeptime * 1000);//this func receive values in milliseconds		
			#else//for linux
				sleep(sleeptime);//this func receive values in seconds
			#endif

			for (int j = nextIndex - 1; j < length; j++)
			{
				flight[j].UpdateRemainingFlyTime(flight[j].getremainingFlyTime() - ((i * 2) + 2));
			}
			FlightContact();
			rn[0].status = false;
			rn[1].status = false;
			rn[2].status = false;

			i++;
		}
	}
};

int main()
{
start:
	int s;
	cout << "Enter number of Flight that are going to land in 10 minustes: ";
	cin >> s;
	while (!(s > 0 && s < 15))
	{
		cout << "No more than 15 flights can be landed in 10 minutes.\n"
			<< "as each flight takes 15 minutes.\n"
			<< "Kindly enter number of flights: ";
		cin >> s;
	}
	cin.ignore();
	AirController A(s);
	A.inputflight();
	A.AssignRunway();
	int choice;
	do
	{
		cout << "Enter 1 if u want to simulate for another 10 minutes..\n"
			<< "Enter 2 if u want exit.."
			<< "\nEnter your choice: ";
		cin >> choice;
	} while (!(choice == 1 || choice == 2));

	switch (choice)
	{
	case 1:
		goto start;

	case 2:
		exit(0);
	}
}