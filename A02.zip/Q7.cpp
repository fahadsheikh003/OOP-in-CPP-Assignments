//Fahad Waheed	20I-0651

#include<iostream>

/*
IDs of tasks are assigned automatically.

Program will automatically assign available tasks to rsources and 
changes their status accordingly.

Skills of Resources:
Resource 101 has A skill
Resource 111 has B skill
Resource 222 has C skill
Resource 333 has D skill
Resource 444 has A skill
Resource 555 has B skill
Resource 666 has C skill
Resource 777 has D skill
Resource 888 has A skill
Resource 999 has C skill
*/

using namespace std;

struct Resource {
	int res_Id;
	bool res_Availability;
	char res_Skill;
};

class task {
private:
	int id;
	static int base;
	int dur;
	int s_Time; //start time of each task
	int e_Time; //end time of each task

	//for critical path
	int LFtime; //late finish time
	int LStime; //late start time

	int* dep; /*list of predecessors of this task - To simplify we assume that a higher number task will depend on a lower number task e.g. T2 can depend on T1 OR T4 can depend on T2 but the opposite is not true.*/
	int depsize;

	char skill; //required for PART B
	Resource res{}; //required for PART B
public:
	task()
	{
		id = dur = s_Time = e_Time = depsize = 0;
		dep = NULL;
		LStime = LFtime = 0;
		skill = NULL;
	}
	
	void setresource(Resource r)
	{
		res = r;
	}

	Resource getresource()
	{
		return res;
	}

	char getskill()
	{
		return skill;
	}

	int getid()
	{
		return id;
	}

	int get_s_Time()
	{
		return s_Time;
	}
	
	int get_e_Time()
	{
		return e_Time;
	}

	int get_LFtime()
	{
		return LFtime;
	}

	int get_LStime()
	{
		return LStime;
	}

	int getdur()
	{
		return dur;
	}

	int checkid(int tempid, task* tasks, int size)
	{
		for (int i = 0; i < size; i++)
		{
			if (tempid == tasks[i].id)
			{
				cout << "\nPredecessor added successfully..\n";
				return i;
			}
		}
		cout << "\nTask not found..\n";
		return -1;
	}

	void addTasks(task* tasks, int size)
	{
		for (int i = 0; i < size; i++)
		{
			tasks[i].id = base;
			base += 11;

			cout << "Enter duration (days) of task " << tasks[i].id << " : ";
			cin >> tasks[i].dur;
			while (!(tasks[i].dur > 0))
			{
				cout << "\nDuration can never be negative..\n";
				cout << "Please Enter valid duration of " << tasks[i].id << " : ";
				cin >> tasks[i].dur;
			}

			cout << "Enter skill required for this task(A,B,C,D): ";
			cin >> skill;
			while (!(skill == 'A' || skill == 'B' || skill == 'C' || skill == 'D'))
			{
				cout << "Please Enter valid skill required for this task(A,B,C,D): ";
				cin >> skill;
			}

			if (i == 0)
				cout << "\nIt is not possible for first task to have predecesors..\n";
			else
			{
				int n;
				cout << "Enter number of Predecesors/Dependencies: ";
				cin >> n;
				while (!(n >= 0))
				{
					cout << "Please Enter valid number of Predecesors/Dependencies: ";
					cin >> n;
				}

				tasks[i].dep = new int[n];

				int tempid;
				for (int j = 0; j < n; j++)
				{
					cout << "Enter ID of Dependency " << j + 1 << " : ";
					cin >> tempid;
					int k = checkid(tempid, tasks, i);
					while (k==-1)
					{
						cout << "Please Enter valid ID of Dependency " << j + 1 << " : ";
						cin >> tempid;
						k = checkid(tempid, tasks, i);
					}
					tasks[i].dep[tasks[i].depsize] = k;//storing index of predecessor
					tasks[i].depsize++;
				}
			}
		}

	}

	//Main working of Program
	void setTaskDuration(task* tasks, int size)//change task duration of all tasks
	{
		for (int i = 0; i < size; i++)
		{
			if (tasks[i].depsize == 0)
			{
				tasks[i].s_Time = 0;
				tasks[i].e_Time = tasks[i].s_Time + tasks[i].dur;
			}
		}

		for (int i = 0; i < size; i++)
		{
			if (tasks[i].depsize > 0)
			{
				int n = tasks[i].depsize;
				int h = tasks[tasks[i].dep[0]].e_Time;
				for (int j = 1; j < n; j++)
				{
					if (tasks[tasks[i].dep[j]].e_Time > h)
					{
						h = tasks[tasks[i].dep[j]].e_Time;
					}
				}
				tasks[i].s_Time = h;
				tasks[i].e_Time= tasks[i].s_Time + tasks[i].dur;
			}
		}

		task* reverse = new task[size];
		
		for (int i = 0; i < size; i++)
		{
			reverse[i].id = tasks[i].id;
			reverse[i].dur = tasks[i].dur;
			reverse[i].s_Time = tasks[i].s_Time;
			reverse[i].e_Time = tasks[i].e_Time;
		}

		for (int i = size - 1; i >= 0; i--)
		{
			if (tasks[i].depsize > 0)
			{
				int n = tasks[i].depsize;
				
				for (int k = 0; k < n; k++)
				{
					if (reverse[tasks[i].dep[k]].depsize==0)
						reverse[tasks[i].dep[k]].dep = new int[reverse[tasks[i].dep[k]].depsize + 1];
					else
					{
						int* temp = new int[reverse[tasks[i].dep[k]].depsize + 1];
						for (int c = 0; c < reverse[tasks[i].dep[k]].depsize; c++)
						{
							temp[c] = reverse[tasks[i].dep[k]].dep[c];
						}
						delete[] reverse[tasks[i].dep[k]].dep;
						reverse[tasks[i].dep[k]].dep = temp;
						temp = NULL;
					}
					
					reverse[tasks[i].dep[k]].dep[reverse[tasks[i].dep[k]].depsize] = i;
					reverse[tasks[i].dep[k]].depsize++;
				}
			}
		}

		reverse[size - 1].LFtime = reverse[size - 1].e_Time;
		reverse[size - 1].LStime = reverse[size - 1].LFtime - reverse[size - 1].dur;

		for (int i = size - 2; i >= 0; i--)
		{
			if (reverse[i].depsize > 0)
			{
				int n = reverse[i].depsize;
				int l = reverse[reverse[i].dep[0]].LStime;
				for (int j = 1; j < n; j++)
				{
					if (reverse[reverse[i].dep[j]].LStime < l)
					{
						l = reverse[reverse[i].dep[j]].LStime;
					}
				}
				reverse[i].LFtime = l;
				reverse[i].LStime = reverse[i].LFtime - reverse[i].dur;
			}
		}

		for (int i = 0; i < size; i++)
		{
			tasks[i].LFtime = reverse[i].LFtime;
			tasks[i].LStime = reverse[i].LStime;
		}

		delete[] reverse;
		reverse = NULL;
	}
		
	void set_nth_TaskDuration(task* tasks, int k)//change duration of a specific task
	{
		if (tasks[k].depsize == 0)
		{
			tasks[k].s_Time = 0;
			tasks[k].e_Time = tasks[k].s_Time + tasks[k].dur;
		}

		else if (tasks[k].depsize > 0)
		{
			int n = tasks[k].depsize;
			int h = tasks[tasks[k].dep[0]].e_Time;
			for (int j = 1; j < n; j++)
			{
				if (tasks[tasks[k].dep[j]].e_Time > h)
				{
					h = tasks[tasks[k].dep[j]].e_Time;
				}
			}
			tasks[k].s_Time = h;
			tasks[k].e_Time = tasks[k].s_Time + tasks[k].dur;
		}
	}

	void printTaskDependencyList(task* tasks)//print dependencies of a specific task
	{
		if (this->depsize == 0)
		{
			cout << this->id << " task has no predecessor.." << endl;
		}
		else
		{
			cout << "Dependencies of task " << this->id << " are \n";
			for (int i = 0; i < this->depsize; i++)
			{
				cout << i + 1 << ". " << tasks[dep[i]].id << " with " << tasks[dep[i]].dur << " duration" << endl;
			}
		}
	}

	~task()
	{
		delete[] dep;
		dep = NULL;
	}
};

int task::base = 11;

class project {
private:
	int id;
	int t; //duration of project
	task* tasks;
	int tasksize;
	task* critical;
	int criticalsize;
	Resource* R;
	int resshort;

public:
	project()// default constructor
	{
		id = t = tasksize = criticalsize = resshort = 0;
		tasks = critical = NULL;
		R = NULL;
	}
		
	void projectmanagement(task* ts, int n)//initialized the project with n tasks
	{
		id = t = tasksize = criticalsize = resshort = 0;
		tasks = ts;
		critical = NULL;
		ts = NULL;

		R = new Resource[10];

		tasksize = n;

		tasks->addTasks(tasks, tasksize);
		tasks->setTaskDuration(tasks, tasksize);
		cout << "\nList of all Tasks with their Predecessors/Dependencies..\n";
		for (int i = 0; i < tasksize; i++)
		{
			tasks[i].printTaskDependencyList(tasks);
			cout << endl;
		}
	}

	void initresources()
	{
		for (int i = 0; i < 10; i++)
			R[i].res_Availability = true;

		R[0].res_Id = 101;
		R[1].res_Id = 111;
		R[2].res_Id = 222;
		R[3].res_Id = 333;
		R[4].res_Id = 444;
		R[5].res_Id = 555;
		R[6].res_Id = 666;
		R[7].res_Id = 777;
		R[8].res_Id = 888;
		R[9].res_Id = 999;

		R[0].res_Skill = 'A';
		R[1].res_Skill = 'B';
		R[2].res_Skill = 'C';
		R[3].res_Skill = 'D';
		R[4].res_Skill = 'A';
		R[5].res_Skill = 'B';
		R[6].res_Skill = 'C';
		R[7].res_Skill = 'D';
		R[8].res_Skill = 'A';
		R[9].res_Skill = 'C';
	}

	void displayresources()
	{
		cout << "\nAvailable Resources:\n";
		for (int i = 0; i < 10; i++)
		{
			if (R[i].res_Availability == true)
			{
				cout << i + 1 << ". " << R[i].res_Id << " with " << R[i].res_Skill << endl;
			}
		}
	}

	void assignresources()
	{
		cout << "\nAssigning tasks to Resources..\n";
		
		int count = 0;
		for (int i = 0; i < tasksize; i++)
		{
			for (int j = 0; j < 10; j++)
			{
				if (tasks[i].getskill() == R[j].res_Skill)
				{
					if (R[j].res_Availability == true)
					{
						tasks[i].setresource(R[j]);
						R[j].res_Availability = false;
						count++;
						break;
					}
				}
			}
		}

		if (count == tasksize)
		{
			cout << "\nTasks assigned to resources are \n";
			for (int i = 0; i < tasksize; i++)
			{
				cout << i + 1 << ". Task " << tasks[i].getid() << " is assigned to " << tasks[i].getresource().res_Id << endl;
			}
		}
		else if (count<tasksize)
		{
			resshort = tasksize - count;
			cout << "\nThe company currently has insufficient resources for this project..\n"
				<< "You may face delay in this project..\n";
		}
	}

	void completionTime()//print completion time of the project
	{
		int x = tasks[0].get_e_Time();
		for (int i = 1; i < tasksize; i++)
		{
			if (tasks[i].get_e_Time() > x)
				x = tasks[i].get_e_Time();
		}
		t = x;
		cout << "Planned Completion Time of Project is " << x << endl;
	}
	
	void printCriticalTasks()/*returns array of critical tasks and displays them � sum of their duration should be equal to project completion time*/
	{
		task* temptasks = new task[tasksize];
		int count = 0;

		for (int i = 0; i < tasksize; i++)
		{
			if ((tasks[i].get_LStime() == tasks[i].get_s_Time()) && (tasks[i].get_e_Time() == tasks[i].get_LFtime()))
			{
				temptasks[count] = tasks[i];
				count++;
			}
		}

		critical = new task[count];
		criticalsize = count;
		for (int i = 0; i < count; i++)
		{
			critical[i] = temptasks[i];
		}

		delete[] temptasks;
		temptasks = NULL;

		cout << "\nCritical tasks are \n";
		for (int i = 0; i < count; i++)
		{
			cout << i+1 << ". " << critical[i].getid() << " with " << critical[i].getdur() << " duration." << endl;
		}
	}

	void completionTimeWithResources()//for PART B
	{
		if (resshort == 0)
			cout << "Expected completion Time with Resources: " << t << endl;
		else
			cout << "Expected completion time with available Resources: " << (resshort * 4) + t << endl;
	}

	~project()
	{
		delete[] R;
		R = NULL;
	}
};

int main()
{
	int n;
	cout << "Enter number of projects that the company currently have: ";
	cin >> n;

	project* P = new project[n];
	for (int i = 0; i < n; i++)
	{
		int x;
		cout << "Enter number of tasks that project " << i + 1 << " have: ";
		cin >> x;

		task* ts = new task[x];

		P[i].projectmanagement(ts, x);
		P[i].completionTime();
		P[i].printCriticalTasks();
		P[i].completionTimeWithResources();
	}
	
	delete[] P;
	P = NULL;
}
