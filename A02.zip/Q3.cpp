//Fahad Waheed	20I-0651

#pragma warning (disable:4996)

/*
Please use this program using this initial data..
And u can also add more data if u want to..

Initial Sales Person:
	Employee 1 ID = 111;
	Employee 1 Name = "Bilal Ahmad";
	Employee 1 Fixed Salary = 25000;

	Employee 2 ID = 222;
	Employee 2 Name = "Ashfaq";
	Employee 2 Fixed Salary = 35000;

	Employee 3 ID = 333;
	Employee 3 Name = "Syed Umer";
	Employee 3 Fixed Salary = 30000;

Initial Books:
	bk[0].id = 1;
	bk[0].type = "Science Fiction";
	bk[0].bookName = "The Stranger Things v1";
	bk[0].authorName = "The Duffer Brothers";
	bk[0].price = 2500;
	bk[0].quantity = 5;

	bk[1].id = 2;
	bk[1].type = "Science Fiction";
	bk[1].bookName = "The Stranger Things v2";
	bk[1].authorName = "The Duffer Brothers";
	bk[1].price = 3500;
	bk[1].quantity = 5;

	bk[2].id = 3;
	bk[2].type = "Science Fiction";
	bk[2].bookName = "The Stranger Things v3";
	bk[2].authorName = "The Duffer Brothers";
	bk[2].price = 4000;
	bk[2].quantity = 5;

	bk[3].id = 4;
	bk[3].type = "History";
	bk[3].bookName = "Crossed Swords";
	bk[3].authorName = "Shuja Nawaz";
	bk[3].price = 2000;
	bk[3].quantity = 5;

	bk[4].id = 5;
	bk[4].type = "History";
	bk[4].bookName = "What is wrong with Pakistan";
	bk[4].authorName = "Babar Ayaz";
	bk[4].price = 3000;
	bk[4].quantity = 5;

	bk[5].id = 6;
	bk[5].type = "History";
	bk[5].bookName = "Democracy and Authoritarianism in South Asia";
	bk[5].authorName = "Ayesha Jalal";
	bk[5].price = 1895;
	bk[5].quantity = 5;

	bk[6].id = 7;
	bk[6].type = "History";
	bk[6].bookName = "Colonialism and its form of Knowledge";
	bk[6].authorName = "Bernard S. Cohn";
	bk[6].price = 4895;
	bk[6].quantity = 5;

	bk[7].id = 8;
	bk[7].type = "Adventure";
	bk[7].bookName = "Into Thin Air";
	bk[7].authorName = "John Krakauer";
	bk[7].price = 2895;
	bk[7].quantity = 5;

	bk[8].id = 9;
	bk[8].type = "Adventure";
	bk[8].bookName = "Treasure Island";
	bk[8].authorName = "Robert Louis Stevenson";
	bk[8].price = 2599;
	bk[8].quantity = 5;

	bk[9].id = 10;
	bk[9].type = "Adventure";
	bk[9].bookName = "Moby Dick";
	bk[9].authorName = "Herman Melville";
	bk[9].price = 2699;
	bk[9].quantity = 5;
*/

#include<iostream>
#include<string>
#include<iomanip>

using namespace std;

struct Address
{
	int house_no{};
	string area;
	string city;
};
struct Book {
	int id{};
	string type;
	char* bookName{};
	char* authorName{};
	double price{};
	int quantity{};
};
struct Salary {
	double fixedSalary{}; //every salesperson has a fixed salary for a daily wager Rs. 15000/-
	double comission{}; //2% of sale price of all the books sold
};
struct Customer {
	int cust_No{};
	char* cust_Name{}; //duration of project
	Address cust_Address; //structure itself
	Book bk; //
};
struct Sales_Person {//to store data of each sales person
	int emp_ID{};
	char* emp_Name{}; //duration of project
	double Sales{};
	Customer* emp_Customer_Array{}; //array of customers that salesperson sold books to
	Salary emp_sal; //salary of the employee
	int csize{};
};

void initial_sales_person(Sales_Person* SP);
void initialbooks(Book* bk);
void newsalesperson(Sales_Person* OSP, int osize, Sales_Person* NSP, int nsize);
Sales_Person inputsalesperson();
void newbooks(Book* oldbook, int osize, Book* newbook, int nsize);
Book inputbook();
void totalSalesbySalesPerson(Sales_Person* SP, int i);
void displayallbooks(Book* books, int size);
void displayallSP(Sales_Person* SP, int size);
void totalSales(Sales_Person* SP, int size);
void Sorting(Sales_Person* SP, int size);
void topSalesPerson(Sales_Person* SP, int size);
void Commission(Sales_Person* SP, int size);
void TotalSalary(Sales_Person* SP, int size);
void booksInventory(Book* books, int size);
void booksInventoryByType(Book* books, int size);
void Sale(Sales_Person* SP, int* spsize, Book* books, int* booksize);

int main()
{
	int SPsize = 3;
	Sales_Person *SP=new Sales_Person[SPsize];
	initial_sales_person(SP);
	int booksize = 10;
	Book * books=new Book[booksize];
	initialbooks(books);
	int choice;
	do
	{
		do
		{
			cout << "\nEnter 1 if u want add a sale.\nEnter 2 if u want to add a book.\n"
				<< "Enter 3 if u want to add a sales person.\n"
				<< "Enter 4 if u want to see total sale.\n"
				<< "Enter 5 if u want to see sales done by a specific sale person.\n"
				<< "Enter 6 if u want to see top sales done by sale persons.\n"
				<< "Enter 7 if u want to see commission of sales person.\n"
				<< "Enter 8 if u want to see total salary that owner has to pay.\n"
				<< "Enter 9 to see total books in inventory.\n"
				<< "Enter 10 to see number of books in inventory by type.\n"
				<< "Enter 11 to display all books.\n"
				<< "Enter 12 to see all Sales Person.\n"
				<< "Enter 0 to exit.\n";
			cout << "Enter ur choice: ";
			cin >> choice;
		} while (!(choice >= 0 && choice <= 12));

		switch (choice)
		{
			case 0:
				exit(0);

			case 1:
			{
				Sale(SP, &SPsize, books, &booksize);
				break;
			}

			case 2:
			{
				int os = booksize;
				int temp;
				cout << "Enter number of new books that u want to add: ";
				cin >> temp;
				booksize = temp + os;
				Book* ptr = new Book[booksize];

				newbooks(books, os, ptr, booksize);
				delete[] books;
				books = ptr;
				break;
			}

			case 3:
			{
				int os = SPsize;
				int temp;
				cout << "Enter number of new sales person that u want to add: ";
				cin >> temp;
				SPsize = temp + os;
				Sales_Person* ptr1 = new Sales_Person[SPsize];

				newsalesperson(SP, os, ptr1, SPsize);
				delete[] SP;
				SP = ptr1;
				break;
			}
			
			case 4:
			{
				totalSales(SP, SPsize);
				break;
			}

			case 5:
			{
				int temp;

				cout << "Enter ID of sales person: ";
				cin >> temp;
				int check = -1;
				for (int i = 0; i < SPsize; i++)
				{
					if (temp == SP[i].emp_ID)
					{
						check = i;
						break;
					}
				}

				if (check == -1)
				{
					cout << "Wrong input..";
				}
				else
					totalSalesbySalesPerson(SP, check);

				break;
			}

			case 6:
			{
				topSalesPerson(SP, SPsize);

				break;
			}

			case 7:
			{
				Commission(SP, SPsize);

				break;
			}

			case 8:
			{
				TotalSalary(SP, SPsize);

				break;
			}

			case 9:
			{
				booksInventory(books, booksize);

				break;
			}

			case 10:
			{
				booksInventoryByType(books, booksize);

				break;
			}

			case 11:
			{
				displayallbooks(books, booksize);

				break;
			}

			case 12:
			{
				displayallSP(SP, SPsize);
			}
		}
		
	}
	while (choice >= 0 && choice <= 12);

	for (int i = 0; i < SPsize; i++)
	{
		delete[] SP[i].emp_Name;
		for (int j = 0; j < SP[i].csize; j++)
		{
			delete[] SP[i].emp_Customer_Array[j].cust_Name;
		}
		delete[] SP[i].emp_Customer_Array;
	}

	for (int i = 0; i < booksize; i++)
	{
		delete[] books[i].bookName;
		delete[] books[i].authorName;
	}

	delete[] books;
	delete[] SP;
}

void initial_sales_person(Sales_Person* SP)
{
	string temp;
	
	SP[0].emp_ID = 111;
	temp = "Bilal Ahmad";
	SP[0].emp_Name = new char[(temp.length())+1];
	strcpy(SP[0].emp_Name, temp.c_str());
	SP[0].emp_sal.fixedSalary = 25000;
	SP[0].csize = 1;
	SP[0].emp_Customer_Array = new Customer[SP[0].csize];

	SP[1].emp_ID = 222;
	temp = "Ashfaq";
	SP[1].emp_Name = new char[(temp.length()) + 1];
	strcpy(SP[1].emp_Name, temp.c_str());
	SP[1].emp_sal.fixedSalary = 35000;
	SP[1].csize = 1;
	SP[1].emp_Customer_Array = new Customer[SP[1].csize];

	SP[2].emp_ID = 333;
	temp = "Syed Umer";
	SP[2].emp_Name = new char[(temp.length()) + 1];
	strcpy(SP[2].emp_Name, temp.c_str());
	SP[2].emp_sal.fixedSalary = 30000;
	SP[2].csize = 1;
	SP[2].emp_Customer_Array = new Customer[SP[2].csize];
}

void initialbooks(Book* bk)
{
	string temp;
	
	bk[0].id = 1;
	bk[0].type = "Science Fiction";
	temp = "The Stranger Things v1";
	bk[0].bookName = new char[temp.length() + 1];
	strcpy(bk[0].bookName, temp.c_str());
	temp = "The Duffer Brothers";
	bk[0].authorName = new char[temp.length() + 1];
	strcpy(bk[0].authorName, temp.c_str());
	bk[0].price = 2500;
	bk[0].quantity = 5;

	bk[1].id = 2;
	bk[1].type = "Science Fiction";
	temp = "The Stranger Things v2";
	bk[1].bookName = new char[temp.length() + 1];
	strcpy(bk[1].bookName, temp.c_str());
	temp = "The Duffer Brothers";
	bk[1].authorName = new char[temp.length() + 1];
	strcpy(bk[1].authorName, temp.c_str());
	bk[1].price = 3500;
	bk[1].quantity = 5;

	bk[2].id = 3;
	bk[2].type = "Science Fiction";
	temp = "The Stranger Things v3";
	bk[2].bookName = new char[temp.length() + 1];
	strcpy(bk[2].bookName, temp.c_str());
	temp = "The Duffer Brothers";
	bk[2].authorName = new char[temp.length() + 1];
	strcpy(bk[2].authorName, temp.c_str());
	bk[2].price = 4000;
	bk[2].quantity = 5;

	bk[3].id = 4;
	bk[3].type = "History";
	temp = "Crossed Swords";
	bk[3].bookName = new char[temp.length() + 1];
	strcpy(bk[3].bookName, temp.c_str());
	temp = "Shuja Nawaz";
	bk[3].authorName = new char[temp.length() + 1];
	strcpy(bk[3].authorName, temp.c_str());
	bk[3].price = 2000;
	bk[3].quantity = 5;

	bk[4].id = 5;
	bk[4].type = "History";
	temp = "What is wrong with Pakistan";
	bk[4].bookName = new char[temp.length() + 1];
	strcpy(bk[4].bookName, temp.c_str());
	temp = "Babar Ayaz";
	bk[4].authorName = new char[temp.length() + 1];
	strcpy(bk[4].authorName, temp.c_str());
	bk[4].price = 3000;
	bk[4].quantity = 5;

	bk[5].id = 6;
	bk[5].type = "History";
	temp = "Democracy and Authoritarianism in South Asia";
	bk[5].bookName = new char[temp.length() + 1];
	strcpy(bk[5].bookName, temp.c_str());
	temp = "Ayesha Jalal";
	bk[5].authorName = new char[temp.length() + 1];
	strcpy(bk[5].authorName, temp.c_str());
	bk[5].price = 1895;
	bk[5].quantity = 5;

	bk[6].id = 7;
	bk[6].type = "History";
	temp = "Colonialism and its form of Knowledge";
	bk[6].bookName = new char[temp.length() + 1];
	strcpy(bk[6].bookName, temp.c_str());
	temp = "Bernard S. Cohn";
	bk[6].authorName = new char[temp.length() + 1];
	strcpy(bk[6].authorName, temp.c_str());
	bk[6].price = 4895;
	bk[6].quantity = 5;

	bk[7].id = 8;
	bk[7].type = "Adventure";
	temp = "Into Thin Air";
	bk[7].bookName = new char[temp.length() + 1];
	strcpy(bk[7].bookName, temp.c_str());
	temp = "John Krakauer";
	bk[7].authorName = new char[temp.length() + 1];
	strcpy(bk[7].authorName, temp.c_str());
	bk[7].price = 2895;
	bk[7].quantity = 5;

	bk[8].id = 9;
	bk[8].type = "Adventure";
	temp = "Treasure Island";
	bk[8].bookName = new char[temp.length() + 1];
	strcpy(bk[8].bookName, temp.c_str());
	temp = "Robert Louis Stevenson";
	bk[8].authorName = new char[temp.length() + 1];
	strcpy(bk[8].authorName, temp.c_str());
	bk[8].price = 2599;
	bk[8].quantity = 5;

	bk[9].id = 10;
	bk[9].type = "Adventure";
	temp = "Moby Dick";
	bk[9].bookName = new char[temp.length() + 1];
	strcpy(bk[9].bookName, temp.c_str());
	temp = "Herman Melville";
	bk[9].authorName = new char[temp.length() + 1];
	strcpy(bk[9].authorName, temp.c_str());
	bk[9].price = 2699;
	bk[9].quantity = 5;
}

void newsalesperson(Sales_Person* OSP, int osize, Sales_Person* NSP, int nsize)
{
	for (int i = 0; i < osize; i++)
	{
		NSP[i] = OSP[i];
	}

	for (int i = osize; i < nsize; i++)
	{
		NSP[i] = inputsalesperson();
	}
}

Sales_Person inputsalesperson()
{
	Sales_Person temp;
	cout << "Enter ID of Sales Person: ";
	cin >> temp.emp_ID;
	cin.ignore();
	string tempname;
	cout << "Enter name of Sales Person: ";
	getline(cin, tempname);
	temp.emp_Name = new char[tempname.length() + 1];
	strcpy(temp.emp_Name, tempname.c_str());

	cout << "Enter Salary: ";
	cin >> temp.emp_sal.fixedSalary;

	temp.csize = 1;
	temp.emp_Customer_Array = new Customer[temp.csize];
	
	return temp;
}

void newbooks(Book* oldbook, int osize, Book* newbook, int nsize)
{
	for (int i = 0; i < osize; i++)
	{
		newbook[i] = oldbook[i];
	}

	for (int i = osize; i < nsize; i++)
	{
		cout << "Enter data for book " << i + 1<<" : ";
		newbook[i] = inputbook();
	}
}

Book inputbook()
{
	Book book;
	string temp;
	cout << "Enter id of book: ";
	cin >> book.id;
	cin.ignore();
	cout << "Enter type of book: ";
	getline(cin, book.type);

	cout << "Enter name of book: ";
	getline(cin, temp);
	book.bookName = new char[temp.length() + 1];
	strcpy(book.bookName, temp.c_str());

	cout << "Enter name of author of book: ";
	getline(cin, temp);
	book.authorName = new char[temp.length() + 1];
	strcpy(book.authorName, temp.c_str());

	cout << "Enter price of book: ";
	cin >> book.price;

	cout << "Enter quantity: ";
	cin >> book.quantity;

	return book;
}

void totalSalesbySalesPerson(Sales_Person* SP, int i)
{
	cout << "\nSales done by " << SP[i].emp_Name << " is " << SP[i].Sales << endl;
}

void displayallbooks(Book* books, int size)
{
	cout << left<<setw(5)<<"ID"<<setw(20)<<"Type"<<setw(45)<<"Book"<<setw(30)<<"Author"<<setw(8)<<"Quantity\n";
	for (int i = 0; i < size; i++)
	{
		cout << left << setw(5) << books[i].id << setw(20) << books[i].type << setw(45) << books[i].bookName << setw(30) << books[i].authorName << setw(8) << books[i].quantity << endl;
	}
}

void displayallSP(Sales_Person* SP, int size)
{
	cout << left << setw(10) << "ID" << setw(20) << "Employee Name" << setw(15) << "Fixed Salary"<<endl;
	for (int i = 0; i < size; i++)
	{
		cout << left << setw(10) << SP[i].emp_ID << setw(20) << SP[i].emp_Name << setw(15) << SP[i].emp_sal.fixedSalary << endl;
	}
}

void totalSales(Sales_Person* SP, int size)
{
	double sum = 0.0;
	for (int i = 0; i < size; i++)
	{
		sum += SP[i].Sales;
	}

	cout << "Total Sales: " << sum << endl;
}

void Sorting(Sales_Person* SP, int size)
{
	Sales_Person temp;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size - i - 1; j++)
		{
			if (SP[j].Sales < SP[j + 1].Sales)
			{
				temp = SP[j];
				SP[j] = SP[j + 1];
				SP[j + 1] = temp;
			}
		}
	}
}

void topSalesPerson(Sales_Person* SP, int size)
{
	Sales_Person* temp = new Sales_Person[size];

	for (int i = 0; i < size; i++)
	{
		temp[i] = SP[i];
	}

	Sorting(temp, size);
	cout << "Top Sales: ";

	for (int i = 0; i < size; i++)
	{
		totalSalesbySalesPerson(temp, i);
	}

	delete[] temp;
	temp = 0;
}

void Commission(Sales_Person* SP, int size)
{
	cout << "\nCommission of Sales Person: \n";
	for (int i = 0; i < size; i++)
	{
		SP[i].emp_sal.comission = 0.02 * SP[i].Sales;
		cout << "Commission of " << SP[i].emp_Name << " is " << SP[i].emp_sal.comission << endl;
	}
}

void TotalSalary(Sales_Person* SP, int size)
{
	double total = 0;
	double com = 0;
	double salary = 0;

	for (int i = 0; i < size; i++)
	{
		com += SP[i].emp_sal.comission;
		salary += SP[i].emp_sal.fixedSalary;
	}

	total = com + salary;

	cout << "\nTotal Salary that the Employer has to pay: " << total << endl;
}

void booksInventory(Book* books, int size)
{
	int quantity = 0;

	for (int i = 0; i < size; i++)
	{
		quantity += books[i].quantity;
	}

	cout << "Total number of books left: " << quantity;
}

void booksInventoryByType(Book* books, int size)
{
	int sq = 0, aq = 0, hq = 0;

	for (int i = 0; i < size; i++)
	{
		if (books[i].type == "Science Fiction")
		{
			sq += books[i].quantity;
		}

		else if (books[i].type == "History")
		{
			hq += books[i].quantity;
		}

		else if (books[i].type == "Adventure")
		{
			aq += books[i].quantity;
		}
	}

	cout << "Quantity of Science Fiction Books: " << sq << endl;
	cout << "Quantity of History Books: " << hq << endl;
	cout << "Quantity of Adventure Books: " << aq << endl;
}

void Sale(Sales_Person* SP, int* spsize, Book* books, int* booksize)
{
	int tempid;
	cout << "Enter your ID(Sales Person): ";
	cin >> tempid;
	int sindex = -1;

	for (int i = 0; i < *spsize; i++)
	{
		if (tempid == SP[i].emp_ID)
		{
			sindex = i;
		}
	}

	if (sindex == -1)
	{
		cout << "Sorry! you are not an employee.";
		return;
	}
	
	int cindex = SP[sindex].csize;

	Customer* temp_Customer_Array = new Customer[cindex];

	for (int i = 0; i < cindex-1; i++)
	{
		temp_Customer_Array[i] = SP[sindex].emp_Customer_Array[i];
	}

	cout << "Enter ID of your Customer: ";
	cin >> temp_Customer_Array[cindex-1].cust_No;
	cin.ignore();
	string te;
	cout << "Enter name of Customer: ";
	getline(cin, te);
	temp_Customer_Array[cindex - 1].cust_Name = new char[te.length() + 1];
	strcpy(temp_Customer_Array[cindex - 1].cust_Name, te.c_str());

	cout << "Enter house # of Customer: ";
	cin >> temp_Customer_Array[cindex-1].cust_Address.house_no;
	cin.ignore();
	cout << "Enter area of customer: ";
	getline(cin, temp_Customer_Array[cindex-1].cust_Address.area);

	cout << "Enter city of Customer: ";
	getline(cin, temp_Customer_Array[cindex-1].cust_Address.city);

	int r;
	repeat:
	string btemp;
	cout << "Enter name of book: ";
	getline(cin, btemp);
	int bookid = -1;

	for (int i = 0; i < *booksize; i++)
	{
		if (btemp == books[i].bookName)
		{
			cout << "Book found";
			bookid = i;
			break;
		}
	}
	r = 0;
	if (bookid == -1)
	{
		cout << "Book not found";
		cout << "\nIf u want to search for another book enter 1: ";
		cin >> r;
		cin.ignore();
		if (r == 1)
			goto repeat;

		return;
	}
	
	if (books[bookid].quantity == 0)
	{
		cout << "Out of stock!";

		cout << "\nIf u want to search for another book enter 1: ";
		cin >> r;
		if (r == 1)
			goto repeat;

		return;
	}

	temp_Customer_Array[cindex-1].bk = books[bookid];
	
	temp_Customer_Array[cindex-1].bk.quantity = 1;
	books[bookid].quantity -= 1;

	SP[sindex].Sales += temp_Customer_Array[cindex-1].bk.price;
	
	cout << "\nBill of " << temp_Customer_Array[cindex-1].cust_Name << " is " << temp_Customer_Array[cindex-1].bk.price << endl;

	SP[sindex].emp_Customer_Array[cindex - 1] = temp_Customer_Array[cindex - 1];

	SP[sindex].csize++;
	cout<<"\nPress Enter if u want to exit.\n";
	cin.get();

	delete[] SP[sindex].emp_Customer_Array;
	
	SP[sindex].emp_Customer_Array = temp_Customer_Array;

	temp_Customer_Array = nullptr;
}