//Fahad Waheed	20I-0651

#include<iostream>
#include<time.h>
#include<string>
#include<cstdlib>

#pragma warning(disable : 4996)

using namespace std;

//Functions and structures used in this program for date and time are from time.h library
//time_t is used for representing the system time and date as some sort of integer.
/*struct tm
{
	int tm_sec;   	// seconds of minutes from 0 to 59
	int tm_min;   	// minutes of hour from 0 to 59
	int tm_hour;  	// hours of day from 0 to 24
	int tm_mday;  	// day of month from 1 to 31
	int tm_mon;   	// month of year from 0 to 11
	int tm_year;  	// year since 1900
	int tm_wday;  	// days since Sunday
	int tm_yday;  	// days since January 1st
	int tm_isdst; 	// hours of daylight savings time
}*/

class task
{
	string name;
	string date;
	string time;
public:
	task() //assigning default values
	{
		name = date = time = "NULL";
	}
	task(string n, string d, string t)
	{
		name = n;
		date = d;
		time = t;
	}

	string getname()
	{
		return name;
	}

	string getdate()
	{
		return date;
	}

	string gettime()
	{
		return time;
	}

	void setname(string n)
	{
		name = n;
	}

	void setdate(string d)
	{
		date = d;
	}

	void settime(string t)
	{
		time = t;
	}
};

class mirror
{
	string date;
	string Time;
	string quote[7];
	task* upcoming_task;
	int tindex{};

public:
	mirror() 
	{
		date = "NULL";
		Time = "NULL";
		upcoming_task = new task[1];
		tindex = 0;
		upcoming_task->setdate("NULL");
		upcoming_task->setname("NULL");
		upcoming_task->settime("NULL");
	}

	task gettask(int i)
	{
		return upcoming_task[i];
	}

	string getdate()
	{
		return date;
	}

	string getTime()
	{
		return Time;
	}

	void setdate(string d)
	{
		date = d;
	}

	void setTime(string t)
	{
		Time = t;
	}

	string getquote(int i)
	{
		return quote[i];
	}

	int gettindex()
	{
		return tindex;
	}

	void settindex(int i)
	{
		tindex = i;
	}

	string DateFormatting(int i)
	{
		string h;
		time_t dt = time(nullptr);
		string c = ctime(&dt);
		tm* itm = localtime(&dt);
		string day, month, year;

		if (itm->tm_mday < 10)
			day = "0" + to_string(itm->tm_mday);
		else
			day = to_string(itm->tm_mday);

		if ((1 + (itm->tm_mon)) < 10)
			month = "0" + to_string(1 + (itm->tm_mon));
		else
			month = to_string(1 + (itm->tm_mon));

		if (i == 1)
		{
			h = day + "/" + month + "/" + to_string(1900 + (itm->tm_year));
		}
		else if (i == 2)
		{
			string month1 = { c[4], c[5], c[6] };
			h = day + " " + month1 + ", " + to_string(1900 + (itm->tm_year));
		}
		return h;
	}

	string TimeFormatting(int i)
	{
		string d;
		time_t dt = time(nullptr);
		tm* itm = localtime(&dt);
		string hours, mins;

		if (itm->tm_min < 10)
			mins = "0" + to_string(itm->tm_min);
		else
			mins = to_string(itm->tm_min);

		if (i == 1)//in 24h format
		{
			if (itm->tm_hour < 10)
				hours = "0" + to_string(itm->tm_hour);
			else
				hours = to_string(itm->tm_hour);
			
			d = hours + ":" + mins;
		}
		else if (i == 2)//in 12h format
		{
			string tt;
			int h = itm->tm_hour;

			if (h < 12)
				tt = "AM";
			else
				tt = "PM";

			h %= 12;//if h=1 or 13, h=2 or 14 etc.
			if (h == 0)//if h= 24 or 12
			{
				h = 12;
			}
			if (h < 10)
				hours = "0" + to_string(h);
			else
				hours = to_string(h);
			
			d = hours + ":" + mins + " " + tt;
		}
		return d;
	}

	void initialquotes()
	{
		quote[0] = "Be fearful when others are greedy\nand greedy when others are fearful.";
		quote[1] = "You miss 100% of the shots you don't take.";
		quote[2] = "Whether you think you can or you think you can't,\n you're right.";
		quote[3] = "I alone cannot change the world, but I can\ncast a stone across the water to create many ripples.";
		quote[4] = "The way to get started is to quit talking and begin doing.";
		quote[5] = "Life is what happens when you're busy making other plans.";
		quote[6] = "The future belongs to those who believe in the beauty of their dreams.";
	}

	void editquote(int i)
	{
		cout << "Enter new quote to edit quote no. " << i << " : ";
		getline(cin, quote[i - 1]);
	}

	void displayquotes()
	{
		for (int i = 0; i < 7; i++)
		{
			cout << i + 1 << ". " << quote[i] << endl;
		}
	}

	void addtask(int i)
	{
		task* new_upcoming_task = new task[i];
		for (int j = 0; j < i - 1; j++)
		{
			new_upcoming_task[j] = upcoming_task[j];
		}

		string n, d, t;
		cout << "Add name of task: ";
		getline(cin, n);
		cout << "Enter date of task: ";
		getline(cin, d);
		cout << "Enter time of task: ";
		getline(cin, t);

		new_upcoming_task[i-1].setname(n);
		new_upcoming_task[i-1].setdate(d);
		new_upcoming_task[i-1].settime(t);

		delete[] upcoming_task;
		upcoming_task = new_upcoming_task;
	}

	void removetask(int i)
	{
		for (int j = i; j < tindex; j++)
		{
			if (j == tindex-1)
			{
				upcoming_task[j].setdate("NULL");
				upcoming_task[j].setname("NULL");
				upcoming_task[j].settime("NULL");
			}
			else if (j<tindex-1)
				upcoming_task[j] = upcoming_task[j + 1];
		}
	}

	void displaytask(int i)
	{
		cout << "List of Upcoming tasks: \n";
		for (int j = 0; j < i; j++)
		{
			cout << j + 1 << ". name of task: " << upcoming_task[j].getname() << endl
				<< "date of task is " << upcoming_task[j].getdate() << endl
				<< "time of task is " << upcoming_task[j].gettime() << endl << endl;
		}
	}

	~mirror()
	{
		delete[] upcoming_task;
		upcoming_task = nullptr;
	}
};


int main()
{
	int t = 1, d = 1;//default formats
	int choice, choice1;
	mirror M1;
	M1.initialquotes();
	M1.settindex(0);

	int ndisplay = 3;//default number of tasks displaying
home:
	M1.setdate(M1.DateFormatting(d));
	M1.setTime(M1.TimeFormatting(t));

	cout << "Home: \n";
	cout << M1.getTime() << endl;
	cout << M1.getdate() << endl;
	cout << M1.getquote(rand() % 7) << endl;

	
	task temp;
	if (M1.gettindex() == 0)
	{
		temp = M1.gettask(0);
		if (temp.getname() == "NULL")
			cout << "No Upcoming Task." << endl;
	}
	else
	{
		cout << "Upcoming tasks:\n";
		for (int i = 0; i < ndisplay; i++)
		{
			if (i < M1.gettindex())
			{
				temp = M1.gettask(i);
				cout << i + 1 << ". " << temp.getname() << " (" << temp.getdate() << ")\n";
			}
		}
	}
	
	cout << "Press Enter to continue..";
	cin.get();

	cout << "\nEnter 1 to change setting..\nEnter 2 to go back to home.."
		<< "\nEnter 3 to shutdown the Mirror..\nEnter your choice: ";
	cin >> choice;
	while (!(choice > 0 && choice < 4))
	{
		cout << "Invalid Input!\n Please ";
		cout << "\nEnter 1 to change setting..\nEnter 2 to go back to home.."
			<< "\nEnter 3 to shutdown the Mirror..\nEnter your choice: ";
		cin >> choice;
	}

	switch (choice)
	{
	case 1:
	{
		cout << "\nSettings:\n";
		cout << "Press 1 to change format of date..\nEnter 2 to change format of time.."
			<< "\nEnter 3 to change quotes..\nEnter 4 to add a task.."
			<< "\nEnter 5 to remove a task..\nEnter 6 to look for all upcoming tasks.."
			<< "\nEnter 7 to change number of upcoming tasks displaying in home screen.."
			<< "\nEnter 8 to go back to home..\nEnter 9 to shut down the mirror.."
			<< "\nEnter your choice: ";

		
		cin >> choice1;
		while (!(choice1 > 0 && choice < 9))
		{
			cout << "Invalid Input!\nPlease Enter valid Input..\n";
			cout << "Press 1 to change format of date..\nEnter 2 to change format of time.."
				<< "\nEnter 3 to change quotes..\nEnter 4 to add a task.."
				<< "\nEnter 5 to remove a task..\nEnter 6 to look for all upcoming tasks.."
				<< "\nEnter 7 to change number of upcoming tasks displaying in home screen."
				<< "\nEnter 8 to go back to home..\nEnter 9 to shut down the mirror.."
				<< "\nEnter your choice: ";
			cin >> choice1;
		}

		switch (choice1)
		{
		case 1:
		{
			if (d == 1)
			{
				d = 2;
				cout << "\nDate format changed successfully.\n";
			}
			else if (d == 2)
			{
				d = 1;
				cout << "\nDate format changed successfully.\n";
			}
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}
		case 2:
		{
			if (t == 1)
			{
				t = 2;
				cout << "\nTime format changed successfully.\n";
			}
			else if (t == 2)
			{
				t = 1;
				cout << "\nTime format changed successfully.\n";
			}
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}
		case 3:
		{
			cout << "\nList of Quotes: \n";
			M1.displayquotes();

			int i = 0;

			cout << "Enter No# of quote to edit: ";
			cin >> i;
			while (!(i > 0 && i < 8))
			{
				cout << "Please enter valid No# of quote to edit: ";
				cin >> i;
			}
			cin.ignore();
			M1.editquote(i);
			cout << "\nAfter Changing: \nList of Quotes: \n";
			M1.displayquotes();
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}
		case 4:
		{
			cin.ignore();
			M1.addtask(M1.gettindex()+1);
			M1.settindex(M1.gettindex()+1);
			cout << "Task added successfully.\nAfter Completion kindly delete it.\n"
				<< "To get things working perfectly.\nThank You.\n";
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}
		case 5:
		{
			M1.displaytask(M1.gettindex());
			int no;
			cout << "Enter task # to remove: ";
			cin >> no;
			while (!(no < M1.gettindex() && no > 0))
			{
				cout << "Enter task # to remove: ";
				cin >> no;
			}

			M1.removetask(no - 1);
			M1.settindex((M1.gettindex()) - 1);
			cout << "\nTask removed Successfully.\n";
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}
		case 6:
		{
			M1.displaytask(M1.gettindex());
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}
		case 7:
		{
			cout << "Enter number of tasks you want to display on home screen: ";
			cin >> ndisplay;
			cout << "Settings Saved!";
			cout << "\nPress Enter to Continue..\n";
			cin.get();
			goto home;
		}


		case 8:
			goto home;

		case 9:
			exit(0);
		}
	}
	case 2:
		goto home;

	case 3:
		cout << "Shutting Down";
		cout << "\nPress Enter to Continue..\n";
		cin.get();
		exit(0);
	}
}
