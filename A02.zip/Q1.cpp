//Fahad Waheed	20I-0651

#include<iostream>
#include<cmath>

using namespace std;

struct coordinates
{
	int x, y;
};

struct rectangle
{
	coordinates p1, p2, p3, p4;
	double area;
};

void input(rectangle* array, int size);

double findarea(rectangle* array, int i);

void sorting(rectangle* array, int size);

void print(rectangle* array, int i);

void overlapping(rectangle* array, int size, int *rect, int* k);

bool findoverlap(rectangle* array, int size, int i);

int main()
{
	int size;
	cout << "Enter number of rectangles: ";
	cin >> size;

	rectangle* array = new rectangle[size];
	input(array, size);

	for (int i = 0; i < size; i++)
	{
		array[i].area = findarea(array, i);
	}

	for (int i = 0; i < size; i++)
	{
		print(array, i);
	}

	sorting(array, size);
	cout << "\n\nAfter Sorting:\n";

	for (int i = 0; i < size; i++)
	{
		print(array, i);
	}
	
	int osize=0;

	int* rect = new int[size];
	overlapping(array, size, rect, &osize);

	if (osize > 0)
	{
		cout << "\n\nThe rectangles who overlap the largest rectangle, which is :\n";
		print(array, size - 1);
		cout << ", are \n";
		for (int i = 0; i < osize; i++)
		{
			cout << i + 1 << ". ";
			print(array, *(rect+i));
			cout << endl;
		}
	}
	else
		cout << "\n\nthere is no rectangle who overlaps the largest rectangle.";

	delete[] rect, array;
	rect = nullptr;
	array = nullptr;
}

void input(rectangle* array, int size)
{
	cout << "Give input in this format: \n"
		<< "(x1,y1)         (x2,y2)\n"
		<< "       _________       \n"
		<< "      |         |      \n"
		<< "      |         |      \n"
		<< "      |         |      \n"
		<< "      |_________|      \n"
		<< "(x3,y3)         (x4,y4)\n";

	for (int i = 0; i < size; i++)
	{
		cout << "Enter data of rectangle " << i + 1 << endl;

		cout << "Please Enter valid point x1: ";
		cin >> array[i].p1.x;

		cout << "Please Enter valid point y1: ";
		cin >> array[i].p1.y;

		do
		{
			cout << "Please Enter valid point x2 (must not be equal to x1): ";
			cin >> array[i].p2.x;
		} while (array[i].p1.x == array[i].p2.x);


		do
		{
			cout << "Please Enter valid point y2 (must be equal to y1): ";
			cin >> array[i].p2.y;
		} while (!(array[i].p1.y == array[i].p2.y));

		do
		{
			cout << "Please Enter valid point x3 (must be equal to x1): ";
			cin >> array[i].p3.x;
		} while (!(array[i].p1.x == array[i].p3.x));

		do
		{
			cout << "Please Enter valid point y3 (must not be equal to y1 or y2): ";
			cin >> array[i].p3.y;
		} while (array[i].p3.y == array[i].p1.y);

		do
		{
			cout << "Please Enter valid point x4 (must be equal to x2): ";
			cin >> array[i].p4.x;
		} while (!(array[i].p2.x == array[i].p4.x));

		do
		{
			cout << "Please Enter valid point y4 (must be equal to y3): ";
			cin >> array[i].p4.y;
		} while (!(array[i].p3.y == array[i].p4.y));
	}
}

double findarea(rectangle* array, int i)
{
	double width = sqrt(pow((array[i].p2.x - array[i].p1.x), 2) + pow((array[i].p2.y - array[i].p1.y), 2));
	double length = sqrt(pow((array[i].p1.x - array[i].p3.x), 2) + pow((array[i].p1.y - array[i].p3.y), 2));

	return length * width;
}

void print(rectangle* array, int i)
{
	cout << "\nArea of Rectangle [(" 
		<< array[i].p1.x << "," << array[i].p1.y << "), ("
		<< array[i].p2.x << "," << array[i].p2.y << "), ("
		<< array[i].p3.x << "," << array[i].p3.y << "), ("
		<< array[i].p4.x << "," << array[i].p4.y << ")] is " 
		<< array[i].area << endl;
}

void sorting(rectangle* array, int size)
{
	rectangle temp;
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = 0; j < size - i - 1; j++)
		{
			if (array[j].area > array[j + 1].area)
			{
				temp = array[j + 1];
				array[j + 1] = array[j];
				array[j] = temp;
			}
		}
	}
}

void overlapping(rectangle* array, int size, int *rect, int *k)
{
	bool check;
	for (int i = 0; i < size - 1; i++)
	{
		check = findoverlap(array, size, i);

		if (check == true)
		{
			rect[*k] = i;
			(*k)++;
		}
	}
}

bool findoverlap(rectangle* array, int size, int i)
{
	coordinates l1, r1, l2, r2;

	l1.x = array[size - 1].p3.x;
	l2.x = array[i].p3.x;
	r2.x = array[i].p2.x;
	r1.x = array[size - 1].p2.x;

	l1.y = array[size - 1].p3.y;
	l2.y = array[i].p3.y;
	r2.y = array[i].p2.y;
	r1.y = array[size - 1].p2.y;

	bool check = true;

	//If sides of rectangle touches
	bool condition1 = l1.x == r1.x || l1.y == r2.y 
					|| l2.x == r2.x || l2.y == r2.y;

	//If one rectangle is on left side of other
	bool condition2 = l1.x >= r2.x || l2.x >= r1.x;

	//If one rectangle is above other
	bool condition3 = l1.y <= r2.y || l2.y <= r1.y;
	
	if (condition1)
		check = false;
	else if (condition2)
		check = false;
	else if (condition3)
		check = false;

	return check;
}