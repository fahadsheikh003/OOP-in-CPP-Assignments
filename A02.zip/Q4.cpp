//Fahad Waheed	20I-0651

#include<iostream>
#include<cstdlib>
#include<ctime>
#include<string>

using namespace std;

struct card {
	const char* i{};
	string suit;
	bool status{};
	int Rank{};
};

struct player {
	int id{};
	card* cardsInHand{};
	int number_of_cards_in_hand{};
};

class rung
{
	card* allcards;
	player* players;
	int activeplayer{};
	player dealer;
	player trump_caller;
	string trump_suit;
	int team1{}, team2{};
	int teamwin{};

public:
	rung()
	{
		allcards = new card[52];
		players = new player[4];
		for (int i = 0; i < 4; i++)
		{
			players[i].cardsInHand = new card[13];
			players[i].number_of_cards_in_hand = 13;
		}
	}

	void setplayersid(int tempid, int i)
	{
		players[i].id = tempid;
	}

	void addcards()
	{
		for (int i = 0, k = 0; i < 4; i++)
		{
			allcards[k].i = "A";
			allcards[k].status = true;
			allcards[k].Rank = 1;

			k++;

			allcards[k].i = "K";
			allcards[k].status = true;
			allcards[k].Rank = 2;

			k++;

			allcards[k].i = "Q";
			allcards[k].status = true;
			allcards[k].Rank = 3;

			k++;

			allcards[k].i = "J";
			allcards[k].status = true;
			allcards[k].Rank = 4;

			k++;

			allcards[k].i = "10";
			allcards[k].status = true;
			allcards[k].Rank = 5;

			k++;

			allcards[k].i = "9";
			allcards[k].status = true;
			allcards[k].Rank = 6;

			k++;

			allcards[k].i = "8";
			allcards[k].status = true;
			allcards[k].Rank = 7;

			k++;

			allcards[k].i = "7";
			allcards[k].status = true;
			allcards[k].Rank = 8;

			k++;

			allcards[k].i = "6";
			allcards[k].status = true;
			allcards[k].Rank = 9;

			k++;

			allcards[k].i = "5";
			allcards[k].status = true;
			allcards[k].Rank = 10;

			k++;

			allcards[k].i = "4";
			allcards[k].status = true;
			allcards[k].Rank = 11;

			k++;

			allcards[k].i = "3";
			allcards[k].status = true;
			allcards[k].Rank = 12;

			k++;

			allcards[k].i = "2";
			allcards[k].status = true;
			allcards[k].Rank = 13;

			k++;
		}
		
		for (int i = 0; i < 13; i++)
			allcards[i].suit = "spades";

		for (int i = 13; i < 26; i++)
			allcards[i].suit = "clubs";

		for (int i = 26; i < 39; i++)
			allcards[i].suit = "hearts";

		for (int i = 39; i < 52; i++)
			allcards[i].suit = "diamonds";
		
	}

	card* getallcard()
	{
		return allcards;
	}

	void chooseDealer()
	{
		srand(time(nullptr));
		
		int i = rand() % 4;

		dealer = players[i];

		if (i == 0)
		{
			trump_caller = players[3];
			activeplayer = 3;
		}
		else
		{
			trump_caller = players[i - 1];
			activeplayer = i - 1;
		}
	}

	void Deal_and_Tumps()
	{
		cin.ignore();
		cout << endl << dealer.id << " is the dealer..\n";
		cout << "Press enter to distribute cards..\n";
		cin.get();
		
		srand(time(nullptr));
		int tempindex;
		for (int i = 0; i < 4; i++)
		{
			for (int j = 0; j < 5; j++)
			{
			card_not_found:
				tempindex = rand() % 52;
				if (allcards[tempindex].status == false)
					goto card_not_found;
				players[i].cardsInHand[j] = allcards[tempindex];
				allcards[tempindex].status = false;
			}
		}
		
		cout << trump_caller.id << " is the trump caller..\n";
		cout << "\nCards of trump Caller: \n";
		for (int i = 0; i < 5; i++)
		{
			cout << i + 1 << ". " << trump_caller.cardsInHand[i].i << " of " << trump_caller.cardsInHand[i].suit << endl;
		}

		cout << "\nTrump callers Turns..\n";
		cout << "Enter trump suit (clubs, spades, diamonds, hearts): ";
		getline(cin, trump_suit);

		while (!(trump_suit == "clubs" || trump_suit == "spades" || trump_suit == "diamonds" || trump_suit == "hearts"))
		{
			cout<<"\nSorry! wrong input..\n"
				<< "Please Enter valid trump suit (clubs, spades, diamonds, hearts): ";
			getline(cin, trump_suit);
		}

		cout << endl << dealer.id << " is the dealer..\n";
		cout << "Press enter to distribute remaining cards..\n";
		cin.get();

		for (int i = 0; i < 4; i++)
		{
			for (int j = 5; j < 13; j++)
			{
			card_not_found1:
				tempindex = rand() % 52;
				if (allcards[tempindex].status == false)
					goto card_not_found1;
				players[i].cardsInHand[j] = allcards[tempindex];
				allcards[tempindex].status = false;
			}
		}
	}

	void revealCards()
	{
		for (int i = 0; i < 4; i++)
		{
			cout << "\nCards of " << players[i].id << " are \n";
			for (int j = 0; j < 13; j++)
			{
				cout << j + 1 << ". " << players[i].cardsInHand[j].i << " of " << players[i].cardsInHand[j].suit << endl;
			}
		}
	}

	void displaycards(card* temp, int n)
	{
		for (int j = 0; j < n; j++)
		{
			cout << j + 1 << ". " << temp[j].i << " of " << temp[j].suit << endl;
		}
	}

	void oneTrick()
	{
		card* tempcards=new card[4];
		int* tempindexes=new int[4];
		
		player* tempplayers=new player[4];
		int** indexofcards = new int* [4];

		for (int i = 0; i < 4; i++)
		{
			tempplayers[i].id = players[i].id;
			tempplayers[i].cardsInHand = new card[13];
			tempplayers[i].number_of_cards_in_hand = 0;
			indexofcards[i] = new int[13];
		}

		for (int z = 0; z < 4; z++)
		{
			cout << endl << players[activeplayer].id << " Turns!\n";
			cout << "Press Enter to see his/her move..\n";
			cin.get();

			tempindexes[z] = activeplayer;

			//looking for cards of trump suit
			for (int i = 0; i < 13; i++)
			{
				if (players[activeplayer].cardsInHand[i].suit == trump_suit)
				{
					tempplayers[activeplayer].cardsInHand[tempplayers[activeplayer].number_of_cards_in_hand] = players[activeplayer].cardsInHand[i];
					indexofcards[activeplayer][tempplayers[activeplayer].number_of_cards_in_hand] = i;
					tempplayers[activeplayer].number_of_cards_in_hand++;
				}
			}

			//bubble sorting to get card of hight rank at zeroth index..
			card te; int k;
			for (int i = 0; i < tempplayers[activeplayer].number_of_cards_in_hand - 1; i++)
			{
				for (int j = 0; j < tempplayers[activeplayer].number_of_cards_in_hand - i - 1; j++)
				{
					if (tempplayers[activeplayer].cardsInHand[j].Rank > tempplayers[activeplayer].cardsInHand[j + 1].Rank)
					{
						te = tempplayers[activeplayer].cardsInHand[j];
						tempplayers[activeplayer].cardsInHand[j] = tempplayers[activeplayer].cardsInHand[j + 1];
						tempplayers[activeplayer].cardsInHand[j + 1] = te;
						k = indexofcards[activeplayer][j];
						indexofcards[activeplayer][j] = indexofcards[activeplayer][j + 1];
						indexofcards[activeplayer][j + 1] = k;
					}
				}
			}

			//if no card of trump's suit found
			if (tempplayers[activeplayer].number_of_cards_in_hand == 0)
			{
				int t = rand() % players[activeplayer].number_of_cards_in_hand;
				tempcards[activeplayer] = players[activeplayer].cardsInHand[t];
				tempcards[activeplayer].Rank = 14;
				for (int i = t; i < players[activeplayer].number_of_cards_in_hand - 1; i++)
				{
					players[activeplayer].cardsInHand[i] = players[activeplayer].cardsInHand[i + 1];
				}
				players[activeplayer].number_of_cards_in_hand--;
			}
			else//for highest rank card of trump's suit
			{
				tempcards[activeplayer] = players[activeplayer].cardsInHand[indexofcards[activeplayer][0]];
				for (int i = indexofcards[activeplayer][0]; i < players[activeplayer].number_of_cards_in_hand - 1; i++)
				{
					players[activeplayer].cardsInHand[i] = players[activeplayer].cardsInHand[i + 1];
				}
				players[activeplayer].number_of_cards_in_hand--;
			}

			cout << "Move of " << players[activeplayer].id << " is " << tempcards[activeplayer].i << " of " << tempcards[activeplayer].suit << endl;

			//Updating activeplayer
			if (activeplayer == 0)
				activeplayer = 3;
			else
				activeplayer -= 1;
		}

		//checking for winning player
		int high = tempcards[0].Rank;
		int y=0;
		for (int i = 1; i < 4; i++)
		{
			if (tempcards[i].Rank < high)
			{
				high = tempcards[i].Rank;
				y = i;
			}
		}

		cout << "\nPlayer " << players[y].id << " wins!"
			<< "\nTrumps card is " << tempcards[y].i << " of " << tempcards[y].suit << ".\n";
		
		//giving next turn to winning player
		activeplayer = y;
		cout << "\nCurrent cards of " << players[activeplayer].id << " are\n";
		displaycards(players[activeplayer].cardsInHand, players[activeplayer].number_of_cards_in_hand);

		cout << "\nPlayer " << players[activeplayer].id << " turns to decide trump's suit..\n";
		cout << "Enter trump suit (clubs, spades, diamonds, hearts): ";
		getline(cin, trump_suit);

		while (!(trump_suit == "clubs" || trump_suit == "spades" || trump_suit == "diamonds" || trump_suit == "hearts"))
		{
			cout << "\nSorry! wrong input..\n"
				<< "Please Enter valid trump suit (clubs, spades, diamonds, hearts): ";
			getline(cin, trump_suit);
		}

		//for updating overall game situation
		if (y % 2 == 0)
		{
			team1++;
		}
		else if (y % 2 == 1)
		{
			team2++;
		}

		delete[] tempcards, tempindexes;

		for (int i = 0; i < 4; i++)
		{
			delete[] tempplayers[i].cardsInHand;
			delete[] indexofcards[i];
		}
		delete[] tempplayers;

		delete[] indexofcards;
	}

	void game()
	{
		for (int i = 0; i < 14; i++)
		{
			oneTrick();
			if (team1 >= 7 && team2 > 0)
			{
				teamwin = 1;
				cout << "Team 1 wins of Player: \n"
					<< "1. " << players[0].id << endl
					<< "2. " << players[2].id << endl;
				cout << "Press enter to continue..\n";
				cin.get();
				break;
			}
			else if (team2 >= 7 && team1 > 0)
			{
				teamwin = 2;
				cout << "Team 2 wins of Player: \n"
					<< "1. " << players[1].id << endl
					<< "2. " << players[3].id << endl;
				cout << "Press enter to continue..\n";
				cin.get();
				break;
			}
			else if (team1 == 13 && team2 == 0)
			{
				teamwin = 1;
				cout << "\nClean sweep by Team 1 with 13 wining tricks..\n";
				cout << "Team 1 wins of Player: \n"
					<< "1. " << players[0].id << endl
					<< "2. " << players[2].id << endl;
				cout << "Press enter to continue..\n";
				cin.get();
				break;
			}
			else if (team1 == 0 && team2 == 13)
			{
				teamwin = 2;
				cout << "\nClean sweep by Team 2 with 13 wining tricks..\n";
				cout << "Team 2 wins of Player: \n"
					<< "1. " << players[1].id << endl
					<< "2. " << players[3].id << endl;
				cout << "Press enter to continue..\n";
				cin.get();
				break;
			}
		}
	}

	void switchDealer()
	{
		int k;
		if (teamwin == 1)
		{
			k = (rand() % 2) * 2;
			dealer = players[k];
		}
		else if (teamwin == 2)
		{
			k = (rand() % 2);
			if (k == 0)
				k = 1;
			else if (k == 1)
				k = 3;
			dealer = players[k];
		}

		if (k == 0)
			activeplayer = 3;
		else
			activeplayer -= 1;

		trump_caller = players[activeplayer];

		for (int i = 0; i < 4; i++)
		{
			players[i].number_of_cards_in_hand = 13;
		}
	}

	~rung()
	{
		delete[] allcards;
		for (int i = 0; i < 4; i++)
		{
			delete[] players[i].cardsInHand;
		}
		delete[] players;
	}
};

int main()
{
	rung R;

	cout << "Player 1 and Player 3 are teammates..\n"
		<< "Whereas Player 2 and 4 are teammates..\n";
	int temp;
	for (int i = 0; i < 4; i++)
	{
		cout << "Enter Id of Player " << i + 1 << " : ";
		cin >> temp;

		R.setplayersid(temp, i);
	}

	R.addcards();
	R.chooseDealer();
	R.Deal_and_Tumps();
	R.revealCards();
	R.game();

	int choice;
	cout << "Enter 1 if u want to continue Playing: ";
	cin >> choice;

	if (choice == 1)
	{
	cont:
		R.addcards();
		R.switchDealer();
		R.Deal_and_Tumps();
		R.revealCards();
		R.game();

		cout << "Enter 1 if u want to continue Playing: ";
		cin >> choice;

		if (choice == 1)
		{
			goto cont;
		}
	}
	else
	{
		cout << "You decided to quit..";
		cout << "\nPress Enter to go ahead..";
		cin.get();
	}
}



