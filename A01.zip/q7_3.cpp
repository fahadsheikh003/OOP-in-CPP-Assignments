//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

void printarray(int **A, int x, int y, int n);
void input(int **A, int x, int y, int n);
bool CheckEqualArrays(int **A1, int **A2, int **A3, int x, int y);

int main()
{
	int row, col;
	
	cout<<"Enter number of rows of Arrays: ";
	cin>>row;
	
	cout<<"Enter number of columns of Array: ";
	cin>>col;
	
	int **A=new int *[row];
	int **B=new int *[row];
	int **C=new int *[row];
	
	for (int i=0; i<row; i++)
	{
		*(A+i)=new int [col];
		*(B+i)=new int [col];
		*(C+i)=new int [col];
	}
	
	input(A, row, col, 1);
	input(B, row, col, 2);
	input(C, row, col, 3);	
	
	printarray(A, row , col, 1);
	printarray(B, row , col, 2);
	printarray(C, row , col, 3);	
	
	CheckEqualArrays(A, B, C, row, col);
	
	for (int i=0; i<row; i++)
	{
		delete [] *(A+i);
		delete [] *(B+i);
		delete [] *(C+i);
	}
	
	delete [] A, B, C;
	A=B=C=0;
}

void printarray(int **A, int x, int y, int n)
{
	cout<<"\nArray "<<n<<": \n";
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<*(*(A+i)+j)<<"  ";
		}
		cout<<endl;
	}
}

void input(int **A, int x, int y, int n)
{
	cout<<"\nEnter data in Array "<<n<<": \n";
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<"Enter number at row "<<i+1<<" & column "<<j+1<<" : ";
			cin>>*(*(A+i)+j);
		}
		cout<<endl;
	}	
}

bool CheckEqualArrays(int **A1, int **A2, int **A3, int x, int y)
{
	bool check1=true, check2=true, check3=true, check4=true;
	
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			if ((*(*(A1+i)+j)==*(*(A2+i)+j))&&(*(*(A2+i)+j)==*(*(A3+i)+j))&&(*(*(A1+i)+j)==*(*(A3+i)+j)))
			{
				check1=true;
			}
			else
			{
				check1=false;
				break;
			}
		}
		if (check1==false)
		{
			break;
		}
	}
	
	if (check1==true)
	{
		cout<<"\nAll arrays are equal.\n";
		return true;
	}
	
	if (check1==false)
	{
		for (int i=0; i<x; i++)
		{
			for (int j=0; j<y; j++)
			{
				if (*(*(A1+i)+j)==*(*(A2+i)+j))
				{
					check2=true;
				}
				else
				{
					check2=false;
					break;
				}
			}
			
			if (check2==false)
			{
				break;
			}
		}
		
		if (check2==true)
		{
			cout<<"\nArray 1 & 2 are equal.\n";
			return true;
		}
	}
	
	if (check2==false)
	{
		for (int i=0; i<x; i++)
		{
			for (int j=0; j<y; j++)
			{
				if (*(*(A1+i)+j)==*(*(A3+i)+j))
				{
					check3=true;
				}
				else
				{
					check3=false;
					break;
				}
			}
			
			if (check3==false)
			{
				break;
			}
		}
		
		if (check3==true)
		{
			cout<<"\nArray 1 & 3 are equal.\n";
			return true;
		}
	}
	
	if (check3==false)
	{
		for (int i=0; i<x; i++)
		{
			for (int j=0; j<y; j++)
			{
				if (*(*(A2+i)+j)==*(*(A3+i)+j))
				{
					check4=true;
				}
				else
				{
					check4=false;
					break;
				}
			}
			
			if (check4==false)
			{
				break;
			}
		}
		
		if (check4==true)
		{
			cout<<"\nArray 2 & 3 are equal.\n";
			return true;
		}
	}
	
	if (check4==false)
	{
		cout<<"\nAll arrays are different.\n";
		return false;
	}
}
