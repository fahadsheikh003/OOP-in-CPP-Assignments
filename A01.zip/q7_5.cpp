//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

void printarray(int **A, int size, int n);
void input(int **A, int size, int n);
void RotateArrays(int **A1, int **A2, int **A3, int i1, int i2, int i3);

int main()
{
	int i1, i2, i3;
	
	cout<<"Enter size of square 2d array 1: ";
	cin>>i1;
	cout<<"Enter size of square 2d array 2: ";
	cin>>i2;
	cout<<"Enter size of square 2d array 3: ";
	cin>>i3;
	
	int **A=new int *[i1];
	int **B=new int *[i2];
	int **C=new int *[i3];
	
	for (int i=0; i<i1; i++)
	{
		*(A+i)=new int [i1];
	}
	for (int i=0; i<i2; i++)
	{
		*(B+i)=new int [i2];
	}
	for (int i=0; i<i3; i++)
	{
		*(C+i)=new int [i3];
	}
	
	input(A, i1, 1);
	input(B, i2, 2);
	input(C, i3, 3);
	cout<<"\nBefore Rotating: \n";
	printarray(A, i1, 1);
	printarray(B, i2, 2);
	printarray(C, i3, 3);
	
	RotateArrays(A, B, C, i1, i2, i3);
	cout<<"\nAfter Rotating: \n";
	printarray(A, i1, 1);
	printarray(B, i2, 2);
	printarray(C, i3, 3);
	
	for (int i=0; i<i1; i++)
	{
		delete [] *(A+i);
	}
	for (int i=0; i<i2; i++)
	{
		delete [] *(B+i);
	}
	for (int i=0; i<i3; i++)
	{
		delete [] *(C+i);
	}
	
	delete [] A, B, C;
	A=B=C=0;
}

void input(int **A, int size, int n)
{
	cout<<"\nEnter data in Array "<<n<<": \n";
	for (int i=0; i<size; i++)
	{
		for (int j=0; j<size; j++)
		{
			cout<<"Enter number at row "<<i+1<<" & column "<<j+1<<" : ";
			cin>>*(*(A+i)+j);
		}
		cout<<endl;
	}
}

void printarray(int **A, int size, int n)
{
	cout<<"\nArray "<<n<<": \n";
	for (int i=0; i<size; i++)
	{
		for (int j=0; j<size; j++)
		{
			cout<<*(*(A+i)+j)<<"  ";
		}
		cout<<endl;
	}
}

void RotateArrays(int **A1, int **A2, int **A3, int i1, int i2, int i3)
{
	int temp1, temp2, temp3;
	
	for (int i=0; i<i1/2; i++)
	{
    	for (int j=i; j<i1-i-1; j++)
    	{
    	    temp1= *(*(A1+i)+j);
        	*(*(A1+i)+j)= *(*(A1+i1-j-1)+i);
        	*(*(A1+i1-j-1)+i)= *(*(A1+i1-i-1)+i1-j-1);
        	*(*(A1+i1-i-1)+i1-j-1)= *(*(A1+j)+i1-i-1);
        	*(*(A1+j)+i1-i-1)= temp1;
    	}
	}
	
	for (int i=0; i<i2/2; i++)
	{
		for (int j=i; j<i2-i-1; j++)
		{
			temp2= *(*(A2+i)+j);
        	*(*(A2+i)+j)= *(*(A2+i2-j-1)+i);
        	*(*(A2+i2-j-1)+i)= *(*(A2+i2-i-1)+i2-j-1);
        	*(*(A2+i2-i-1)+i2-j-1)= *(*(A2+j)+i2-i-1);
        	*(*(A2+j)+i2-i-1)= temp2;
		}
	}
	
	for (int i=0; i<i3/2; i++)
	{
		for (int j=i; j<i3-i-1; j++)
		{
			temp3= *(*(A3+i)+j);
        	*(*(A3+i)+j)= *(*(A3+i3-j-1)+i);
        	*(*(A3+i3-j-1)+i)= *(*(A3+i3-i-1)+i3-j-1);
        	*(*(A3+i3-i-1)+i3-j-1)= *(*(A3+j)+i3-i-1);
        	*(*(A3+j)+i3-i-1)= temp3;
		}
	}
}
