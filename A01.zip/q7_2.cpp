//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

void printarray(int **A, int x, int y, int n);
void input(int **A, int x, int y, int n);
bool CheckDifferentArrays(int **A1, int **A2, int **A3, int x, int y);

int main()
{
	int row, col;
	
	cout<<"Enter number of rows of Arrays: ";
	cin>>row;
	
	cout<<"Enter number of columns of Array: ";
	cin>>col;
	
	int **A=new int *[row];
	int **B=new int *[row];
	int **C=new int *[row];
	
	for (int i=0; i<row; i++)
	{
		*(A+i)=new int [col];
		*(B+i)=new int [col];
		*(C+i)=new int [col];
	}
	
	input(A, row, col, 1);
	input(B, row, col, 2);
	input(C, row, col, 3);	
	
	printarray(A, row , col, 1);
	printarray(B, row , col, 2);
	printarray(C, row , col, 3);	
	
	CheckDifferentArrays(A, B, C, row, col);
	
	for (int i=0; i<row; i++)
	{
		delete [] *(A+i);
		delete [] *(B+i);
		delete [] *(C+i);
	}
	
	delete [] A, B, C;
	A=B=C=0;
}

void printarray(int **A, int x, int y, int n)
{
	cout<<"\nArray "<<n<<": \n";
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<*(*(A+i)+j)<<"  ";
		}
		cout<<endl;
	}
}

void input(int **A, int x, int y, int n)
{
	cout<<"\nEnter data in Array "<<n<<": \n";
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<"Enter number at row "<<i+1<<" & column "<<j+1<<" : ";
			cin>>*(*(A+i)+j);
		}
		cout<<endl;
	}
}

bool CheckDifferentArrays(int **A1, int **A2, int **A3, int x, int y)
{
	int A1sum=0, A2sum=0, A3sum=0;
	
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			A1sum+=*(*(A1+i)+j);
			A2sum+=*(*(A2+i)+j);
			A3sum+=*(*(A3+i)+j);
		}
	}
	
	if (A1sum-A2sum==A3sum)
	{
		cout<<"The Difference of array 1 and 2 is equal to array 3.";
		return true;
	}
	
	else if (A1sum-A3sum==A2sum)
	{
		cout<<"The Difference of array 1 and 3 is equal to array 2.";
		return true;
	}
	
	else if (A2sum-A3sum==A1sum)
	{
		cout<<"The Difference of array 2 and 3 is equal to array 1.";
		return true;
	}
	
	else
	{
		cout<<"Sorry! the Difference of any two arrays is not equal to the third one.";
		return false;
	}
}
