//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

int EvenSum(int **arr, int x, int y);
int OddSum(int **arr, int x, int y);

int main()
{
	int x, y;
	
	cout<<"Enter number of rows of Array: ";
	cin>>x;
	
	cout<<"Enter number of columns of Array: ";
	cin>>y;
	
	int **arr=new int *[x];
	
	for (int i=0; i<x; i++)
	{
		*(arr+i)=new int [y];
	}
	
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<"Enter number at row "<<i+1<<" & column "<<j+1<<" : ";
			cin>>*(*(arr+i)+j);
		}
	}
	
	cout<<"Sum of Even numbers of Array: "<<EvenSum(arr, x, y)<<endl;
	cout<<"Sum of Odd numbers of Array: "<<OddSum(arr, x, y)<<endl;
	
	for (int i=0; i<x; i++)
	{
		delete [] *(arr+i);
	}
	
	delete [] arr;
	arr=0;
}

int EvenSum(int **arr, int x, int y)
{
	int sum=0;
	
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			if (*(*(arr+i)+j)%2==0)
			{
				sum+=*(*(arr+i)+j);
			}
		}
	}
	
	return sum;
}

int OddSum(int **arr, int x, int y)
{
	int sum=0;
	
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			if (*(*(arr+i)+j)%2==1)
			{
				sum+=*(*(arr+i)+j);
			}
		}
	}
	
	return sum;
}
