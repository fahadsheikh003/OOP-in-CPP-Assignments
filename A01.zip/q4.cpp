//Fahad Waheed	20I-0651

#include<iostream>
#include<iomanip>

using namespace std;

void FindOccurances(int* A, int size);
int occurance(int* A, int size, int curr);
void sorting(int* ResultArray, int* DigitArray, int size);

int main()
{
	int size=0;
    cout<<"Enter the Size of the Array: ";
    cin>>size;
    
	int *array = new int [size];
    cout<<"Enter the Elements in the array : \n";
    for (int i=0; i<size; i++)
    {
        cout<<"Enter Number "<<i+1<<" in Array :";
        cin>>*(array+i);
    }
    //int array[] = {2, 4, 1, 5, 6, 4, 2};
    //int size = sizeof(array) / sizeof(array[0]);
    FindOccurances(array, size);
    
    delete [] array;
    array=0;
}

void FindOccurances(int* A, int size)
{
	int arraysize = 0;
	int resultarray[size], digitarray[size];
	bool check;
	int curr;
	
	for (int i = 0, k = 0; i < size; i++)
	{
		check = true;
		curr = A[i];

		for (int j = 0; j < i; j++)
		{
			if (i == 0)
				continue;
			
			if (A[j] == curr)
			{
				check = false;
			}
		}

		if (check == true)
		{
			digitarray[k] = curr;
			k++;
			arraysize++;
		}
	}
	
	for (int i=0; i<arraysize; i++)
	{
		resultarray[i]=occurance(A, size - 1, digitarray[i]);
	}	
		
	sorting(resultarray, digitarray, arraysize);
	cout << "Numbers" << setw(22) << "Occurances\n";
	for (int i = 0; i < arraysize; i++)
	{
		cout << digitarray[i] << setw(22) << resultarray[i] << endl;
	}
}

int occurance(int* A, int size, int curr)
{	
	if (size < 0)
	{
		return 0;
	}

	if (A[size]==curr)
	{
		return 1 + occurance(A, size - 1, curr);
	}
	else
	{
		return 0 + occurance(A, size - 1, curr);
	}
}

void sorting(int* ResultArray, int* DigitArray, int size)
{
	if (size == 0)
		return;

	for (int i = 0; i < size-1; i++)
	{
		if (ResultArray[i] < ResultArray[i + 1])
		{
			swap(ResultArray[i], ResultArray[i + 1]);
			swap(DigitArray[i], DigitArray[i + 1]);
		}
	}

	sorting(ResultArray, DigitArray, size - 1);
}
