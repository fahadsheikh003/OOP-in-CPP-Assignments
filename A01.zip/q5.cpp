//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

int FindInversion(int **A, int i, int j);

int CountInversion(int **A, int i, int j, int y);

int main()
{
	int row, col;
	
	cout<<"Enter number of rows of 2d array: ";
	cin>>row;
	
	cout<<"Enter number of column of 2d array: ";
	cin>>col;
	
	int **arr=new int *[row];
	for (int i=0; i<row; i++)
	{
		*(arr+i)=new int [col];
	}
	
	for (int i=0; i<row; i++)
	{
		for (int j=0; j<col; j++)
		{
			cout<<"Enter number at row "<<i+1<<" & column "<<j+1<<" : ";
			cin>>*(*(arr+i)+j);
		}
	}
	
	FindInversion(arr, row-1, col-1);
	
	for (int i=0; i<row; i++)
	{
		delete *(arr+i);
	}
	
	delete [] arr;
	arr=0;
}

int CountInversion(int **A, int i, int j, int y)
{
	if (i<0)
		return 0;
		
	else if ((i<j && A[i][j]>A[j][i])&&(j<0))
		return 1 + CountInversion(A, i-1, y, y);
		
	else if ((j>=0)&&(i<j && A[i][j]>A[j][i]))
		return 1 + CountInversion(A, i, j-1, y);
	
	else if (j<0)
		return CountInversion(A, i-1, y, y);
		
	else 
		return CountInversion(A, i, j-1, y);		
}

int FindInversion(int **A, int i, int j)
{
	int count=CountInversion(A, i, j, j);
	cout<<"Total number of Inversions: "<<count<<endl;
	
	return count;
}
