//Fahad Waheed	20I-0651

#include<iostream>
#include<cstring>

using namespace std;

bool CheckSubsequent(char *str1, char *str2, int i, int j);

int main()
{
	char A1[50], A2[50];
	
	cout<<"Program to find that a second string is a subsequent of the first string or not.\n";
	
	cout<<"Enter first String: ";
	cin.getline(A1, 50);
	
	cout<<"Enter Second String: ";
	cin.getline(A2, 50);
	
	int s1=strlen(A1);
	int s2=strlen(A2);
	
	if (CheckSubsequent(A1, A2, s1, s2))
	{
		cout<<A2<<" is a subsequent of "<<A1<<endl;
	}
	
	else 
	{
		cout<<A2<<" is not a subsequent of "<<A1<<endl;
	}
}

bool CheckSubsequent(char *str1, char *str2, int i, int j)
{
	if (j==0)
		return true;
	else if (i==0)
		return false;
	else if (str1[i-1]==str2[j-1])
		CheckSubsequent(str1, str2, i-1, j-1);
	else 
		CheckSubsequent(str1, str2, i-1, j);
}
