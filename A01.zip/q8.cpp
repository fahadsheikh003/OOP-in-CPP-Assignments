//Fahad Waheed	20I-0651

#include<iostream>
#include<cstring>

using namespace std;

void countingUniqueWords (char * string, char **uwords , int *size);
char ** deleterepeating (char **uwords, int *size, int *ns);

int main()
{
	char array[500];
	char **uwords;
	
	cout<<"Enter a String: ";
	cin.getline(array, 500);
	
	int size=0;
	
	countingUniqueWords(array, uwords, &size);
}

void countingUniqueWords (char * string, char **uwords , int *size)
{
	char **input;
	int j=0, k=0;
	int count=0;
	int stringsize=strlen(string);
	count<<"String Length: "<<stringsize<<endl;
	for (int i=0; i<stringsize; i++)
	{
		if (string[i]==' '||'\n'||'\t'||'.'||'?'||','||'!')
		{
			j++;
			k=0;
			count++;
			*size++;
		}
		
		else 
		{
			input[j][k]=string[i];
			k++;
		}
	}
	
	
	uwords=deleterepeating(input, &count, size);
	
	cout<<"Number of Unique words: "<<*size<<endl;
	cout<<"Unique words are: \n";
	for (int i=0; i<*size; i++)
	{
		cout<<uwords[i]<<endl;
	}
}

char ** deleterepeating (char **uwords, int *size, int *ns)
{
	for (int i=0; i<*size; i++)
	{
		for (int j=i+1; j<*size; j++ )
		{
			if (uwords[i]==uwords[j])
			{
				uwords[j]="Null";
			}
		}
	}
	
	char **result;
	
	for (int i=0; i<*size; i++)
	{
		if (uwords[i]=="Null")
		{
			continue;
		}
		
		else
		{
			result[i]=uwords[i];
			*ns++;
		}
	}
	
	return result;
}
