//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

void PrintPattern(int &n);
void findcombinations(int array[], int i, int n, int rn);
void check(int arr[], int i,int n);

int main()
{
	int n;
	
	cout<<"Enter a number: ";
	cin>>n;
	
	PrintPattern(n);
}

void PrintPattern(int &n)
{
	int array[n];
	
	findcombinations(array, 0, n, n);
}

void check(int arr[], int i,int n)
{
	int sum=0;
	for (int j=0; j<i; j++)
	{
		sum+=arr[j];
	}
	
	if (sum==n)
	{
		for (int j=0; j<i; j++)
            cout<<arr[j]<<" ";
        cout<<endl;
	}
}

void findcombinations(int array[], int i, int n, int rn)
{
	if (rn < 0)
        return;

    int last;
    if (i==0)
    	last=1;
    else 
    	last=array[i-1];

    for (int j = last; j <= n ; j++)
    {
        array[i] = j;
        findcombinations (array, i+1, n, rn - j);
    }
    
	check(array, i, n);
}
