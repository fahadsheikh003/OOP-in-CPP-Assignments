//Fahad Waheed	20I-0651

#include<iostream>

using namespace std;

void printarray(int **A, int x, int y, int n);
void input(int **A, int x, int y, int n);
int FindSameRows(int **A1, int **A2, int **A3, int x, int y);

int main()
{
	int row, col;
	
	cout<<"Enter number of rows of Arrays: ";
	cin>>row;
	
	cout<<"Enter number of columns of Array: ";
	cin>>col;
	
	int **A=new int *[row];
	int **B=new int *[row];
	int **C=new int *[row];
	
	for (int i=0; i<row; i++)
	{
		*(A+i)=new int [col];
		*(B+i)=new int [col];
		*(C+i)=new int [col];
	}
	
	input(A, row, col, 1);
	input(B, row, col, 2);
	input(C, row, col, 3);	
	
	printarray(A, row , col, 1);
	printarray(B, row , col, 2);
	printarray(C, row , col, 3);
	
	cout<<"Number of same rows: "<<FindSameRows(A, B, C, row, col);
}

void printarray(int **A, int x, int y, int n)
{
	cout<<"\nArray "<<n<<": \n";
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<*(*(A+i)+j)<<"  ";
		}
		cout<<endl;
	}
}

void input(int **A, int x, int y, int n)
{
	cout<<"\nEnter data in Array "<<n<<": \n";
	for (int i=0; i<x; i++)
	{
		for (int j=0; j<y; j++)
		{
			cout<<"Enter number at row "<<i+1<<" & column "<<j+1<<" : ";
			cin>>*(*(A+i)+j);
		}
		cout<<endl;
	}	
}

int FindSameRows(int **A1, int **A2, int **A3, int x, int y)
{
	int count=1, count1=0, n=0, index=0;
	bool check;
	
	for (int i=0; i<x; i++)
	{
		for (int j=i+1; j<x; j++)
		{
			check=true;
			
			for (int k=0; k<y; k++)
			{
				if (*(*(A1+i)+k)!=*(*(A1+j)+k))
				{
					check=false;
					
					break;
				}	
			}
			
			if (check==true)
			{
				count++;
				index=j-1;
				n=1;
				break;	
			}
		}
		
		if (count==2)
		{
			break;
		}
	}
	
	if (count=1)
	{
		for (int i=0; i<x; i++)
		{
			for (int j=i+1; j<x; j++)
			{
				check=true;
			
				for (int k=0; k<y; k++)
				{
					if (*(*(A2+i)+k)!=*(*(A2+j)+k))
					{
						check=false;
					
						break;
					}
				
				
				}
			
				if (check==true)
				{
					count++;
					index=j-1;
					n=2;
					break;	
				}
			}
		
			if (count==2)
			{
				break;
			}
		}
	}
	
	if (count=1)
	{
		for (int i=0; i<x; i++)
		{
			for (int j=i+1; j<x; j++)
			{
				check=true;
			
				for (int k=0; k<y; k++)
				{
					if (*(*(A3+i)+k)!=*(*(A3+j)+k))
					{
						check=false;
					
						break;
					}
				
				
				}
			
				if (check==true)
				{
					count++;
					index=j-1;
					n=3;
					break;	
				}
			}
		
			if (count==2)
			{
				break;
			}
		}
	}
	
	bool check1, check2, check3;
	
	if (n==1)
	{
		for (int i=0; i<x; i++)
		{
			check1=check2=check3=true;
		
			for (int j=0; j<y; j++)
			{
				if (*(*(A1+index)+j)!=*(*(A1+i)+j))
				{
					check1=false;
				}
			
				if (*(*(A1+index)+j)!=*(*(A3+i)+j))
				{
					check3=false;
				}
			
				if (*(*(A1+index)+j)!=*(*(A2+i)+j))
				{
					check2=false;
				}
			}
		
			if (check1==true)
			{
				count1++;
			}
		
			if (check2==true)
			{
				count1++;
			}
		
			if (check3==true)
			{
				count1++;
			}
		}
	}
	
	else if (n==2)
	{
		for (int i=0; i<x; i++)
		{
			check1=check2=check3=true;
		
			for (int j=0; j<y; j++)
			{
				if (*(*(A2+index)+j)!=*(*(A1+i)+j))
				{
					check1=false;
				}
			
				if (*(*(A2+index)+j)!=*(*(A3+i)+j))
				{
					check3=false;
				}
			
				if (*(*(A2+index)+j)!=*(*(A2+i)+j))
				{
					check2=false;
				}
			}
		
			if (check1==true)
			{
				count1++;
			}
		
			if (check2==true)
			{
				count1++;
			}
		
			if (check3==true)
			{
				count1++;
			}
		}
	}
	
	else if (n==3)
	{
		for (int i=0; i<x; i++)
		{
			check1=check2=check3=true;
		
			for (int j=0; j<y; j++)
			{
				if (*(*(A3+index)+j)!=*(*(A1+i)+j))
				{
					check1=false;
				}
			
				if (*(*(A3+index)+j)!=*(*(A3+i)+j))
				{
					check3=false;
				}
			
				if (*(*(A3+index)+j)!=*(*(A2+i)+j))
				{
					check2=false;
				}
			}
		
			if (check1==true)
			{
				count1++;
			}
		
			if (check2==true)
			{
				count1++;
			}
		
			if (check3==true)
			{
				count1++;
			}
		}
	}
	
	return count1;
}
